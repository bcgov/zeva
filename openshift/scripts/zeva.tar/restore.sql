--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE zeva;
--
-- Name: zeva; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE zeva WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf-8';


\connect zeva

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: zeva_audit; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA zeva_audit;


--
-- Name: SCHEMA zeva_audit; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA zeva_audit IS 'Auditing of actions';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgaudit; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgaudit WITH SCHEMA public;


--
-- Name: EXTENSION pgaudit; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgaudit IS 'provides auditing functionality';


--
-- Name: set_user; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS set_user WITH SCHEMA public;


--
-- Name: EXTENSION set_user; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION set_user IS 'similar to SET ROLE but with added logging';


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(username text) RETURNS TABLE(username text, password text)
    LANGUAGE sql STABLE SECURITY DEFINER
    AS $_$
  SELECT rolname::TEXT, rolpassword::TEXT
  FROM pg_catalog.pg_authid
  WHERE pg_authid.rolname = $1
    AND pg_authid.rolcanlogin
    AND NOT pg_authid.rolsuper
    AND NOT pg_authid.rolreplication
    AND pg_authid.rolname <> '_crunchypgbouncer'
    AND (pg_authid.rolvaliduntil IS NULL OR pg_authid.rolvaliduntil >= CURRENT_TIMESTAMP)$_$;


--
-- Name: audit_table(regclass); Type: FUNCTION; Schema: zeva_audit; Owner: -
--

CREATE FUNCTION zeva_audit.audit_table(target_table regclass) RETURNS void
    LANGUAGE sql
    AS $_$
SELECT zeva_audit.audit_table($1, BOOLEAN 't', BOOLEAN 't');
$_$;


--
-- Name: FUNCTION audit_table(target_table regclass); Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON FUNCTION zeva_audit.audit_table(target_table regclass) IS '
Add auditing support to the given table. Row-level changes will be logged with full client query text. No cols are ignored.
';


--
-- Name: audit_table(regclass, boolean, boolean); Type: FUNCTION; Schema: zeva_audit; Owner: -
--

CREATE FUNCTION zeva_audit.audit_table(target_table regclass, audit_rows boolean, audit_query_text boolean) RETURNS void
    LANGUAGE sql
    AS $_$
SELECT zeva_audit.audit_table($1, $2, $3, ARRAY[]::text[]);
$_$;


--
-- Name: audit_table(regclass, boolean, boolean, text[]); Type: FUNCTION; Schema: zeva_audit; Owner: -
--

CREATE FUNCTION zeva_audit.audit_table(target_table regclass, audit_rows boolean, audit_query_text boolean, ignored_cols text[]) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  stm_targets text = 'INSERT OR UPDATE OR DELETE OR TRUNCATE';
  _q_txt text;
  _ignored_cols_snip text = '';
BEGIN
    EXECUTE 'DROP TRIGGER IF EXISTS audit_trigger_row ON ' || quote_ident(target_table::TEXT);
    EXECUTE 'DROP TRIGGER IF EXISTS audit_trigger_stm ON ' || quote_ident(target_table::TEXT);

    IF audit_rows THEN
        IF array_length(ignored_cols,1) > 0 THEN
            _ignored_cols_snip = ', ' || quote_literal(ignored_cols);
        END IF;
        _q_txt = 'CREATE TRIGGER audit_trigger_row AFTER INSERT OR UPDATE OR DELETE ON ' ||
                 target_table::TEXT ||
                 ' FOR EACH ROW EXECUTE PROCEDURE zeva_audit.if_modified_func(' ||
                 quote_literal(audit_query_text) || _ignored_cols_snip || ');';
        RAISE NOTICE '%',_q_txt;
        EXECUTE _q_txt;
        stm_targets = 'TRUNCATE';
    ELSE
    END IF;

    _q_txt = 'CREATE TRIGGER audit_trigger_stm AFTER ' || stm_targets || ' ON ' ||
             target_table ||
             ' FOR EACH STATEMENT EXECUTE PROCEDURE zeva_audit.if_modified_func('||
             quote_literal(audit_query_text) || ');';
    RAISE NOTICE '%',_q_txt;
    EXECUTE _q_txt;

END;
$$;


--
-- Name: FUNCTION audit_table(target_table regclass, audit_rows boolean, audit_query_text boolean, ignored_cols text[]); Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON FUNCTION zeva_audit.audit_table(target_table regclass, audit_rows boolean, audit_query_text boolean, ignored_cols text[]) IS '
Add auditing support to a table.

Arguments:
   target_table:     Table name, schema qualified if not on search_path
   audit_rows:       Record each row change, or only audit at a statement level
   audit_query_text: Record the text of the client query that triggered the audit event?
   ignored_cols:     Columns to exclude from update diffs, ignore updates that change only ignored cols.
';


--
-- Name: if_modified_func(); Type: FUNCTION; Schema: zeva_audit; Owner: -
--

CREATE FUNCTION zeva_audit.if_modified_func() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public'
    AS $$
DECLARE
    audit_row zeva_audit.logged_actions;
    include_values boolean;
    log_diffs boolean;
    h_old hstore;
    h_new hstore;
    excluded_cols text[] = ARRAY[]::text[];
BEGIN
    IF TG_WHEN <> 'AFTER' THEN
        RAISE EXCEPTION 'zeva_audit.if_modified_func() may only run as an AFTER trigger';
    END IF;

    audit_row = ROW(
        nextval('zeva_audit.logged_actions_event_id_seq'), -- event_id
        TG_TABLE_SCHEMA::text,                        -- schema_name
        TG_TABLE_NAME::text,                          -- table_name
        TG_RELID,                                     -- relation OID for much quicker searches
        session_user::text,                           -- session_user_name
        current_timestamp,                            -- action_tstamp_tx
        current_query(),                              -- top-level query or queries (if multistatement) from client
        substring(TG_OP,1,1),                         -- action
        NULL, NULL,                                   -- row_data, changed_fields
        'f'                                           -- statement_only
        );

    IF NOT TG_ARGV[0]::boolean IS DISTINCT FROM 'f'::boolean THEN
        audit_row.client_query = NULL;
    END IF;

    IF TG_ARGV[1] IS NOT NULL THEN
        excluded_cols = TG_ARGV[1]::text[];
    END IF;

    IF (TG_OP = 'UPDATE' AND TG_LEVEL = 'ROW') THEN
        audit_row.row_data = hstore(OLD.*) - excluded_cols;
        audit_row.changed_fields =  (hstore(NEW.*) - audit_row.row_data) - excluded_cols;
        IF audit_row.changed_fields = hstore('') THEN
            -- All changed fields are ignored. Skip this update.
            RETURN NULL;
        END IF;
    ELSIF (TG_OP = 'DELETE' AND TG_LEVEL = 'ROW') THEN
        audit_row.row_data = hstore(OLD.*) - excluded_cols;
    ELSIF (TG_OP = 'INSERT' AND TG_LEVEL = 'ROW') THEN
        audit_row.row_data = hstore(NEW.*) - excluded_cols;
    ELSIF (TG_LEVEL = 'STATEMENT' AND TG_OP IN ('INSERT','UPDATE','DELETE','TRUNCATE')) THEN
        audit_row.statement_only = 't';
    ELSE
        RAISE EXCEPTION '[zeva_audit.if_modified_func] - Trigger func added as trigger for unhandled case: %, %',TG_OP, TG_LEVEL;
        RETURN NULL;
    END IF;
    INSERT INTO zeva_audit.logged_actions VALUES (audit_row.*);
    RETURN NULL;
END;
$$;


--
-- Name: FUNCTION if_modified_func(); Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON FUNCTION zeva_audit.if_modified_func() IS '
Track changes to a table at the statement and/or row level.

Optional parameters to trigger in CREATE TRIGGER call:

param 0: boolean, whether to log the query text. Default ''t''.

param 1: text[], columns to ignore in updates. Default [].

         Updates to ignored cols are omitted from changed_fields.

         Updates with only ignored cols changed are not inserted
         into the audit log.

         Almost all the processing work is still done for updates
         that ignored. If you need to save the load, you need to use
         WHEN clause on the trigger instead.

         No warning or error is issued if ignored_cols contains columns
         that do not exist in the target table. This lets you specify
         a standard set of ignored columns.

There is no parameter to disable logging of values. Add this trigger as
a ''FOR EACH STATEMENT'' rather than ''FOR EACH ROW'' trigger if you do not
want to log row values.

Note that the user name logged is the login role for the session. The audit trigger
cannot obtain the active role because it is reset by the SECURITY DEFINER invocation
of the audit trigger its self.
';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.address_type (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    effective_date date,
    expiration_date date,
    address_type character varying(20) NOT NULL
);


--
-- Name: TABLE address_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.address_type IS 'A lookup table for address type.Can be either records or service addresses.Service = the address for service of the supplierRecords = the address where the supplier keeps records required to be kept and maintained under the Act';


--
-- Name: COLUMN address_type.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address_type.id IS 'Primary key';


--
-- Name: COLUMN address_type.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address_type.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN address_type.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address_type.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN address_type.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address_type.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN address_type.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address_type.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN address_type.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address_type.effective_date IS 'The calendar date the value became valid.';


--
-- Name: COLUMN address_type.expiration_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address_type.expiration_date IS 'The calendar date the value is no longer valid.';


--
-- Name: COLUMN address_type.address_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address_type.address_type IS 'Address Type';


--
-- Name: address_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.address_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: address_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.address_type_id_seq OWNED BY public.address_type.id;


--
-- Name: vehicle_change_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_change_history (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    vehicle_id integer NOT NULL,
    model_name character varying(250),
    model_year_id integer NOT NULL,
    range integer NOT NULL,
    user_role character varying(50)[],
    validation_status character varying(20),
    vehicle_zev_type_id integer NOT NULL,
    make character varying(250),
    vehicle_class_code_id integer NOT NULL,
    weight_kg numeric(6,0) NOT NULL,
    organization_id integer NOT NULL,
    create_user character varying(130) NOT NULL
);


--
-- Name: TABLE vehicle_change_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vehicle_change_history IS 'Keeps track of the changes done on the vehicle table.Each row should contain the last known values of the vehicle row, before it''s updated or created.';


--
-- Name: COLUMN vehicle_change_history.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.create_timestamp IS 'When the change was made';


--
-- Name: COLUMN vehicle_change_history.vehicle_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.vehicle_id IS 'Reference to primary key (id) of table vehicle';


--
-- Name: COLUMN vehicle_change_history.model_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.model_name IS 'Model of vehicle';


--
-- Name: COLUMN vehicle_change_history.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.model_year_id IS 'ID referencing the model_year table';


--
-- Name: COLUMN vehicle_change_history.range; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.range IS 'Vehicle Range in km';


--
-- Name: COLUMN vehicle_change_history.user_role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.user_role IS 'The role (or roles) assigned to the user at the time they made a change to a vehicle record. Role values are generated from Keycloak and are stored in a comma-delimited string.';


--
-- Name: COLUMN vehicle_change_history.validation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.validation_status IS 'The validation status of the vehicle. Valid statuses: [''NEW'', ''DRAFT'', ''SUBMITTED'', ''VALIDATED'', ''REJECTED'', ''CHANGES_REQUESTED'', ''DELETED'']';


--
-- Name: COLUMN vehicle_change_history.vehicle_zev_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.vehicle_zev_type_id IS 'ID referencing the vehicle_zev_type table';


--
-- Name: COLUMN vehicle_change_history.make; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.make IS 'Make of vehicle';


--
-- Name: COLUMN vehicle_change_history.vehicle_class_code_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.vehicle_class_code_id IS 'ID referencing the vehicle_class_code table';


--
-- Name: COLUMN vehicle_change_history.weight_kg; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.weight_kg IS 'Weight of vehicle';


--
-- Name: COLUMN vehicle_change_history.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.organization_id IS 'ID referencing the organization table';


--
-- Name: COLUMN vehicle_change_history.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_change_history.create_user IS 'User ID associated to the person who''s making the changes to the vehicle record';


--
-- Name: api_vehiclechangehistory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_vehiclechangehistory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: api_vehiclechangehistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_vehiclechangehistory_id_seq OWNED BY public.vehicle_change_history.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


--
-- Name: TABLE auth_group; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.auth_group IS 'Django Authentication groups(used by admin application)';


--
-- Name: COLUMN auth_group.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.auth_group.id IS 'Primary key';


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: TABLE auth_group_permissions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.auth_group_permissions IS 'Django Authentication groups to permissions mapping(used by admin application)';


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


--
-- Name: TABLE auth_permission; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.auth_permission IS 'Django Authentication permissions (used by admin application)';


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: compliance_ratio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_ratio (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    model_year character varying(250) NOT NULL,
    compliance_ratio numeric(20,2) NOT NULL,
    zev_class_a numeric(20,2) NOT NULL
);


--
-- Name: TABLE compliance_ratio; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.compliance_ratio IS 'Table to store compliance ratio based on model year';


--
-- Name: COLUMN compliance_ratio.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.compliance_ratio.id IS 'Primary key';


--
-- Name: COLUMN compliance_ratio.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.compliance_ratio.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN compliance_ratio.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.compliance_ratio.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN compliance_ratio.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.compliance_ratio.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN compliance_ratio.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.compliance_ratio.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN compliance_ratio.model_year; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.compliance_ratio.model_year IS 'model year';


--
-- Name: COLUMN compliance_ratio.compliance_ratio; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.compliance_ratio.compliance_ratio IS 'Containes the compliance ratio percentage for for each model year for light-duty motor vehicle class.';


--
-- Name: COLUMN compliance_ratio.zev_class_a; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.compliance_ratio.zev_class_a IS 'Contains the compliance ratio percentage for ZEV Class A vehicles in the light-duty motor vehicle class.';


--
-- Name: compliance_ratio_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compliance_ratio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compliance_ratio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compliance_ratio_id_seq OWNED BY public.compliance_ratio.id;


--
-- Name: credit_agreement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_agreement (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    transaction_type character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    effective_date date,
    organization_id integer NOT NULL,
    optional_agreement_id character varying(20),
    model_year_report_id integer
);


--
-- Name: TABLE credit_agreement; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_agreement IS 'Credit Agreement containes details of credit adjustments agreements created by government';


--
-- Name: COLUMN credit_agreement.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.id IS 'Primary key';


--
-- Name: COLUMN credit_agreement.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_agreement.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_agreement.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_agreement.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_agreement.transaction_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.transaction_type IS 'The transaction type of this credit agreement. Valid transaction types: [''INITIATIVE_AGREEMENT'', ''PURCHASE_AGREEMENT'', ''ADMINISTRATIVE_CREDIT_ALLOCATION'', ''ADMINISTRATIVE_CREDIT_REDUCTION'', ''AUTOMATIC_ADMINISTRATIVE_PENALTY'', ''REASSESSMENT_ALLOCATION'', ''REASSESSMENT_REDUCTION'']';


--
-- Name: COLUMN credit_agreement.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.status IS 'The validation status of this credit agreement. Valid statuses: [''DRAFT'', ''RECOMMENDED'', ''ISSUED'', ''DELETED'', ''RETURNED'']';


--
-- Name: COLUMN credit_agreement.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.effective_date IS 'The calendar date the credit agreement created';


--
-- Name: COLUMN credit_agreement.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.organization_id IS 'Reference to primary key (id) of table organization';


--
-- Name: COLUMN credit_agreement.optional_agreement_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.optional_agreement_id IS 'Optional Agreement ID, not a foreign key';


--
-- Name: COLUMN credit_agreement.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: credit_agreement_comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_agreement_comment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    to_director boolean NOT NULL,
    comment character varying(4000),
    credit_agreement_id integer NOT NULL
);


--
-- Name: TABLE credit_agreement_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_agreement_comment IS 'Contains comments made about the Credit Agreementfrom analyst to director and from director to supplier';


--
-- Name: COLUMN credit_agreement_comment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_comment.id IS 'Primary key';


--
-- Name: COLUMN credit_agreement_comment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_comment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_agreement_comment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_comment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_agreement_comment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_comment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_agreement_comment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_comment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_agreement_comment.to_director; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_comment.to_director IS 'determines if comment is meant for director';


--
-- Name: COLUMN credit_agreement_comment.comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_comment.comment IS 'Comment left by idir user about credit agreement';


--
-- Name: COLUMN credit_agreement_comment.credit_agreement_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_comment.credit_agreement_id IS 'Reference to primary key (id) of table credit_agreement';


--
-- Name: credit_agreement_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_agreement_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_agreement_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_agreement_comment_id_seq OWNED BY public.credit_agreement_comment.id;


--
-- Name: credit_agreement_content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_agreement_content (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    number_of_credits numeric(20,2) NOT NULL,
    credit_agreement_id integer NOT NULL,
    credit_class_id integer NOT NULL,
    model_year_id integer NOT NULL
);


--
-- Name: TABLE credit_agreement_content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_agreement_content IS 'Credit details for Credit Agreement Report.';


--
-- Name: COLUMN credit_agreement_content.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_content.id IS 'Primary key';


--
-- Name: COLUMN credit_agreement_content.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_content.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_agreement_content.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_content.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_agreement_content.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_content.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_agreement_content.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_content.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_agreement_content.number_of_credits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_content.number_of_credits IS 'Number of credits.';


--
-- Name: COLUMN credit_agreement_content.credit_agreement_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_content.credit_agreement_id IS 'Reference to primary key (id) of table credit_agreement';


--
-- Name: COLUMN credit_agreement_content.credit_class_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_content.credit_class_id IS 'Reference to primary key (id) of table credit_class_code';


--
-- Name: COLUMN credit_agreement_content.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_content.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: credit_agreement_content_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_agreement_content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_agreement_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_agreement_content_id_seq OWNED BY public.credit_agreement_content.id;


--
-- Name: credit_agreement_credit_transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_agreement_credit_transaction (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    credit_agreement_id integer NOT NULL,
    credit_transaction_id integer NOT NULL
);


--
-- Name: TABLE credit_agreement_credit_transaction; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_agreement_credit_transaction IS 'Contains the relationship between the credit agreement and credit transactions table.';


--
-- Name: COLUMN credit_agreement_credit_transaction.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_credit_transaction.id IS 'Primary key';


--
-- Name: COLUMN credit_agreement_credit_transaction.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_credit_transaction.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_agreement_credit_transaction.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_credit_transaction.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_agreement_credit_transaction.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_credit_transaction.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_agreement_credit_transaction.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_credit_transaction.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_agreement_credit_transaction.credit_agreement_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_credit_transaction.credit_agreement_id IS 'Reference to primary key (id) of table credit_agreement';


--
-- Name: COLUMN credit_agreement_credit_transaction.credit_transaction_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_credit_transaction.credit_transaction_id IS 'Reference to primary key (id) of table credit_transaction';


--
-- Name: credit_agreement_credit_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_agreement_credit_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_agreement_credit_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_agreement_credit_transaction_id_seq OWNED BY public.credit_agreement_credit_transaction.id;


--
-- Name: credit_agreement_file_attachment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_agreement_file_attachment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    filename character varying(260) NOT NULL,
    minio_object_name character varying(32) NOT NULL,
    size bigint NOT NULL,
    mime_type character varying(255),
    is_removed boolean NOT NULL,
    credit_agreement_id integer NOT NULL
);


--
-- Name: TABLE credit_agreement_file_attachment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_agreement_file_attachment IS 'Attachment information for the credit agreement.Contains information such as mime type, file size, and minio URL.';


--
-- Name: COLUMN credit_agreement_file_attachment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.id IS 'Primary key';


--
-- Name: COLUMN credit_agreement_file_attachment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_agreement_file_attachment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_agreement_file_attachment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_agreement_file_attachment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_agreement_file_attachment.filename; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.filename IS 'Filename from when it was in the user''s system.';


--
-- Name: COLUMN credit_agreement_file_attachment.minio_object_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.minio_object_name IS 'Object name in minio (UUID as a 32 hexadecimal string).';


--
-- Name: COLUMN credit_agreement_file_attachment.size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.size IS 'Size of the file in bytes.';


--
-- Name: COLUMN credit_agreement_file_attachment.mime_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.mime_type IS 'Mime type information of the file. (eg. application/pdf, image/gif, image/png, etc)';


--
-- Name: COLUMN credit_agreement_file_attachment.is_removed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.is_removed IS 'Whether it was marked as deleted';


--
-- Name: COLUMN credit_agreement_file_attachment.credit_agreement_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_file_attachment.credit_agreement_id IS 'Reference to primary key (id) of table credit_agreement';


--
-- Name: credit_agreement_file_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_agreement_file_attachment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_agreement_file_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_agreement_file_attachment_id_seq OWNED BY public.credit_agreement_file_attachment.id;


--
-- Name: credit_agreement_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_agreement_history (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    status character varying(20) NOT NULL,
    credit_agreement_id integer NOT NULL
);


--
-- Name: TABLE credit_agreement_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_agreement_history IS 'credit agreement history';


--
-- Name: COLUMN credit_agreement_history.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_history.id IS 'Primary key';


--
-- Name: COLUMN credit_agreement_history.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_history.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_agreement_history.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_history.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_agreement_history.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_history.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_agreement_history.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_history.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_agreement_history.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_history.status IS 'The validation status of this credit agreement. Status remains unchanged if the user is just adding a comment, but will generated a new record anyway.Valid statuses: [''DRAFT'', ''RECOMMENDED'', ''ISSUED'', ''DELETED'', ''RETURNED'']';


--
-- Name: COLUMN credit_agreement_history.credit_agreement_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_agreement_history.credit_agreement_id IS 'Reference to primary key (id) of table credit_agreement';


--
-- Name: credit_agreement_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_agreement_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_agreement_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_agreement_history_id_seq OWNED BY public.credit_agreement_history.id;


--
-- Name: credit_agreement_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_agreement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_agreement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_agreement_id_seq OWNED BY public.credit_agreement.id;


--
-- Name: credit_class_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_class_code (
    effective_date date,
    expiration_date date,
    credit_class character varying(3) NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_user character varying(130),
    id integer NOT NULL
);


--
-- Name: TABLE credit_class_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_class_code IS 'A lookup table for credit classes. Initially, A or B, but with room to expand later.';


--
-- Name: COLUMN credit_class_code.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_class_code.effective_date IS 'The calendar date the value became valid.';


--
-- Name: COLUMN credit_class_code.expiration_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_class_code.expiration_date IS 'The calendar date the value is no longer valid.';


--
-- Name: COLUMN credit_class_code.credit_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_class_code.credit_class IS 'Credit Class (eg A, B)';


--
-- Name: COLUMN credit_class_code.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_class_code.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_class_code.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_class_code.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_class_code.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_class_code.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_class_code.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_class_code.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_class_code.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_class_code.id IS 'Primary key';


--
-- Name: credit_class_code_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_class_code_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_class_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_class_code_id_seq OWNED BY public.credit_class_code.id;


--
-- Name: credit_transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_transaction (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    credit_value numeric(20,2) NOT NULL,
    transaction_timestamp timestamp with time zone NOT NULL,
    credit_to_id integer,
    debit_from_id integer,
    create_user character varying(130) NOT NULL,
    update_user character varying(130),
    credit_class_id integer NOT NULL,
    transaction_type_id integer NOT NULL,
    model_year_id integer NOT NULL,
    weight_class_id integer NOT NULL,
    number_of_credits integer NOT NULL,
    total_value numeric(20,2) NOT NULL
);


--
-- Name: TABLE credit_transaction; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_transaction IS 'A ledger of all recorded credit transactions from any source. Additionally used to calculate current balance.';


--
-- Name: COLUMN credit_transaction.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.id IS 'Primary key';


--
-- Name: COLUMN credit_transaction.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_transaction.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_transaction.credit_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.credit_value IS 'Credit value of the model when the submission was approved. For credit transfers, this will be the amount that is going to be added or subtracted from the organization. (since it supports decimals)';


--
-- Name: COLUMN credit_transaction.transaction_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.transaction_timestamp IS 'The timestamp at which the transaction was recorded';


--
-- Name: COLUMN credit_transaction.credit_to_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.credit_to_id IS 'Reference to primary key (id) of table organization';


--
-- Name: COLUMN credit_transaction.debit_from_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.debit_from_id IS 'Reference to primary key (id) of table organization';


--
-- Name: COLUMN credit_transaction.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_transaction.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_transaction.credit_class_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.credit_class_id IS 'Reference to primary key (id) of table credit_class_code';


--
-- Name: COLUMN credit_transaction.transaction_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.transaction_type_id IS 'Reference to primary key (id) of table credit_transaction_type';


--
-- Name: COLUMN credit_transaction.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN credit_transaction.weight_class_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.weight_class_id IS 'Reference to primary key (id) of table weight_class_code';


--
-- Name: COLUMN credit_transaction.number_of_credits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.number_of_credits IS 'Number of credits being transferred. For credit transfers this will always be 1.';


--
-- Name: COLUMN credit_transaction.total_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction.total_value IS 'calculated field: number of credits x credit value';


--
-- Name: credit_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_transaction_id_seq OWNED BY public.credit_transaction.id;


--
-- Name: credit_transaction_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_transaction_type (
    transaction_type character varying(50) NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_user character varying(130),
    id integer NOT NULL
);


--
-- Name: TABLE credit_transaction_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_transaction_type IS 'A lookup table for credit transaction types, since credits may be generated for multiple reasons';


--
-- Name: COLUMN credit_transaction_type.transaction_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction_type.transaction_type IS 'Transaction Type (eg Trade, Reduction, Grant)';


--
-- Name: COLUMN credit_transaction_type.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction_type.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_transaction_type.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction_type.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_transaction_type.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction_type.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_transaction_type.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction_type.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_transaction_type.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transaction_type.id IS 'Primary key';


--
-- Name: credit_transaction_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_transaction_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_transaction_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_transaction_type_id_seq OWNED BY public.credit_transaction_type.id;


--
-- Name: credit_transfer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_transfer (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    status character varying(20) NOT NULL,
    credit_to_id integer NOT NULL,
    debit_from_id integer NOT NULL
);


--
-- Name: TABLE credit_transfer; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_transfer IS 'A ledger of credit transfers between suppliers ';


--
-- Name: COLUMN credit_transfer.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer.id IS 'Primary key';


--
-- Name: COLUMN credit_transfer.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_transfer.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_transfer.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_transfer.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_transfer.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer.status IS 'The validation status of this transfer. Valid statuses: [''DRAFT'', ''SUBMITTED'', ''APPROVED'', ''DISAPPROVED'', ''RECOMMEND_APPROVAL'', ''RECOMMEND_REJECTION'', ''VALIDATED'', ''RESCIND_PRE_APPROVAL'', ''RESCINDED'', ''REJECTED'', ''DELETED'']';


--
-- Name: COLUMN credit_transfer.credit_to_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer.credit_to_id IS 'Reference to primary key (id) of table organization';


--
-- Name: COLUMN credit_transfer.debit_from_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer.debit_from_id IS 'Reference to primary key (id) of table organization';


--
-- Name: credit_transfer_comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_transfer_comment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    credit_transfer_comment character varying(4000),
    credit_transfer_history_id integer NOT NULL
);


--
-- Name: TABLE credit_transfer_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_transfer_comment IS 'Contains comments made about the Credit Transferfrom receiving partner to seller';


--
-- Name: COLUMN credit_transfer_comment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_comment.id IS 'Primary key';


--
-- Name: COLUMN credit_transfer_comment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_comment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_transfer_comment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_comment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_transfer_comment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_comment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_transfer_comment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_comment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_transfer_comment.credit_transfer_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_comment.credit_transfer_comment IS 'Comment left by supplier about sale';


--
-- Name: COLUMN credit_transfer_comment.credit_transfer_history_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_comment.credit_transfer_history_id IS 'Reference to primary key (id) of table credit_transfer_history';


--
-- Name: credit_transfer_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_transfer_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_transfer_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_transfer_comment_id_seq OWNED BY public.credit_transfer_comment.id;


--
-- Name: credit_transfer_content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_transfer_content (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    credit_transfer_id integer NOT NULL,
    credit_class_id integer NOT NULL,
    credit_value numeric(20,2) NOT NULL,
    dollar_value numeric(20,2) NOT NULL,
    model_year_id integer NOT NULL,
    weight_class_id integer NOT NULL
);


--
-- Name: TABLE credit_transfer_content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_transfer_content IS 'Contains the rows for the credit transfer.';


--
-- Name: COLUMN credit_transfer_content.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.id IS 'Primary key';


--
-- Name: COLUMN credit_transfer_content.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_transfer_content.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_transfer_content.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_transfer_content.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_transfer_content.credit_transfer_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.credit_transfer_id IS 'Reference to primary key (id) of table credit_transfer';


--
-- Name: COLUMN credit_transfer_content.credit_class_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.credit_class_id IS 'Reference to primary key (id) of table credit_class_code';


--
-- Name: COLUMN credit_transfer_content.credit_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.credit_value IS 'Amount of credits being transferred';


--
-- Name: COLUMN credit_transfer_content.dollar_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.dollar_value IS 'Value per credit in dollars';


--
-- Name: COLUMN credit_transfer_content.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN credit_transfer_content.weight_class_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_content.weight_class_id IS 'Reference to primary key (id) of table weight_class_code';


--
-- Name: credit_transfer_content_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_transfer_content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_transfer_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_transfer_content_id_seq OWNED BY public.credit_transfer_content.id;


--
-- Name: credit_transfer_credit_transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_transfer_credit_transaction (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    credit_transaction_id integer NOT NULL,
    credit_transfer_id integer NOT NULL
);


--
-- Name: TABLE credit_transfer_credit_transaction; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_transfer_credit_transaction IS 'Contains the relationship between the credit_transfer and credit transactions table.';


--
-- Name: COLUMN credit_transfer_credit_transaction.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_credit_transaction.id IS 'Primary key';


--
-- Name: COLUMN credit_transfer_credit_transaction.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_credit_transaction.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_transfer_credit_transaction.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_credit_transaction.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_transfer_credit_transaction.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_credit_transaction.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_transfer_credit_transaction.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_credit_transaction.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_transfer_credit_transaction.credit_transaction_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_credit_transaction.credit_transaction_id IS 'Reference to primary key (id) of table credit_transaction';


--
-- Name: COLUMN credit_transfer_credit_transaction.credit_transfer_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_credit_transaction.credit_transfer_id IS 'Reference to primary key (id) of table credit_transfer';


--
-- Name: credit_transfer_credit_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_transfer_credit_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_transfer_credit_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_transfer_credit_transaction_id_seq OWNED BY public.credit_transfer_credit_transaction.id;


--
-- Name: credit_transfer_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_transfer_history (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    status character varying(20) NOT NULL,
    transfer_id integer NOT NULL
);


--
-- Name: TABLE credit_transfer_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.credit_transfer_history IS 'credit transfer history';


--
-- Name: COLUMN credit_transfer_history.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_history.id IS 'Primary key';


--
-- Name: COLUMN credit_transfer_history.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_history.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN credit_transfer_history.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_history.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN credit_transfer_history.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_history.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN credit_transfer_history.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_history.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN credit_transfer_history.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_history.status IS 'The validation status of this credit transfer. Status remains unchanged if the user is just adding a comment, but will generated a new record anyway.Valid statuses: [''DRAFT'', ''SUBMITTED'', ''APPROVED'', ''DISAPPROVED'', ''RECOMMEND_APPROVAL'', ''RECOMMEND_REJECTION'', ''VALIDATED'', ''RESCIND_PRE_APPROVAL'', ''RESCINDED'', ''REJECTED'', ''DELETED'']';


--
-- Name: COLUMN credit_transfer_history.transfer_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.credit_transfer_history.transfer_id IS 'Reference to primary key (id) of table credit_transfer';


--
-- Name: credit_transfer_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_transfer_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_transfer_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_transfer_history_id_seq OWNED BY public.credit_transfer_history.id;


--
-- Name: credit_transfer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_transfer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_transfer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_transfer_id_seq OWNED BY public.credit_transfer.id;


--
-- Name: django_celery_beat_clockedschedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_celery_beat_clockedschedule (
    id integer NOT NULL,
    clocked_time timestamp with time zone NOT NULL,
    enabled boolean NOT NULL
);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_celery_beat_clockedschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_celery_beat_clockedschedule_id_seq OWNED BY public.django_celery_beat_clockedschedule.id;


--
-- Name: django_celery_beat_crontabschedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_celery_beat_crontabschedule (
    id integer NOT NULL,
    minute character varying(240) NOT NULL,
    hour character varying(96) NOT NULL,
    day_of_week character varying(64) NOT NULL,
    day_of_month character varying(124) NOT NULL,
    month_of_year character varying(64) NOT NULL,
    timezone character varying(63) NOT NULL
);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_celery_beat_crontabschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_celery_beat_crontabschedule_id_seq OWNED BY public.django_celery_beat_crontabschedule.id;


--
-- Name: django_celery_beat_intervalschedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_celery_beat_intervalschedule (
    id integer NOT NULL,
    every integer NOT NULL,
    period character varying(24) NOT NULL
);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_celery_beat_intervalschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_celery_beat_intervalschedule_id_seq OWNED BY public.django_celery_beat_intervalschedule.id;


--
-- Name: django_celery_beat_periodictask; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_celery_beat_periodictask (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    task character varying(200) NOT NULL,
    args text NOT NULL,
    kwargs text NOT NULL,
    queue character varying(200),
    exchange character varying(200),
    routing_key character varying(200),
    expires timestamp with time zone,
    enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    total_run_count integer NOT NULL,
    date_changed timestamp with time zone NOT NULL,
    description text NOT NULL,
    crontab_id integer,
    interval_id integer,
    solar_id integer,
    one_off boolean NOT NULL,
    start_time timestamp with time zone,
    priority integer,
    headers text NOT NULL,
    clocked_id integer,
    CONSTRAINT django_celery_beat_periodictask_priority_check CHECK ((priority >= 0)),
    CONSTRAINT django_celery_beat_periodictask_total_run_count_check CHECK ((total_run_count >= 0))
);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_celery_beat_periodictask_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_celery_beat_periodictask_id_seq OWNED BY public.django_celery_beat_periodictask.id;


--
-- Name: django_celery_beat_periodictasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_celery_beat_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


--
-- Name: django_celery_beat_solarschedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_celery_beat_solarschedule (
    id integer NOT NULL,
    event character varying(24) NOT NULL,
    latitude numeric(9,6) NOT NULL,
    longitude numeric(9,6) NOT NULL
);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_celery_beat_solarschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_celery_beat_solarschedule_id_seq OWNED BY public.django_celery_beat_solarschedule.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: TABLE django_migrations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.django_migrations IS 'Used to track Django database migration state';


--
-- Name: COLUMN django_migrations.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.django_migrations.name IS 'The filename containing the related migration';


--
-- Name: COLUMN django_migrations.applied; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.django_migrations.applied IS 'Flag. True if this migration was applied successfully';


--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: fixture_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fixture_migrations (
    id integer NOT NULL,
    fixture_filename character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: fixture_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fixture_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fixture_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fixture_migrations_id_seq OWNED BY public.fixture_migrations.id;


--
-- Name: icbc_registration_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.icbc_registration_data (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    vin character varying(20) NOT NULL,
    icbc_vehicle_id integer NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130),
    icbc_upload_date_id integer NOT NULL
);


--
-- Name: TABLE icbc_registration_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.icbc_registration_data IS 'Contains records of BC vehicle registrations, as provided by ICBC. This data is typically provided/loaded quarterly and is used to verify a supplier’s submission for ZEV sales credits.';


--
-- Name: COLUMN icbc_registration_data.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_registration_data.id IS 'Primary key';


--
-- Name: COLUMN icbc_registration_data.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_registration_data.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN icbc_registration_data.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_registration_data.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN icbc_registration_data.vin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_registration_data.vin IS 'A Vehicle Identification Number, a standard 17-character identifier  used in the automative industry to identify origin, colour, style, serial number, and other attributes (encoding is manufacturer-specific)';


--
-- Name: COLUMN icbc_registration_data.icbc_vehicle_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_registration_data.icbc_vehicle_id IS 'Reference to primary key (id) of table icbc_vehicle';


--
-- Name: COLUMN icbc_registration_data.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_registration_data.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN icbc_registration_data.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_registration_data.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN icbc_registration_data.icbc_upload_date_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_registration_data.icbc_upload_date_id IS 'Reference to primary key (id) of table icbc_upload_date';


--
-- Name: icbc_registration_data_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.icbc_registration_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: icbc_registration_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.icbc_registration_data_id_seq OWNED BY public.icbc_registration_data.id;


--
-- Name: icbc_snapshot_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.icbc_snapshot_data (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    vin character varying(20) NOT NULL,
    make character varying(250) NOT NULL,
    model_name character varying(250) NOT NULL,
    model_year character varying(250) NOT NULL,
    upload_date date NOT NULL,
    submission_id integer NOT NULL
);


--
-- Name: TABLE icbc_snapshot_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.icbc_snapshot_data IS 'Used as a reference for the record of sales. This is so we know what the value was when the row was validated.';


--
-- Name: COLUMN icbc_snapshot_data.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.id IS 'Primary key';


--
-- Name: COLUMN icbc_snapshot_data.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN icbc_snapshot_data.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN icbc_snapshot_data.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN icbc_snapshot_data.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN icbc_snapshot_data.vin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.vin IS 'A Vehicle Identification Number, a standard 17-character identifier  used in the automative industry to identify origin, colour, style, serial number, and other attributes (encoding is manufacturer-specific)';


--
-- Name: COLUMN icbc_snapshot_data.make; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.make IS 'The make of vehicleeg Toyota, Honda, Mitsubishi';


--
-- Name: COLUMN icbc_snapshot_data.model_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.model_name IS 'Model and trim of vehicle';


--
-- Name: COLUMN icbc_snapshot_data.model_year; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.model_year IS 'Model Year of the vehicle that''s in the ICBC data';


--
-- Name: COLUMN icbc_snapshot_data.upload_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.upload_date IS 'Upload date of the ICBC data';


--
-- Name: COLUMN icbc_snapshot_data.submission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_snapshot_data.submission_id IS 'Reference to primary key (id) of table sales_submission';


--
-- Name: icbc_snapshot_data_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.icbc_snapshot_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: icbc_snapshot_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.icbc_snapshot_data_id_seq OWNED BY public.icbc_snapshot_data.id;


--
-- Name: icbc_upload_date; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.icbc_upload_date (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    upload_date date NOT NULL,
    filename character varying(500)
);


--
-- Name: TABLE icbc_upload_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.icbc_upload_date IS 'contains a record for each time that the icbc file is         uploaded, with the date current to as specified by the user';


--
-- Name: COLUMN icbc_upload_date.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_upload_date.id IS 'Primary key';


--
-- Name: COLUMN icbc_upload_date.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_upload_date.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN icbc_upload_date.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_upload_date.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN icbc_upload_date.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_upload_date.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN icbc_upload_date.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_upload_date.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN icbc_upload_date.upload_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_upload_date.upload_date IS 'the date the icbc data is current to';


--
-- Name: COLUMN icbc_upload_date.filename; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_upload_date.filename IS 'Filename of the uploaded data';


--
-- Name: icbc_upload_date_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.icbc_upload_date_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: icbc_upload_date_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.icbc_upload_date_id_seq OWNED BY public.icbc_upload_date.id;


--
-- Name: icbc_vehicle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.icbc_vehicle (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    model_name character varying(250) NOT NULL,
    make character varying(250) NOT NULL,
    model_year_id integer NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130)
);


--
-- Name: TABLE icbc_vehicle; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.icbc_vehicle IS 'all vehicle models that have been added from icbc registration spreadsheet.';


--
-- Name: COLUMN icbc_vehicle.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_vehicle.id IS 'Primary key';


--
-- Name: COLUMN icbc_vehicle.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_vehicle.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN icbc_vehicle.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_vehicle.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN icbc_vehicle.model_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_vehicle.model_name IS 'Model and trim of vehicle';


--
-- Name: COLUMN icbc_vehicle.make; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_vehicle.make IS 'The make of vehicleeg Toyota, Honda, Mitsubishi';


--
-- Name: COLUMN icbc_vehicle.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_vehicle.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN icbc_vehicle.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_vehicle.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN icbc_vehicle.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.icbc_vehicle.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: icbc_vehicle_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.icbc_vehicle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: icbc_vehicle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.icbc_vehicle_id_seq OWNED BY public.icbc_vehicle.id;


--
-- Name: model_year; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    effective_date date,
    expiration_date date,
    description character varying(250) NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130)
);


--
-- Name: TABLE model_year; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year IS 'A year that is used by a manufacturer as a model year shall (a) if the period of production of a model of vehicle or engine does not include January 1 of a calendar year, correspond to the calendar year during which the period of production falls; or (b) if the period of production of a model of vehicle or engine includes January 1 of a calendar year, correspond to that calendar year. The period of production of a model of vehicle or engine shall include only one January 1. Contains unique values.';


--
-- Name: COLUMN model_year.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year.id IS 'Primary key';


--
-- Name: COLUMN model_year.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year.effective_date IS 'The calendar date the value became valid.';


--
-- Name: COLUMN model_year.expiration_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year.expiration_date IS 'The calendar date the value is no longer valid.';


--
-- Name: COLUMN model_year.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year.description IS 'Displayed name for the lookup value. Contains unique values.';


--
-- Name: COLUMN model_year.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: model_year_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_id_seq OWNED BY public.model_year.id;


--
-- Name: model_year_report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    organization_name character varying(500) NOT NULL,
    supplier_class character varying(1),
    validation_status character varying(20) NOT NULL,
    model_year_id integer NOT NULL,
    organization_id integer NOT NULL,
    credit_reduction_selection character varying(1)
);


--
-- Name: TABLE model_year_report; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report IS 'Model Year Report contains details of light duty vehicle sales as submitted by the supplier each model year in order to demonstrate regulatory compliance.';


--
-- Name: COLUMN model_year_report.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.id IS 'Primary key';


--
-- Name: COLUMN model_year_report.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report.organization_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.organization_name IS 'Name of the organization when the report was generated';


--
-- Name: COLUMN model_year_report.supplier_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.supplier_class IS 'Supplier Class: S - Small, M - Medium, L - Large';


--
-- Name: COLUMN model_year_report.validation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.validation_status IS 'The validation status of this model year report. Valid statuses: [''DRAFT'', ''SUBMITTED'', ''RECOMMENDED'', ''RETURNED'', ''ASSESSED'', ''REASSESSED'', ''DELETED'']';


--
-- Name: COLUMN model_year_report.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN model_year_report.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.organization_id IS 'Reference to primary key (id) of table organization';


--
-- Name: COLUMN model_year_report.credit_reduction_selection; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report.credit_reduction_selection IS 'Which ZEV credit class to use first for unspecified reductions. (A or B)';


--
-- Name: model_year_report_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_address (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    representative_name character varying(100),
    address_line_1 character varying(500),
    address_line_2 character varying(100),
    address_line_3 character varying(100),
    city character varying(100),
    postal_code character varying(10),
    state character varying(50),
    county character varying(50),
    country character varying(100),
    other character varying(100),
    address_type_id integer NOT NULL,
    model_year_report_id integer NOT NULL
);


--
-- Name: TABLE model_year_report_address; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_address IS 'Supplier addresses available during the time the report was created.';


--
-- Name: COLUMN model_year_report_address.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_address.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_address.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_address.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_address.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_address.representative_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.representative_name IS 'optional name of representative (eg attorney)';


--
-- Name: COLUMN model_year_report_address.address_line_1; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.address_line_1 IS 'The first line of the organization''s address';


--
-- Name: COLUMN model_year_report_address.address_line_2; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.address_line_2 IS 'The second line of the organization''s address';


--
-- Name: COLUMN model_year_report_address.address_line_3; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.address_line_3 IS 'The third line of the organization''s address';


--
-- Name: COLUMN model_year_report_address.city; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.city IS 'City';


--
-- Name: COLUMN model_year_report_address.postal_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.postal_code IS 'Postal Code';


--
-- Name: COLUMN model_year_report_address.state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.state IS 'State or Province';


--
-- Name: COLUMN model_year_report_address.county; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.county IS 'County Name';


--
-- Name: COLUMN model_year_report_address.country; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.country IS 'Country';


--
-- Name: COLUMN model_year_report_address.other; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.other IS 'Other Address Details';


--
-- Name: COLUMN model_year_report_address.address_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.address_type_id IS 'Reference to primary key (id) of table address_type';


--
-- Name: COLUMN model_year_report_address.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_address.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: model_year_report_address_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_address_id_seq OWNED BY public.model_year_report_address.id;


--
-- Name: model_year_report_adjustment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_adjustment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    number_of_credits integer NOT NULL,
    is_reduction boolean NOT NULL,
    credit_class_id integer NOT NULL,
    model_year_id integer NOT NULL,
    model_year_report_id integer NOT NULL
);


--
-- Name: TABLE model_year_report_adjustment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_adjustment IS 'Adjustments that the government user is making to the report.';


--
-- Name: COLUMN model_year_report_adjustment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_adjustment.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_adjustment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_adjustment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_adjustment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_adjustment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_adjustment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_adjustment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_adjustment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_adjustment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_adjustment.number_of_credits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_adjustment.number_of_credits IS 'Number of credits that the report is being adjusted to.';


--
-- Name: COLUMN model_year_report_adjustment.is_reduction; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_adjustment.is_reduction IS 'Flag. True if it''s a reduction. Otherwise, it''s an allocation ';


--
-- Name: COLUMN model_year_report_adjustment.credit_class_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_adjustment.credit_class_id IS 'Reference to primary key (id) of table credit_class_code';


--
-- Name: COLUMN model_year_report_adjustment.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_adjustment.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN model_year_report_adjustment.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_adjustment.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: model_year_report_adjustment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_adjustment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_adjustment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_adjustment_id_seq OWNED BY public.model_year_report_adjustment.id;


--
-- Name: model_year_report_assessment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_assessment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    penalty numeric(20,2),
    model_year_report_id integer NOT NULL,
    model_year_report_assessment_description_id integer NOT NULL,
    display boolean NOT NULL
);


--
-- Name: TABLE model_year_report_assessment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_assessment IS 'Contains Model Year Assessment description as selectedby analyst and penalty amount if applicable';


--
-- Name: COLUMN model_year_report_assessment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_assessment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_assessment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_assessment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_assessment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_assessment.penalty; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment.penalty IS 'amount of administrative penalty';


--
-- Name: COLUMN model_year_report_assessment.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: COLUMN model_year_report_assessment.model_year_report_assessment_description_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment.model_year_report_assessment_description_id IS 'Reference to primary key (id) of table model_year_report_assessment_descriptions';


--
-- Name: COLUMN model_year_report_assessment.display; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment.display IS 'field to determine if we should display this info';


--
-- Name: model_year_report_assessment_comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_assessment_comment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    to_director boolean NOT NULL,
    assessment_comment text,
    model_year_report_id integer NOT NULL,
    display boolean NOT NULL
);


--
-- Name: TABLE model_year_report_assessment_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_assessment_comment IS 'Contains comments made about the Model Year Assessmentfrom analyst to director and from analyst to supplier';


--
-- Name: COLUMN model_year_report_assessment_comment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_comment.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_assessment_comment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_comment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_assessment_comment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_comment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_assessment_comment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_comment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_assessment_comment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_comment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_assessment_comment.to_director; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_comment.to_director IS 'determines if comment is meant for director';


--
-- Name: COLUMN model_year_report_assessment_comment.assessment_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_comment.assessment_comment IS 'Comment left by idir about model year report';


--
-- Name: COLUMN model_year_report_assessment_comment.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_comment.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: COLUMN model_year_report_assessment_comment.display; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_comment.display IS 'field to determine if we should display this info';


--
-- Name: model_year_report_assessment_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_assessment_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_assessment_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_assessment_comment_id_seq OWNED BY public.model_year_report_assessment_comment.id;


--
-- Name: model_year_report_assessment_descriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_assessment_descriptions (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    assessment_description character varying(4000),
    display_order integer NOT NULL
);


--
-- Name: TABLE model_year_report_assessment_descriptions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_assessment_descriptions IS 'a lookup table for descriptions of the assessmentradio options';


--
-- Name: COLUMN model_year_report_assessment_descriptions.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_descriptions.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_assessment_descriptions.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_descriptions.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_assessment_descriptions.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_descriptions.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_assessment_descriptions.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_descriptions.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_assessment_descriptions.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_descriptions.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_assessment_descriptions.assessment_description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_descriptions.assessment_description IS 'descriptions of the assessment radio options';


--
-- Name: COLUMN model_year_report_assessment_descriptions.display_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_assessment_descriptions.display_order IS 'Sort order of the items.';


--
-- Name: model_year_report_assessment_descriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_assessment_descriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_assessment_descriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_assessment_descriptions_id_seq OWNED BY public.model_year_report_assessment_descriptions.id;


--
-- Name: model_year_report_assessment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_assessment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_assessment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_assessment_id_seq OWNED BY public.model_year_report_assessment.id;


--
-- Name: model_year_report_compliance_obligation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_compliance_obligation (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    credit_a_value numeric(20,2) NOT NULL,
    credit_b_value numeric(20,2) NOT NULL,
    category character varying(100),
    model_year_id integer NOT NULL,
    model_year_report_id integer NOT NULL,
    from_gov boolean NOT NULL,
    reduction_value numeric(20,2)
);


--
-- Name: TABLE model_year_report_compliance_obligation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_compliance_obligation IS 'Table to record compliance obligation and creditactivity information for the model year report';


--
-- Name: COLUMN model_year_report_compliance_obligation.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_compliance_obligation.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_compliance_obligation.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_compliance_obligation.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_compliance_obligation.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_compliance_obligation.credit_a_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.credit_a_value IS 'Value of credit A';


--
-- Name: COLUMN model_year_report_compliance_obligation.credit_b_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.credit_b_value IS 'Value of credit B';


--
-- Name: COLUMN model_year_report_compliance_obligation.category; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.category IS 'Category (eg. CREDIT_BALANCE_START. CREDITS_ISSUED_ZEV_SALES, CREDITS_IN, CREDITS_OUT, CREDIT_BALANCE_END, CREDIT_BALANCE_END, CREDIT_BALANCE_PROVISIONAL)';


--
-- Name: COLUMN model_year_report_compliance_obligation.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN model_year_report_compliance_obligation.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: COLUMN model_year_report_compliance_obligation.from_gov; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.from_gov IS 'Flag. True if this edit came from a government user.';


--
-- Name: COLUMN model_year_report_compliance_obligation.reduction_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_compliance_obligation.reduction_value IS 'Reduction value';


--
-- Name: model_year_report_compliance_obligation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_compliance_obligation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_compliance_obligation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_compliance_obligation_id_seq OWNED BY public.model_year_report_compliance_obligation.id;


--
-- Name: model_year_report_confirmation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_confirmation (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    has_accepted boolean NOT NULL,
    title character varying(100),
    model_year_report_id integer,
    signing_authority_assertion_id integer NOT NULL
);


--
-- Name: TABLE model_year_report_confirmation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_confirmation IS 'Contains a history of assertions having been accepted by the bceid user for model year reports.';


--
-- Name: COLUMN model_year_report_confirmation.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_confirmation.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_confirmation.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_confirmation.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_confirmation.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_confirmation.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_confirmation.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_confirmation.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_confirmation.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_confirmation.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_confirmation.has_accepted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_confirmation.has_accepted IS 'Flag. True if the associated confirmation was accepted.';


--
-- Name: COLUMN model_year_report_confirmation.title; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_confirmation.title IS 'Title of the user who acccepted the assertion.';


--
-- Name: COLUMN model_year_report_confirmation.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_confirmation.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: COLUMN model_year_report_confirmation.signing_authority_assertion_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_confirmation.signing_authority_assertion_id IS 'Reference to primary key (id) of table signing_authority_assertion';


--
-- Name: model_year_report_confirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_confirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_confirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_confirmation_id_seq OWNED BY public.model_year_report_confirmation.id;


--
-- Name: model_year_report_credit_offset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_credit_offset (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    credit_a_offset_value numeric(20,2) NOT NULL,
    credit_b_offset_value numeric(20,2) NOT NULL,
    model_year_id integer NOT NULL,
    model_year_report_id integer NOT NULL
);


--
-- Name: TABLE model_year_report_credit_offset; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_credit_offset IS 'Table to store credit offset values for the obligation and credit activity for the model year report';


--
-- Name: COLUMN model_year_report_credit_offset.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_offset.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_credit_offset.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_offset.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_credit_offset.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_offset.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_credit_offset.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_offset.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_credit_offset.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_offset.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_credit_offset.credit_a_offset_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_offset.credit_a_offset_value IS 'Value of credit A offset';


--
-- Name: COLUMN model_year_report_credit_offset.credit_b_offset_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_offset.credit_b_offset_value IS 'Value of credit B offset';


--
-- Name: COLUMN model_year_report_credit_offset.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_offset.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN model_year_report_credit_offset.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_offset.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: model_year_report_credit_offset_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_credit_offset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_credit_offset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_credit_offset_id_seq OWNED BY public.model_year_report_credit_offset.id;


--
-- Name: model_year_report_credit_transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_credit_transaction (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    credit_transaction_id integer NOT NULL,
    model_year_report_id integer NOT NULL
);


--
-- Name: TABLE model_year_report_credit_transaction; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_credit_transaction IS 'Contains the relationship between the model year report and credit transactions table.';


--
-- Name: COLUMN model_year_report_credit_transaction.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_transaction.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_credit_transaction.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_transaction.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_credit_transaction.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_transaction.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_credit_transaction.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_transaction.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_credit_transaction.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_transaction.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_credit_transaction.credit_transaction_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_transaction.credit_transaction_id IS 'Reference to primary key (id) of table credit_transaction';


--
-- Name: COLUMN model_year_report_credit_transaction.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_credit_transaction.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: model_year_report_credit_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_credit_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_credit_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_credit_transaction_id_seq OWNED BY public.model_year_report_credit_transaction.id;


--
-- Name: model_year_report_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_history (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    validation_status character varying(20) NOT NULL,
    model_year_report_id integer NOT NULL
);


--
-- Name: TABLE model_year_report_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_history IS 'history of model year report statuses';


--
-- Name: COLUMN model_year_report_history.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_history.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_history.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_history.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_history.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_history.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_history.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_history.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_history.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_history.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_history.validation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_history.validation_status IS 'The validation status of this model year report. Valid statuses: [''DRAFT'', ''SUBMITTED'', ''RECOMMENDED'', ''RETURNED'', ''ASSESSED'', ''REASSESSED'', ''DELETED'']';


--
-- Name: COLUMN model_year_report_history.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_history.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: model_year_report_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_history_id_seq OWNED BY public.model_year_report_history.id;


--
-- Name: model_year_report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_id_seq OWNED BY public.model_year_report.id;


--
-- Name: model_year_report_ldv_sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_ldv_sales (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    ldv_sales integer NOT NULL,
    from_gov boolean NOT NULL,
    model_year_id integer NOT NULL,
    model_year_report_id integer NOT NULL,
    display boolean NOT NULL
);


--
-- Name: TABLE model_year_report_ldv_sales; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_ldv_sales IS 'Table to store LDV Sales/Leases by year';


--
-- Name: COLUMN model_year_report_ldv_sales.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_ldv_sales.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_ldv_sales.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_ldv_sales.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_ldv_sales.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_ldv_sales.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_ldv_sales.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_ldv_sales.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_ldv_sales.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_ldv_sales.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_ldv_sales.ldv_sales; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_ldv_sales.ldv_sales IS 'Contains the LDV sales/leases data based on model year.';


--
-- Name: COLUMN model_year_report_ldv_sales.from_gov; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_ldv_sales.from_gov IS 'Flag. True if this edit came from a government user.';


--
-- Name: COLUMN model_year_report_ldv_sales.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_ldv_sales.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN model_year_report_ldv_sales.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_ldv_sales.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: COLUMN model_year_report_ldv_sales.display; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_ldv_sales.display IS 'field to determine if we should display this info';


--
-- Name: model_year_report_ldv_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_ldv_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_ldv_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_ldv_sales_id_seq OWNED BY public.model_year_report_ldv_sales.id;


--
-- Name: model_year_report_make; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_make (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    make character varying(250) NOT NULL,
    model_year_report_id integer NOT NULL,
    from_gov boolean NOT NULL,
    display boolean NOT NULL
);


--
-- Name: TABLE model_year_report_make; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_make IS 'Makes that are involved for the model year report.';


--
-- Name: COLUMN model_year_report_make.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_make.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_make.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_make.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_make.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_make.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_make.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_make.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_make.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_make.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_make.make; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_make.make IS 'The make of vehicleeg Toyota, Honda, Mitsubishi';


--
-- Name: COLUMN model_year_report_make.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_make.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: COLUMN model_year_report_make.from_gov; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_make.from_gov IS 'Flag. True if this edit came from a government user.';


--
-- Name: COLUMN model_year_report_make.display; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_make.display IS 'field to determine if we should display this info';


--
-- Name: model_year_report_make_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_make_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_make_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_make_id_seq OWNED BY public.model_year_report_make.id;


--
-- Name: model_year_report_vehicle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_year_report_vehicle (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    pending_sales integer NOT NULL,
    sales_issued integer NOT NULL,
    make character varying(250) NOT NULL,
    model_name character varying(250) NOT NULL,
    range numeric(20,2) NOT NULL,
    model_year_id integer NOT NULL,
    zev_class_id integer NOT NULL,
    vehicle_zev_type_id integer NOT NULL,
    model_year_report_id integer NOT NULL
);


--
-- Name: TABLE model_year_report_vehicle; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_year_report_vehicle IS 'Table to store ZEV vehicle information based on model year';


--
-- Name: COLUMN model_year_report_vehicle.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.id IS 'Primary key';


--
-- Name: COLUMN model_year_report_vehicle.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN model_year_report_vehicle.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN model_year_report_vehicle.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN model_year_report_vehicle.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN model_year_report_vehicle.pending_sales; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.pending_sales IS 'Sum of pending sales for zev models';


--
-- Name: COLUMN model_year_report_vehicle.sales_issued; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.sales_issued IS 'Sum of issued sales for zev models';


--
-- Name: COLUMN model_year_report_vehicle.make; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.make IS 'Make of vehicle';


--
-- Name: COLUMN model_year_report_vehicle.model_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.model_name IS 'Model of vehicle';


--
-- Name: COLUMN model_year_report_vehicle.range; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.range IS 'vehicle range in km';


--
-- Name: COLUMN model_year_report_vehicle.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN model_year_report_vehicle.zev_class_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.zev_class_id IS 'Reference to primary key (id) of table credit_class_code';


--
-- Name: COLUMN model_year_report_vehicle.vehicle_zev_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.vehicle_zev_type_id IS 'Reference to primary key (id) of table vehicle_zev_type';


--
-- Name: COLUMN model_year_report_vehicle.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_year_report_vehicle.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: model_year_report_vehicle_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_year_report_vehicle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_year_report_vehicle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_year_report_vehicle_id_seq OWNED BY public.model_year_report_vehicle.id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    notification_code character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(1000) NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: TABLE notification; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.notification IS 'Contains information about the different notification types and which user(IDIR or Supplier) can get that notification';


--
-- Name: COLUMN notification.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification.id IS 'Primary key';


--
-- Name: COLUMN notification.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN notification.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN notification.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN notification.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN notification.notification_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification.notification_code IS 'Notification code. Natural key.';


--
-- Name: COLUMN notification.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification.name IS 'Short description of the notification.';


--
-- Name: COLUMN notification.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification.description IS 'More detailed description of the notification.';


--
-- Name: COLUMN notification.permission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification.permission_id IS 'Reference to primary key (id) of table permission';


--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_id_seq OWNED BY public.notification.id;


--
-- Name: notification_subscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_subscription (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    notification_id integer NOT NULL,
    user_profile_id integer NOT NULL
);


--
-- Name: TABLE notification_subscription; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.notification_subscription IS 'Relationship table between the users and notification';


--
-- Name: COLUMN notification_subscription.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_subscription.id IS 'Primary key';


--
-- Name: COLUMN notification_subscription.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_subscription.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN notification_subscription.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_subscription.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN notification_subscription.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_subscription.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN notification_subscription.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_subscription.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN notification_subscription.notification_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_subscription.notification_id IS 'Reference to primary key (id) of table notification';


--
-- Name: COLUMN notification_subscription.user_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_subscription.user_profile_id IS 'Reference to primary key (id) of table user_profile';


--
-- Name: notification_subscription_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_subscription_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_subscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_subscription_id_seq OWNED BY public.notification_subscription.id;


--
-- Name: organization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    organization_name character varying(500) NOT NULL,
    is_government boolean NOT NULL,
    is_active boolean NOT NULL,
    short_name character varying(64),
    create_user character varying(130) NOT NULL,
    update_user character varying(130),
    first_model_year_id integer
);


--
-- Name: TABLE organization; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.organization IS 'Contains a list of all of the recognized Vehicle suppliers, both past and present, as well as an entry for the government which is also considered an organization.';


--
-- Name: COLUMN organization.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.id IS 'Primary key';


--
-- Name: COLUMN organization.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN organization.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN organization.organization_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.organization_name IS 'Name of the organization';


--
-- Name: COLUMN organization.is_government; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.is_government IS 'Flag to check whether this is the Government organization';


--
-- Name: COLUMN organization.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.is_active IS 'Boolean Field to see if the organization is disabled or not.';


--
-- Name: COLUMN organization.short_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.short_name IS 'Short version of the organization name, used in generating some reports';


--
-- Name: COLUMN organization.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN organization.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN organization.first_model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.first_model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: organization_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_address (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    effective_date date,
    expiration_date date,
    address_line_1 character varying(500),
    address_line_2 character varying(100),
    address_line_3 character varying(100),
    city character varying(100),
    postal_code character varying(10),
    state character varying(50),
    county character varying(50),
    country character varying(100),
    other character varying(100),
    organization_id integer NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130),
    address_type_id integer NOT NULL,
    representative_name character varying(100)
);


--
-- Name: TABLE organization_address; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.organization_address IS 'Represents an organization''s address.';


--
-- Name: COLUMN organization_address.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.id IS 'Primary key';


--
-- Name: COLUMN organization_address.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN organization_address.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN organization_address.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.effective_date IS 'The calendar date the value became valid.';


--
-- Name: COLUMN organization_address.expiration_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.expiration_date IS 'The calendar date the value is no longer valid.';


--
-- Name: COLUMN organization_address.address_line_1; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.address_line_1 IS 'The first line of the organization''s address';


--
-- Name: COLUMN organization_address.address_line_2; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.address_line_2 IS 'The second line of the organization''s address';


--
-- Name: COLUMN organization_address.address_line_3; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.address_line_3 IS 'The third line of the organization''s address';


--
-- Name: COLUMN organization_address.city; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.city IS 'City';


--
-- Name: COLUMN organization_address.postal_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.postal_code IS 'Postal Code';


--
-- Name: COLUMN organization_address.state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.state IS 'State or Province';


--
-- Name: COLUMN organization_address.county; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.county IS 'County Name';


--
-- Name: COLUMN organization_address.country; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.country IS 'Country';


--
-- Name: COLUMN organization_address.other; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.other IS 'Other Address Details';


--
-- Name: COLUMN organization_address.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.organization_id IS 'Reference to primary key (id) of table organization';


--
-- Name: COLUMN organization_address.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN organization_address.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN organization_address.address_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.address_type_id IS 'Reference to primary key (id) of table address_type';


--
-- Name: COLUMN organization_address.representative_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_address.representative_name IS 'optional name of representative (eg attorney)';


--
-- Name: organization_address_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organization_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organization_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organization_address_id_seq OWNED BY public.organization_address.id;


--
-- Name: organization_deficits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_deficits (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    credit_value numeric(20,2) NOT NULL,
    credit_class_id integer NOT NULL,
    model_year_id integer NOT NULL,
    organization_id integer NOT NULL
);


--
-- Name: TABLE organization_deficits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.organization_deficits IS 'Table to store the organization''s deficits';


--
-- Name: COLUMN organization_deficits.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_deficits.id IS 'Primary key';


--
-- Name: COLUMN organization_deficits.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_deficits.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN organization_deficits.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_deficits.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN organization_deficits.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_deficits.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN organization_deficits.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_deficits.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN organization_deficits.credit_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_deficits.credit_value IS 'Amount of credits in deficit';


--
-- Name: COLUMN organization_deficits.credit_class_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_deficits.credit_class_id IS 'Reference to primary key (id) of table credit_class_code';


--
-- Name: COLUMN organization_deficits.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_deficits.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN organization_deficits.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_deficits.organization_id IS 'Reference to primary key (id) of table organization';


--
-- Name: organization_deficits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organization_deficits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organization_deficits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organization_deficits_id_seq OWNED BY public.organization_deficits.id;


--
-- Name: organization_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organization_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organization_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organization_id_seq OWNED BY public.organization.id;


--
-- Name: organization_ldv_sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_ldv_sales (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    ldv_sales integer NOT NULL,
    model_year_id integer NOT NULL,
    organization_id integer NOT NULL,
    is_supplied boolean NOT NULL
);


--
-- Name: TABLE organization_ldv_sales; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.organization_ldv_sales IS 'Table to store the organization''s LDV Sales/Leases';


--
-- Name: COLUMN organization_ldv_sales.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_ldv_sales.id IS 'Primary key';


--
-- Name: COLUMN organization_ldv_sales.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_ldv_sales.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN organization_ldv_sales.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_ldv_sales.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN organization_ldv_sales.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_ldv_sales.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN organization_ldv_sales.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_ldv_sales.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN organization_ldv_sales.ldv_sales; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_ldv_sales.ldv_sales IS 'Contains the LDV sales/leases for the organization .circleci/categorized by year.';


--
-- Name: COLUMN organization_ldv_sales.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_ldv_sales.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN organization_ldv_sales.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_ldv_sales.organization_id IS 'Reference to primary key (id) of table organization';


--
-- Name: organization_ldv_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organization_ldv_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organization_ldv_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organization_ldv_sales_id_seq OWNED BY public.organization_ldv_sales.id;


--
-- Name: permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    permission_code character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(1000) NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130)
);


--
-- Name: TABLE permission; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.permission IS 'Contains the list of permissions to grant access to certain actions of areas for the system.';


--
-- Name: COLUMN permission.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permission.id IS 'Primary key';


--
-- Name: COLUMN permission.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permission.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN permission.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permission.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN permission.permission_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permission.permission_code IS 'Permission code. Natural key.';


--
-- Name: COLUMN permission.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permission.name IS 'Short description of the permission.eg User Management, View Credit Transactions, Sign a Credit Transfer Proposal, etc';


--
-- Name: COLUMN permission.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permission.description IS 'More detailed description of the permission.';


--
-- Name: COLUMN permission.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permission.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN permission.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permission.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permission_id_seq OWNED BY public.permission.id;


--
-- Name: record_of_sale; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.record_of_sale (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    reference_number character varying(255),
    vin character varying(20),
    vin_validation_status character varying(30) NOT NULL,
    sale_date date,
    validation_status character varying(20) NOT NULL,
    vehicle_id integer NOT NULL,
    submission_id integer NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130),
    icbc_snapshot_id integer
);


--
-- Name: TABLE record_of_sale; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.record_of_sale IS 'Hold individual records of sale submitted by ZEV suppliers, including their VIN, sales dates, and the workflow state information for this sale (VIN and record validation statuses)';


--
-- Name: COLUMN record_of_sale.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.id IS 'Primary key';


--
-- Name: COLUMN record_of_sale.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN record_of_sale.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN record_of_sale.reference_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.reference_number IS 'An (optional) vehicle-supplier-provided correlation ID';


--
-- Name: COLUMN record_of_sale.vin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.vin IS 'A Vehicle Identification Number, a standard 17-character identifier used in the automative industry to identify origin, colour, style, serial number, and other attributes (encoding is manufacturer-specific)';


--
-- Name: COLUMN record_of_sale.vin_validation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.vin_validation_status IS 'The validation status of the VIN. Valid statuses: [''UNCHECKED'', ''MATCHED'', ''EMPTY_VIN'', ''INVALID_VIN'', ''NOT_IN_PROVINCIAL_RECORDS'', ''PREVIOUSLY_MATCHED'', ''MODEL_MISMATCH'', ''MODELYEAR_MISMATCH'']';


--
-- Name: COLUMN record_of_sale.sale_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.sale_date IS 'The calendar date the vehicle was placed with an end customer';


--
-- Name: COLUMN record_of_sale.validation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.validation_status IS 'The validation status of this record of sale. Valid statuses: [''NEW'', ''DRAFT'', ''SUBMITTED'', ''VALIDATED'', ''REJECTED'', ''TRANSACTED'']';


--
-- Name: COLUMN record_of_sale.vehicle_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.vehicle_id IS 'Reference to primary key (id) of table vehicle';


--
-- Name: COLUMN record_of_sale.submission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.submission_id IS 'Reference to primary key (id) of table sales_submission';


--
-- Name: COLUMN record_of_sale.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN record_of_sale.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN record_of_sale.icbc_snapshot_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_of_sale.icbc_snapshot_id IS 'Reference to primary key (id) of table icbc_snapshot_data';


--
-- Name: record_of_sale_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.record_of_sale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: record_of_sale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.record_of_sale_id_seq OWNED BY public.record_of_sale.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    role_code character varying(200) NOT NULL,
    description character varying(1000) NOT NULL,
    is_government_role boolean NOT NULL,
    display_order integer NOT NULL,
    default_role boolean NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130)
);


--
-- Name: TABLE role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.role IS 'Table that will hold all the available Roles and descriptions.';


--
-- Name: COLUMN role.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role.id IS 'Primary key';


--
-- Name: COLUMN role.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN role.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN role.role_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role.role_code IS 'Role code. Natural key. Used internally.eg Admin, GovUser, GovDirector, etc';


--
-- Name: COLUMN role.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role.description IS 'Descriptive text explaining this role. This is what''s shown to the user.';


--
-- Name: COLUMN role.is_government_role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role.is_government_role IS 'Flag. True if this is a government role (eg. Analyst, Administrator)';


--
-- Name: COLUMN role.display_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role.display_order IS 'Relative rank in display sorting order';


--
-- Name: COLUMN role.default_role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role.default_role IS 'Flag. True if this will be a default role applied to a user if the user doesn''t have any other roles.';


--
-- Name: COLUMN role.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN role.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: role_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permission (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    permission_id integer NOT NULL,
    role_id integer NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130)
);


--
-- Name: TABLE role_permission; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.role_permission IS 'Relationship table between the roles and permissions.(ie what roles contain what permissions)';


--
-- Name: COLUMN role_permission.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role_permission.id IS 'Primary key';


--
-- Name: COLUMN role_permission.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role_permission.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN role_permission.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role_permission.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN role_permission.permission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role_permission.permission_id IS 'Reference to primary key (id) of table permission';


--
-- Name: COLUMN role_permission.role_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role_permission.role_id IS 'Reference to primary key (id) of table role';


--
-- Name: COLUMN role_permission.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role_permission.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN role_permission.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role_permission.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: role_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_permission_id_seq OWNED BY public.role_permission.id;


--
-- Name: sales_submission_content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_submission_content (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    xls_make character varying(255),
    xls_model character varying(255),
    xls_model_year character varying(255),
    xls_sale_date character varying(255),
    xls_vin character varying(255),
    submission_id integer NOT NULL,
    xls_date_mode smallint NOT NULL,
    xls_date_type smallint NOT NULL,
    reason character varying(255),
    warnings_list character varying(255),
    CONSTRAINT sale_submission_content_xls_date_mode_check CHECK ((xls_date_mode >= 0)),
    CONSTRAINT sale_submission_content_xls_date_type_check CHECK ((xls_date_type >= 0))
);


--
-- Name: TABLE sales_submission_content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sales_submission_content IS 'Holds the raw records for sale submission. This is so that we can look back into the  validation errors (if there are any) and show it to the users.';


--
-- Name: COLUMN sales_submission_content.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.id IS 'Primary key';


--
-- Name: COLUMN sales_submission_content.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN sales_submission_content.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN sales_submission_content.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN sales_submission_content.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN sales_submission_content.xls_make; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.xls_make IS 'Raw value of the Make from the spreadsheet';


--
-- Name: COLUMN sales_submission_content.xls_model; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.xls_model IS 'Raw value of the Vehicle Model from the spreadsheet';


--
-- Name: COLUMN sales_submission_content.xls_model_year; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.xls_model_year IS 'Raw value of the Model Year from the spreadsheet';


--
-- Name: COLUMN sales_submission_content.xls_sale_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.xls_sale_date IS 'Raw value of the Sales Date from the spreadsheet';


--
-- Name: COLUMN sales_submission_content.xls_vin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.xls_vin IS 'Raw value of the VIN from the spreadsheet';


--
-- Name: COLUMN sales_submission_content.submission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.submission_id IS 'Reference to primary key (id) of table sales_submission';


--
-- Name: COLUMN sales_submission_content.xls_date_mode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.xls_date_mode IS 'XLS date mode: 0: 1900-based, 1: 1904-based (only applies to XL_CELL_DATE)';


--
-- Name: COLUMN sales_submission_content.xls_date_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.xls_date_type IS 'Date Type: 1: XL_CELL_TEXT, 3: XL_CELL_DATE';


--
-- Name: COLUMN sales_submission_content.reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.reason IS 'Reason for overriding the initial assessment';


--
-- Name: COLUMN sales_submission_content.warnings_list; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content.warnings_list IS 'comma-separated list of warnings a VIN was flagged with';


--
-- Name: sale_submission_content_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_submission_content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sale_submission_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_submission_content_id_seq OWNED BY public.sales_submission_content.id;


--
-- Name: sales_submission_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_submission_evidence (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    filename character varying(260) NOT NULL,
    minio_object_name character varying(32) NOT NULL,
    size bigint NOT NULL,
    mime_type character varying(255),
    is_removed boolean NOT NULL,
    submission_id integer NOT NULL
);


--
-- Name: TABLE sales_submission_evidence; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sales_submission_evidence IS 'Attachment information for the sale submission.Contains information such as mime type, file size, and minio URL.';


--
-- Name: COLUMN sales_submission_evidence.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.id IS 'Primary key';


--
-- Name: COLUMN sales_submission_evidence.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN sales_submission_evidence.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN sales_submission_evidence.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN sales_submission_evidence.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN sales_submission_evidence.filename; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.filename IS 'Filename from when it was in the user''s system.';


--
-- Name: COLUMN sales_submission_evidence.minio_object_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.minio_object_name IS 'Object name in minio (UUID as a 32 hexadecimal string).';


--
-- Name: COLUMN sales_submission_evidence.size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.size IS 'Size of the file in bytes.';


--
-- Name: COLUMN sales_submission_evidence.mime_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.mime_type IS 'Mime type information of the file. (eg. application/pdf, image/gif, image/png, etc)';


--
-- Name: COLUMN sales_submission_evidence.is_removed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.is_removed IS 'Whether it was marked as deleted';


--
-- Name: COLUMN sales_submission_evidence.submission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_evidence.submission_id IS 'Reference to primary key (id) of table sales_submission';


--
-- Name: sale_submission_file_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_submission_file_attachment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sale_submission_file_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_submission_file_attachment_id_seq OWNED BY public.sales_submission_evidence.id;


--
-- Name: sales_forecast; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_forecast (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    ice_vehicles_one integer,
    ice_vehicles_two integer,
    ice_vehicles_three integer,
    zev_vehicles_one integer,
    zev_vehicles_two integer,
    zev_vehicles_three integer,
    model_year_report_id integer NOT NULL
);


--
-- Name: TABLE sales_forecast; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sales_forecast IS 'Stores sales forecast information';


--
-- Name: COLUMN sales_forecast.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast.id IS 'Primary key';


--
-- Name: COLUMN sales_forecast.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN sales_forecast.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN sales_forecast.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN sales_forecast.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN sales_forecast.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: sales_forecast_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_forecast_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_forecast_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_forecast_id_seq OWNED BY public.sales_forecast.id;


--
-- Name: sales_forecast_record; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_forecast_record (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    model_year character varying(4) NOT NULL,
    make character varying(250) NOT NULL,
    model_name character varying(250) NOT NULL,
    type character varying(10) NOT NULL,
    range numeric(20,2) NOT NULL,
    zev_class character varying(1) NOT NULL,
    vehicle_class_interior_volume character varying(250) NOT NULL,
    total_supplied integer NOT NULL,
    sales_forecast_id integer NOT NULL
);


--
-- Name: TABLE sales_forecast_record; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sales_forecast_record IS 'Stores sales forecast records';


--
-- Name: COLUMN sales_forecast_record.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast_record.id IS 'Primary key';


--
-- Name: COLUMN sales_forecast_record.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast_record.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN sales_forecast_record.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast_record.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN sales_forecast_record.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast_record.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN sales_forecast_record.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast_record.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN sales_forecast_record.sales_forecast_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_forecast_record.sales_forecast_id IS 'Reference to primary key (id) of table sales_forecast';


--
-- Name: sales_forecast_record_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_forecast_record_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_forecast_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_forecast_record_id_seq OWNED BY public.sales_forecast_record.id;


--
-- Name: sales_submission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_submission (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    submission_date date,
    validation_status character varying(20) NOT NULL,
    organization_id integer NOT NULL,
    submission_sequence integer,
    create_user character varying(130) NOT NULL,
    update_user character varying(130),
    filename character varying(260),
    part_of_model_year_report boolean
);


--
-- Name: TABLE sales_submission; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sales_submission IS 'Stores information related to batches of record of sales submissions (such as what the status of the submission, the date it was entered, and which organization submitted it.';


--
-- Name: COLUMN sales_submission.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.id IS 'Primary key';


--
-- Name: COLUMN sales_submission.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN sales_submission.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN sales_submission.submission_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.submission_date IS 'The calendar date the submission was created in ZEVA';


--
-- Name: COLUMN sales_submission.validation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.validation_status IS 'The validation status of this sales submission. Valid statuses: [''NEW'', ''DRAFT'', ''SUBMITTED'', ''VALIDATED'', ''REJECTED'', ''RECOMMEND_APPROVAL'', ''RECOMMEND_REJECTION'', ''DELETED'', ''CHECKED'']';


--
-- Name: COLUMN sales_submission.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.organization_id IS 'Reference to primary key (id) of table organization';


--
-- Name: COLUMN sales_submission.submission_sequence; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.submission_sequence IS 'A sequential integer for each (organization, submission_date) tuple, to create a unique reference number for the submission.';


--
-- Name: COLUMN sales_submission.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN sales_submission.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN sales_submission.filename; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.filename IS 'Filename of the spreadsheet. Just to help the users keep track of their submissions.';


--
-- Name: COLUMN sales_submission.part_of_model_year_report; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission.part_of_model_year_report IS 'determine if issue as Sept 30 as part of model year report.';


--
-- Name: sales_submission_comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_submission_comment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    sales_submission_comment character varying(4000),
    sales_submission_id integer NOT NULL,
    to_govt boolean NOT NULL
);


--
-- Name: TABLE sales_submission_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sales_submission_comment IS 'Contains comments made about the sales submissionbetween director and analyst and from analyst to supplier';


--
-- Name: COLUMN sales_submission_comment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_comment.id IS 'Primary key';


--
-- Name: COLUMN sales_submission_comment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_comment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN sales_submission_comment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_comment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN sales_submission_comment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_comment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN sales_submission_comment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_comment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN sales_submission_comment.sales_submission_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_comment.sales_submission_comment IS 'Comment left by director/analyst about sale';


--
-- Name: COLUMN sales_submission_comment.sales_submission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_comment.sales_submission_id IS 'Reference to primary key (id) of table sales_submission';


--
-- Name: COLUMN sales_submission_comment.to_govt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_comment.to_govt IS 'determines if comment is meant for government or supplier';


--
-- Name: sales_submission_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_submission_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_submission_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_submission_comment_id_seq OWNED BY public.sales_submission_comment.id;


--
-- Name: sales_submission_content_reason; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_submission_content_reason (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    reason character varying(255) NOT NULL
);


--
-- Name: TABLE sales_submission_content_reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sales_submission_content_reason IS 'Contains possible reasons for overriding the ICBC default status.';


--
-- Name: COLUMN sales_submission_content_reason.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content_reason.id IS 'Primary key';


--
-- Name: COLUMN sales_submission_content_reason.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content_reason.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN sales_submission_content_reason.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content_reason.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN sales_submission_content_reason.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content_reason.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN sales_submission_content_reason.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content_reason.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN sales_submission_content_reason.reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_content_reason.reason IS 'Reason why the assessment is being overriden.';


--
-- Name: sales_submission_content_reason_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_submission_content_reason_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_submission_content_reason_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_submission_content_reason_id_seq OWNED BY public.sales_submission_content_reason.id;


--
-- Name: sales_submission_credit_transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_submission_credit_transaction (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    credit_transaction_id integer NOT NULL,
    sales_submission_id integer NOT NULL
);


--
-- Name: TABLE sales_submission_credit_transaction; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sales_submission_credit_transaction IS 'Contains the relationship between the sales_submission and credit transactions table.';


--
-- Name: COLUMN sales_submission_credit_transaction.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_credit_transaction.id IS 'Primary key';


--
-- Name: COLUMN sales_submission_credit_transaction.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_credit_transaction.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN sales_submission_credit_transaction.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_credit_transaction.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN sales_submission_credit_transaction.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_credit_transaction.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN sales_submission_credit_transaction.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_credit_transaction.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN sales_submission_credit_transaction.credit_transaction_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_credit_transaction.credit_transaction_id IS 'Reference to primary key (id) of table credit_transaction';


--
-- Name: COLUMN sales_submission_credit_transaction.sales_submission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_credit_transaction.sales_submission_id IS 'Reference to primary key (id) of table sales_submission';


--
-- Name: sales_submission_credit_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_submission_credit_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_submission_credit_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_submission_credit_transaction_id_seq OWNED BY public.sales_submission_credit_transaction.id;


--
-- Name: sales_submission_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_submission_history (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    validation_status character varying(20) NOT NULL,
    submission_id integer NOT NULL
);


--
-- Name: TABLE sales_submission_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sales_submission_history IS 'history of sales submissions';


--
-- Name: COLUMN sales_submission_history.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_history.id IS 'Primary key';


--
-- Name: COLUMN sales_submission_history.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_history.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN sales_submission_history.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_history.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN sales_submission_history.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_history.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN sales_submission_history.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_history.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN sales_submission_history.validation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_history.validation_status IS 'The validation status of this sales submission. Valid statuses: [''NEW'', ''DRAFT'', ''SUBMITTED'', ''VALIDATED'', ''REJECTED'', ''RECOMMEND_APPROVAL'', ''RECOMMEND_REJECTION'', ''DELETED'', ''CHECKED'']';


--
-- Name: COLUMN sales_submission_history.submission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales_submission_history.submission_id IS 'Reference to primary key (id) of table sales_submission';


--
-- Name: sales_submission_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_submission_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_submission_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_submission_history_id_seq OWNED BY public.sales_submission_history.id;


--
-- Name: sales_submission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_submission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_submission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_submission_id_seq OWNED BY public.sales_submission.id;


--
-- Name: signing_authority_assertion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.signing_authority_assertion (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    effective_date date,
    expiration_date date,
    display_order integer NOT NULL,
    description character varying(4000),
    module character varying(50) NOT NULL
);


--
-- Name: TABLE signing_authority_assertion; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.signing_authority_assertion IS 'Contains a list of valid regulatory statements that must be confirmed or certified by the officer or employee of the vehicle supplier.';


--
-- Name: COLUMN signing_authority_assertion.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_assertion.id IS 'Primary key';


--
-- Name: COLUMN signing_authority_assertion.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_assertion.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN signing_authority_assertion.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_assertion.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN signing_authority_assertion.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_assertion.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN signing_authority_assertion.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_assertion.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN signing_authority_assertion.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_assertion.effective_date IS 'The calendar date the value became valid.';


--
-- Name: COLUMN signing_authority_assertion.expiration_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_assertion.expiration_date IS 'The calendar date the value is no longer valid.';


--
-- Name: COLUMN signing_authority_assertion.display_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_assertion.display_order IS 'Sort order of the items.';


--
-- Name: COLUMN signing_authority_assertion.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_assertion.description IS 'Description of the signing authority assertion statement. This is the displayed name.';


--
-- Name: COLUMN signing_authority_assertion.module; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_assertion.module IS 'Module that uses the assertion.e.g. Credit Transfer';


--
-- Name: signing_authority_assertion_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.signing_authority_assertion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: signing_authority_assertion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.signing_authority_assertion_id_seq OWNED BY public.signing_authority_assertion.id;


--
-- Name: signing_authority_confirmation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.signing_authority_confirmation (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    has_accepted boolean NOT NULL,
    title character varying(100),
    credit_transfer_id integer,
    signing_authority_assertion_id integer NOT NULL
);


--
-- Name: TABLE signing_authority_confirmation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.signing_authority_confirmation IS 'Contains a history of assertions having been accepted by the bceid user.';


--
-- Name: COLUMN signing_authority_confirmation.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_confirmation.id IS 'Primary key';


--
-- Name: COLUMN signing_authority_confirmation.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_confirmation.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN signing_authority_confirmation.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_confirmation.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN signing_authority_confirmation.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_confirmation.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN signing_authority_confirmation.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_confirmation.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN signing_authority_confirmation.has_accepted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_confirmation.has_accepted IS 'Flag. True if the associated confirmation was accepted.';


--
-- Name: COLUMN signing_authority_confirmation.title; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_confirmation.title IS 'Title of the user who acccepted the assertion.';


--
-- Name: COLUMN signing_authority_confirmation.credit_transfer_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_confirmation.credit_transfer_id IS 'Reference to primary key (id) of table credit_transfer';


--
-- Name: COLUMN signing_authority_confirmation.signing_authority_assertion_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signing_authority_confirmation.signing_authority_assertion_id IS 'Reference to primary key (id) of table signing_authority_assertion';


--
-- Name: signing_authority_confirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.signing_authority_confirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: signing_authority_confirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.signing_authority_confirmation_id_seq OWNED BY public.signing_authority_confirmation.id;


--
-- Name: supplemental_report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplemental_report (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    status character varying(20) NOT NULL,
    model_year_report_id integer NOT NULL,
    ldv_sales integer,
    supplemental_id integer
);


--
-- Name: TABLE supplemental_report; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.supplemental_report IS 'Supplemental report table containesreference to the original model yearreport and it will be used as the referencefor the other supplemental reort tables';


--
-- Name: COLUMN supplemental_report.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report.id IS 'Primary key';


--
-- Name: COLUMN supplemental_report.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN supplemental_report.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN supplemental_report.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN supplemental_report.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN supplemental_report.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report.status IS 'The validation status of this supplemental report.Valid statuses: [''DRAFT'', ''SUBMITTED'', ''RECOMMENDED'', ''RETURNED'', ''ASSESSED'', ''REASSESSED'', ''DELETED'']';


--
-- Name: COLUMN supplemental_report.model_year_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report.model_year_report_id IS 'Reference to primary key (id) of table model_year_report';


--
-- Name: COLUMN supplemental_report.ldv_sales; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report.ldv_sales IS 'Contains the LDV sales/leases data based on supplemental report.';


--
-- Name: COLUMN supplemental_report.supplemental_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report.supplemental_id IS 'This will reference the previous supplemental report that the analyst was reviewing.';


--
-- Name: supplemental_report_assessment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplemental_report_assessment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    penalty numeric(20,2),
    supplemental_report_id integer NOT NULL,
    supplemental_report_assessment_description_id integer NOT NULL
);


--
-- Name: TABLE supplemental_report_assessment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.supplemental_report_assessment IS 'Contains Supplemental Report Assessment description as selectedby analyst and penalty amount if applicable';


--
-- Name: COLUMN supplemental_report_assessment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment.id IS 'Primary key';


--
-- Name: COLUMN supplemental_report_assessment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN supplemental_report_assessment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN supplemental_report_assessment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN supplemental_report_assessment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN supplemental_report_assessment.penalty; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment.penalty IS 'amount of administrative penalty';


--
-- Name: COLUMN supplemental_report_assessment.supplemental_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment.supplemental_report_id IS 'Reference to primary key (id) of table supplemental_report';


--
-- Name: COLUMN supplemental_report_assessment.supplemental_report_assessment_description_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment.supplemental_report_assessment_description_id IS 'Reference to primary key (id) of table model_year_report_assessment_descriptions';


--
-- Name: supplemental_report_assessment_comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplemental_report_assessment_comment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    to_director boolean NOT NULL,
    assessment_comment character varying(4000),
    supplemental_report_id integer NOT NULL
);


--
-- Name: TABLE supplemental_report_assessment_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.supplemental_report_assessment_comment IS 'Contains comments made about the Supplemental Report Assessmentfrom analyst to director and from analyst to supplier';


--
-- Name: COLUMN supplemental_report_assessment_comment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment_comment.id IS 'Primary key';


--
-- Name: COLUMN supplemental_report_assessment_comment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment_comment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN supplemental_report_assessment_comment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment_comment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN supplemental_report_assessment_comment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment_comment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN supplemental_report_assessment_comment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment_comment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN supplemental_report_assessment_comment.to_director; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment_comment.to_director IS 'determines if comment is meant for director';


--
-- Name: COLUMN supplemental_report_assessment_comment.assessment_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment_comment.assessment_comment IS 'Comment left by idir about supplemental report';


--
-- Name: COLUMN supplemental_report_assessment_comment.supplemental_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_assessment_comment.supplemental_report_id IS 'Reference to primary key (id) of table supplemental_report';


--
-- Name: supplemental_report_assessment_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplemental_report_assessment_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplemental_report_assessment_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplemental_report_assessment_comment_id_seq OWNED BY public.supplemental_report_assessment_comment.id;


--
-- Name: supplemental_report_assessment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplemental_report_assessment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplemental_report_assessment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplemental_report_assessment_id_seq OWNED BY public.supplemental_report_assessment.id;


--
-- Name: supplemental_report_comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplemental_report_comment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    to_govt boolean NOT NULL,
    comment character varying(4000),
    supplemental_report_id integer NOT NULL
);


--
-- Name: TABLE supplemental_report_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.supplemental_report_comment IS 'Contains comments made about the Supplemental Report';


--
-- Name: COLUMN supplemental_report_comment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_comment.id IS 'Primary key';


--
-- Name: COLUMN supplemental_report_comment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_comment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN supplemental_report_comment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_comment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN supplemental_report_comment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_comment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN supplemental_report_comment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_comment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN supplemental_report_comment.to_govt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_comment.to_govt IS 'determines if comment is meant for governement';


--
-- Name: COLUMN supplemental_report_comment.comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_comment.comment IS 'Comment left by idir or bceid user about supplemental report';


--
-- Name: COLUMN supplemental_report_comment.supplemental_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_comment.supplemental_report_id IS 'Reference to primary key (id) of table supplemental_report';


--
-- Name: supplemental_report_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplemental_report_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplemental_report_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplemental_report_comment_id_seq OWNED BY public.supplemental_report_comment.id;


--
-- Name: supplemental_report_credit_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplemental_report_credit_activity (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    credit_a_value numeric(20,2),
    credit_b_value numeric(20,2),
    category character varying(100),
    model_year_id integer,
    supplemental_report_id integer NOT NULL
);


--
-- Name: TABLE supplemental_report_credit_activity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.supplemental_report_credit_activity IS 'Table to record credit activityinformation for the supplemental report';


--
-- Name: COLUMN supplemental_report_credit_activity.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_credit_activity.id IS 'Primary key';


--
-- Name: COLUMN supplemental_report_credit_activity.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_credit_activity.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN supplemental_report_credit_activity.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_credit_activity.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN supplemental_report_credit_activity.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_credit_activity.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN supplemental_report_credit_activity.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_credit_activity.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN supplemental_report_credit_activity.credit_a_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_credit_activity.credit_a_value IS 'Value of credit A';


--
-- Name: COLUMN supplemental_report_credit_activity.credit_b_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_credit_activity.credit_b_value IS 'Value of credit B';


--
-- Name: COLUMN supplemental_report_credit_activity.category; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_credit_activity.category IS 'Category (eg. CREDIT_BALANCE_START. CREDITS_ISSUED_ZEV_SALES, CREDITS_IN, CREDITS_OUT, CREDIT_BALANCE_END, CREDIT_BALANCE_END, CREDIT_BALANCE_PROVISIONAL)';


--
-- Name: COLUMN supplemental_report_credit_activity.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_credit_activity.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN supplemental_report_credit_activity.supplemental_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_credit_activity.supplemental_report_id IS 'Reference to primary key (id) of table supplemental_report';


--
-- Name: supplemental_report_credit_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplemental_report_credit_activity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplemental_report_credit_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplemental_report_credit_activity_id_seq OWNED BY public.supplemental_report_credit_activity.id;


--
-- Name: supplemental_report_file_attachment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplemental_report_file_attachment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    filename character varying(260) NOT NULL,
    minio_object_name character varying(32) NOT NULL,
    size bigint NOT NULL,
    mime_type character varying(255),
    is_removed boolean NOT NULL,
    supplemental_report_id integer NOT NULL
);


--
-- Name: TABLE supplemental_report_file_attachment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.supplemental_report_file_attachment IS 'Attachment Information for the Supplemental Report.Contains information such as mime type, file size, and minio URL.';


--
-- Name: COLUMN supplemental_report_file_attachment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.id IS 'Primary key';


--
-- Name: COLUMN supplemental_report_file_attachment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN supplemental_report_file_attachment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN supplemental_report_file_attachment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN supplemental_report_file_attachment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN supplemental_report_file_attachment.filename; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.filename IS 'Filename from when it was in the user''s system.';


--
-- Name: COLUMN supplemental_report_file_attachment.minio_object_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.minio_object_name IS 'Object name in minio (UUID as a 32 hexadecimal string).';


--
-- Name: COLUMN supplemental_report_file_attachment.size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.size IS 'Size of the file in bytes.';


--
-- Name: COLUMN supplemental_report_file_attachment.mime_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.mime_type IS 'Mime type information of the file. (eg. application/pdf, image/gif, image/png, etc)';


--
-- Name: COLUMN supplemental_report_file_attachment.is_removed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.is_removed IS 'Whether it was marked as deleted';


--
-- Name: COLUMN supplemental_report_file_attachment.supplemental_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_file_attachment.supplemental_report_id IS 'Reference to primary key (id) of table supplemental_report';


--
-- Name: supplemental_report_file_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplemental_report_file_attachment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplemental_report_file_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplemental_report_file_attachment_id_seq OWNED BY public.supplemental_report_file_attachment.id;


--
-- Name: supplemental_report_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplemental_report_history (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    validation_status character varying(20) NOT NULL,
    supplemental_report_id integer NOT NULL
);


--
-- Name: TABLE supplemental_report_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.supplemental_report_history IS 'history of supplemental report statuses';


--
-- Name: COLUMN supplemental_report_history.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_history.id IS 'Primary key';


--
-- Name: COLUMN supplemental_report_history.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_history.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN supplemental_report_history.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_history.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN supplemental_report_history.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_history.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN supplemental_report_history.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_history.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN supplemental_report_history.validation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_history.validation_status IS 'The validation status of this supplemental report. Valid statuses: [''DRAFT'', ''SUBMITTED'', ''RECOMMENDED'', ''RETURNED'', ''ASSESSED'', ''REASSESSED'', ''DELETED'']';


--
-- Name: COLUMN supplemental_report_history.supplemental_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_history.supplemental_report_id IS 'Reference to primary key (id) of table supplemental_report';


--
-- Name: supplemental_report_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplemental_report_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplemental_report_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplemental_report_history_id_seq OWNED BY public.supplemental_report_history.id;


--
-- Name: supplemental_report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplemental_report_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplemental_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplemental_report_id_seq OWNED BY public.supplemental_report.id;


--
-- Name: supplemental_report_sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplemental_report_sales (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    sales integer,
    make character varying(250),
    model_name character varying(250),
    range numeric(20,2),
    model_year character varying(4),
    model_year_report_vehicle_id integer,
    supplemental_report_id integer NOT NULL,
    vehicle_zev_type character varying(4),
    zev_class character varying(3),
    supplemental_origin_zev_sale_id integer
);


--
-- Name: TABLE supplemental_report_sales; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.supplemental_report_sales IS 'Table containes ZEV vehicle salesinformation based on supplemental report';


--
-- Name: COLUMN supplemental_report_sales.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.id IS 'Primary key';


--
-- Name: COLUMN supplemental_report_sales.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN supplemental_report_sales.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN supplemental_report_sales.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN supplemental_report_sales.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN supplemental_report_sales.sales; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.sales IS 'Sum of issued sales for zev models';


--
-- Name: COLUMN supplemental_report_sales.make; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.make IS 'Make of vehicle';


--
-- Name: COLUMN supplemental_report_sales.model_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.model_name IS 'Model of vehicle';


--
-- Name: COLUMN supplemental_report_sales.range; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.range IS 'vehicle range in km';


--
-- Name: COLUMN supplemental_report_sales.model_year; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.model_year IS 'model year';


--
-- Name: COLUMN supplemental_report_sales.model_year_report_vehicle_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.model_year_report_vehicle_id IS 'Reference to primary key (id) of table model_year_report_vehicle';


--
-- Name: COLUMN supplemental_report_sales.supplemental_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.supplemental_report_id IS 'Reference to primary key (id) of table supplemental_report';


--
-- Name: COLUMN supplemental_report_sales.vehicle_zev_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.vehicle_zev_type IS 'zev type';


--
-- Name: COLUMN supplemental_report_sales.zev_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.zev_class IS 'zev class';


--
-- Name: COLUMN supplemental_report_sales.supplemental_origin_zev_sale_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_sales.supplemental_origin_zev_sale_id IS 'This will reference the original, newly added zev sale if this sale is based on that sale';


--
-- Name: supplemental_report_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplemental_report_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplemental_report_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplemental_report_sales_id_seq OWNED BY public.supplemental_report_sales.id;


--
-- Name: supplemental_report_supplier_information; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplemental_report_supplier_information (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    category character varying(250),
    value character varying(500),
    supplemental_report_id integer NOT NULL
);


--
-- Name: TABLE supplemental_report_supplier_information; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.supplemental_report_supplier_information IS 'Table containes supplemetal report''s supplier information';


--
-- Name: COLUMN supplemental_report_supplier_information.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_supplier_information.id IS 'Primary key';


--
-- Name: COLUMN supplemental_report_supplier_information.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_supplier_information.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN supplemental_report_supplier_information.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_supplier_information.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN supplemental_report_supplier_information.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_supplier_information.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN supplemental_report_supplier_information.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_supplier_information.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN supplemental_report_supplier_information.category; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_supplier_information.category IS 'Category (eg. LEGAL_NAME, SERVICE_ADDRESS, RECORDS_ADDRESS, LDV_MAKES, SUPPLIER_CLASS';


--
-- Name: COLUMN supplemental_report_supplier_information.supplemental_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.supplemental_report_supplier_information.supplemental_report_id IS 'Reference to primary key (id) of table supplemental_report';


--
-- Name: supplemental_report_supplier_information_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplemental_report_supplier_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplemental_report_supplier_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplemental_report_supplier_information_id_seq OWNED BY public.supplemental_report_supplier_information.id;


--
-- Name: user_creation_request; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_creation_request (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    keycloak_email character varying(254) NOT NULL,
    external_username character varying(150),
    is_mapped boolean NOT NULL,
    user_profile_id integer NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130)
);


--
-- Name: TABLE user_creation_request; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_creation_request IS 'Contains a list of users that were created by the system. This is used to map out the relationship between the email used via keycloak and the actual user in the system.';


--
-- Name: COLUMN user_creation_request.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_creation_request.id IS 'Primary key';


--
-- Name: COLUMN user_creation_request.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_creation_request.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN user_creation_request.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_creation_request.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN user_creation_request.keycloak_email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_creation_request.keycloak_email IS 'Keycloak email address to associate on first login';


--
-- Name: COLUMN user_creation_request.external_username; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_creation_request.external_username IS 'BCeID or IDIR username';


--
-- Name: COLUMN user_creation_request.is_mapped; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_creation_request.is_mapped IS 'True if this request has been acted on';


--
-- Name: COLUMN user_creation_request.user_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_creation_request.user_profile_id IS 'Reference to primary key (id) of table user_profile, with additional comment: The user to be associated with a Keycloak account';


--
-- Name: COLUMN user_creation_request.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_creation_request.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN user_creation_request.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_creation_request.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: user_creation_request_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_creation_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_creation_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_creation_request_id_seq OWNED BY public.user_creation_request.id;


--
-- Name: user_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_profile (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(254),
    phone character varying(50),
    username character varying(130) NOT NULL,
    organization_id integer,
    display_name character varying(500),
    is_active boolean NOT NULL,
    keycloak_email character varying(254),
    title character varying(100),
    create_user character varying(130) NOT NULL,
    update_user character varying(130),
    keycloak_user_id character varying(150)
);


--
-- Name: TABLE user_profile; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_profile IS 'Users who may access the application';


--
-- Name: COLUMN user_profile.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.id IS 'Primary key';


--
-- Name: COLUMN user_profile.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN user_profile.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN user_profile.first_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.first_name IS 'First name (retrieved from Keycloak)';


--
-- Name: COLUMN user_profile.last_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.last_name IS 'Last name (retrieved from Keycloak)';


--
-- Name: COLUMN user_profile.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.email IS 'Primary email address';


--
-- Name: COLUMN user_profile.phone; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.phone IS 'Primary phone number';


--
-- Name: COLUMN user_profile.username; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.username IS 'Username that we can connect the user to Keycloak.';


--
-- Name: COLUMN user_profile.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.organization_id IS 'Reference to primary key (id) of table organization';


--
-- Name: COLUMN user_profile.display_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.display_name IS 'Display Name (retrieved from Keycloak)';


--
-- Name: COLUMN user_profile.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.is_active IS 'Boolean Field to see if the user should be able to login.';


--
-- Name: COLUMN user_profile.keycloak_email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.keycloak_email IS 'BCEID/IDIR Email Address';


--
-- Name: COLUMN user_profile.title; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.title IS 'Professional Title';


--
-- Name: COLUMN user_profile.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN user_profile.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN user_profile.keycloak_user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profile.keycloak_user_id IS 'This is the unique id returned from Keycloak and is the main mapping key between the TFRS user and the Keycloak user. The identity provider type will be appended as a suffix after an @ symbol. For ex. asdf1234@bceidbasic or asdf1234@idir';


--
-- Name: user_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_profile_id_seq OWNED BY public.user_profile.id;


--
-- Name: user_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_role (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    role_id integer NOT NULL,
    user_profile_id integer NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130)
);


--
-- Name: TABLE user_role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_role IS 'Contains the relationship between the user and roles table.(ie what roles do the users have)';


--
-- Name: COLUMN user_role.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_role.id IS 'Primary key';


--
-- Name: COLUMN user_role.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_role.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN user_role.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_role.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN user_role.role_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_role.role_id IS 'Reference to primary key (id) of table role';


--
-- Name: COLUMN user_role.user_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_role.user_profile_id IS 'Reference to primary key (id) of table user_profile';


--
-- Name: COLUMN user_role.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_role.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN user_role.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_role.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_role_id_seq OWNED BY public.user_role.id;


--
-- Name: vehicle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    range integer NOT NULL,
    make character varying(250) NOT NULL,
    model_year_id integer NOT NULL,
    validation_status character varying(20) NOT NULL,
    model_name character varying(250) NOT NULL,
    credit_value numeric(20,2),
    vehicle_zev_type_id integer NOT NULL,
    vehicle_class_code_id integer NOT NULL,
    weight_kg numeric(6,0) NOT NULL,
    organization_id integer NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130),
    credit_class_id integer,
    has_passed_us_06_test boolean NOT NULL,
    is_active boolean NOT NULL
);


--
-- Name: TABLE vehicle; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vehicle IS 'List of credit-generating vehicle definitions';


--
-- Name: COLUMN vehicle.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.id IS 'Primary key';


--
-- Name: COLUMN vehicle.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN vehicle.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN vehicle.range; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.range IS 'Vehicle Range in km';


--
-- Name: COLUMN vehicle.make; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.make IS 'The make of vehicleeg Toyota, Honda, Mitsubishi';


--
-- Name: COLUMN vehicle.model_year_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.model_year_id IS 'Reference to primary key (id) of table model_year';


--
-- Name: COLUMN vehicle.validation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.validation_status IS 'The validation status of the vehicle. Valid statuses: [''NEW'', ''DRAFT'', ''SUBMITTED'', ''VALIDATED'', ''REJECTED'', ''CHANGES_REQUESTED'', ''DELETED'']';


--
-- Name: COLUMN vehicle.model_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.model_name IS 'Model information of the vehicle';


--
-- Name: COLUMN vehicle.credit_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.credit_value IS 'The number of credits (of credit_class) a sale of this vehicle can generate';


--
-- Name: COLUMN vehicle.vehicle_zev_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.vehicle_zev_type_id IS 'Reference to primary key (id) of table vehicle_zev_type';


--
-- Name: COLUMN vehicle.vehicle_class_code_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.vehicle_class_code_id IS 'Reference to primary key (id) of table vehicle_class_code';


--
-- Name: COLUMN vehicle.weight_kg; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.weight_kg IS 'Weight of vehicle';


--
-- Name: COLUMN vehicle.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.organization_id IS 'Reference to primary key (id) of table organization';


--
-- Name: COLUMN vehicle.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN vehicle.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN vehicle.credit_class_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.credit_class_id IS 'Reference to primary key (id) of table credit_class_code';


--
-- Name: COLUMN vehicle.has_passed_us_06_test; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.has_passed_us_06_test IS 'Boolean field used to claim whether the vehicle should get additional credit for passing the US06 range test.';


--
-- Name: COLUMN vehicle.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle.is_active IS 'Boolean field used to determine whether a vehicle is active or inactive';


--
-- Name: vehicle_class_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_class_code (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    effective_date date,
    expiration_date date,
    description character varying(250) NOT NULL,
    vehicle_class_code character varying(3) NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130)
);


--
-- Name: TABLE vehicle_class_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vehicle_class_code IS 'Vehicle Class (Body/Weight class) as defined in NRCANe.g. T - Two-seaterI - Minicompact';


--
-- Name: COLUMN vehicle_class_code.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_class_code.id IS 'Primary key';


--
-- Name: COLUMN vehicle_class_code.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_class_code.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN vehicle_class_code.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_class_code.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN vehicle_class_code.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_class_code.effective_date IS 'The calendar date the value became valid.';


--
-- Name: COLUMN vehicle_class_code.expiration_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_class_code.expiration_date IS 'The calendar date the value is no longer valid.';


--
-- Name: COLUMN vehicle_class_code.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_class_code.description IS 'Displayed name for the lookup value';


--
-- Name: COLUMN vehicle_class_code.vehicle_class_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_class_code.vehicle_class_code IS 'Vehicle Class Code (e.g. T, I, S, C, M, L)';


--
-- Name: COLUMN vehicle_class_code.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_class_code.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN vehicle_class_code.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_class_code.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: vehicle_class_code_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_class_code_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_class_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_class_code_id_seq OWNED BY public.vehicle_class_code.id;


--
-- Name: vehicle_comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_comment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    vehicle_comment character varying(4000),
    vehicle_id integer NOT NULL
);


--
-- Name: TABLE vehicle_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vehicle_comment IS 'Contains comments made about the vehicle such as requesting range test results from the supplier.';


--
-- Name: COLUMN vehicle_comment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_comment.id IS 'Primary key';


--
-- Name: COLUMN vehicle_comment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_comment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN vehicle_comment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_comment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN vehicle_comment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_comment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN vehicle_comment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_comment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN vehicle_comment.vehicle_comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_comment.vehicle_comment IS 'Comment left by idir user about vehicle';


--
-- Name: COLUMN vehicle_comment.vehicle_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_comment.vehicle_id IS 'Reference to primary key (id) of table vehicle';


--
-- Name: vehicle_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_comment_id_seq OWNED BY public.vehicle_comment.id;


--
-- Name: vehicle_file_attachment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_file_attachment (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    filename character varying(260) NOT NULL,
    minio_object_name character varying(32) NOT NULL,
    size bigint NOT NULL,
    mime_type character varying(255),
    is_removed boolean NOT NULL,
    vehicle_id integer NOT NULL
);


--
-- Name: TABLE vehicle_file_attachment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vehicle_file_attachment IS 'Attachment information for the vehicles.Contains information such as mime type, file size, and minio URL.';


--
-- Name: COLUMN vehicle_file_attachment.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.id IS 'Primary key';


--
-- Name: COLUMN vehicle_file_attachment.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN vehicle_file_attachment.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN vehicle_file_attachment.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN vehicle_file_attachment.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN vehicle_file_attachment.filename; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.filename IS 'Filename from when it was in the user''s system.';


--
-- Name: COLUMN vehicle_file_attachment.minio_object_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.minio_object_name IS 'Object name in minio (UUID as a 32 hexadecimal string).';


--
-- Name: COLUMN vehicle_file_attachment.size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.size IS 'Size of the file in bytes.';


--
-- Name: COLUMN vehicle_file_attachment.mime_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.mime_type IS 'Mime type information of the file. (eg. application/pdf, image/gif, image/png, etc)';


--
-- Name: COLUMN vehicle_file_attachment.is_removed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.is_removed IS 'Whether it was marked as deleted';


--
-- Name: COLUMN vehicle_file_attachment.vehicle_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_file_attachment.vehicle_id IS 'Reference to primary key (id) of table vehicle';


--
-- Name: vehicle_file_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_file_attachment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_file_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_file_attachment_id_seq OWNED BY public.vehicle_file_attachment.id;


--
-- Name: vehicle_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_id_seq OWNED BY public.vehicle.id;


--
-- Name: vehicle_zev_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_zev_type (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    update_timestamp timestamp with time zone,
    effective_date date,
    expiration_date date,
    description character varying(250) NOT NULL,
    vehicle_zev_code character varying(4) NOT NULL,
    create_user character varying(130) NOT NULL,
    update_user character varying(130)
);


--
-- Name: TABLE vehicle_zev_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vehicle_zev_type IS 'ZEV type of the vehiclee.g.BEV - Battery Electric VehicleFCEV - Hydrogen Fuel Cell Electric VehiclePHEV - Plug-in Hybrid Electric Vehicle';


--
-- Name: COLUMN vehicle_zev_type.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_zev_type.id IS 'Primary key';


--
-- Name: COLUMN vehicle_zev_type.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_zev_type.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN vehicle_zev_type.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_zev_type.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN vehicle_zev_type.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_zev_type.effective_date IS 'The calendar date the value became valid.';


--
-- Name: COLUMN vehicle_zev_type.expiration_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_zev_type.expiration_date IS 'The calendar date the value is no longer valid.';


--
-- Name: COLUMN vehicle_zev_type.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_zev_type.description IS 'Displayed name for the lookup value';


--
-- Name: COLUMN vehicle_zev_type.vehicle_zev_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_zev_type.vehicle_zev_code IS 'Zev type (e.g. BEV, FCEV, PHEV)';


--
-- Name: COLUMN vehicle_zev_type.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_zev_type.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN vehicle_zev_type.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_zev_type.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: vehicle_zev_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_zev_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_zev_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_zev_type_id_seq OWNED BY public.vehicle_zev_type.id;


--
-- Name: weight_class_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weight_class_code (
    id integer NOT NULL,
    create_timestamp timestamp with time zone,
    create_user character varying(130) NOT NULL,
    update_timestamp timestamp with time zone,
    update_user character varying(130),
    effective_date date,
    expiration_date date,
    weight_class_code character varying(3) NOT NULL,
    description character varying(1000) NOT NULL
);


--
-- Name: TABLE weight_class_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.weight_class_code IS 'A lookup table for weight classes.Initially, LDV only, room to expand later.';


--
-- Name: COLUMN weight_class_code.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.weight_class_code.id IS 'Primary key';


--
-- Name: COLUMN weight_class_code.create_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.weight_class_code.create_timestamp IS 'Creation timestamp';


--
-- Name: COLUMN weight_class_code.create_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.weight_class_code.create_user IS 'User ID associated to the person who''s creating the record';


--
-- Name: COLUMN weight_class_code.update_timestamp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.weight_class_code.update_timestamp IS 'Last updated/saved timestamp';


--
-- Name: COLUMN weight_class_code.update_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.weight_class_code.update_user IS 'User ID associated to the person who''s making changes to the record';


--
-- Name: COLUMN weight_class_code.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.weight_class_code.effective_date IS 'The calendar date the value became valid.';


--
-- Name: COLUMN weight_class_code.expiration_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.weight_class_code.expiration_date IS 'The calendar date the value is no longer valid.';


--
-- Name: COLUMN weight_class_code.weight_class_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.weight_class_code.weight_class_code IS 'Weight Class (eg LDV for Light-weight Vehicle)';


--
-- Name: COLUMN weight_class_code.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.weight_class_code.description IS 'More detailed description of the weight class.';


--
-- Name: weight_class_code_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.weight_class_code_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: weight_class_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.weight_class_code_id_seq OWNED BY public.weight_class_code.id;


--
-- Name: logged_actions; Type: TABLE; Schema: zeva_audit; Owner: -
--

CREATE TABLE zeva_audit.logged_actions (
    event_id bigint NOT NULL,
    schema_name text NOT NULL,
    table_name text NOT NULL,
    relid oid NOT NULL,
    session_user_name text,
    action_tstamp_tx timestamp with time zone NOT NULL,
    client_query text,
    action text NOT NULL,
    statement_only boolean NOT NULL,
    CONSTRAINT logged_actions_action_check CHECK ((action = ANY (ARRAY['I'::text, 'D'::text, 'U'::text, 'T'::text])))
);


--
-- Name: TABLE logged_actions; Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON TABLE zeva_audit.logged_actions IS 'History of auditable actions on audited tables, from zeva_audit.if_modified_func()';


--
-- Name: COLUMN logged_actions.event_id; Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON COLUMN zeva_audit.logged_actions.event_id IS 'Unique identifier for each auditable event';


--
-- Name: COLUMN logged_actions.schema_name; Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON COLUMN zeva_audit.logged_actions.schema_name IS 'Database schema audited table for this event is in';


--
-- Name: COLUMN logged_actions.table_name; Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON COLUMN zeva_audit.logged_actions.table_name IS 'Non-schema-qualified table name of table event occured in';


--
-- Name: COLUMN logged_actions.relid; Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON COLUMN zeva_audit.logged_actions.relid IS 'Table OID. Changes with drop/create. Get with ''tablename''::regclass';


--
-- Name: COLUMN logged_actions.session_user_name; Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON COLUMN zeva_audit.logged_actions.session_user_name IS 'Login / session user whose statement caused the audited event';


--
-- Name: COLUMN logged_actions.action_tstamp_tx; Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON COLUMN zeva_audit.logged_actions.action_tstamp_tx IS 'Transaction start timestamp for tx in which audited event occurred';


--
-- Name: COLUMN logged_actions.client_query; Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON COLUMN zeva_audit.logged_actions.client_query IS 'Top-level query that caused this auditable event. May be more than one statement.';


--
-- Name: COLUMN logged_actions.action; Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON COLUMN zeva_audit.logged_actions.action IS 'Action type; I = insert, D = delete, U = update, T = truncate';


--
-- Name: COLUMN logged_actions.statement_only; Type: COMMENT; Schema: zeva_audit; Owner: -
--

COMMENT ON COLUMN zeva_audit.logged_actions.statement_only IS '''t'' if audit event is from an FOR EACH STATEMENT trigger, ''f'' for FOR EACH ROW';


--
-- Name: logged_actions_event_id_seq; Type: SEQUENCE; Schema: zeva_audit; Owner: -
--

CREATE SEQUENCE zeva_audit.logged_actions_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: logged_actions_event_id_seq; Type: SEQUENCE OWNED BY; Schema: zeva_audit; Owner: -
--

ALTER SEQUENCE zeva_audit.logged_actions_event_id_seq OWNED BY zeva_audit.logged_actions.event_id;


--
-- Name: address_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_type ALTER COLUMN id SET DEFAULT nextval('public.address_type_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: compliance_ratio id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_ratio ALTER COLUMN id SET DEFAULT nextval('public.compliance_ratio_id_seq'::regclass);


--
-- Name: credit_agreement id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement ALTER COLUMN id SET DEFAULT nextval('public.credit_agreement_id_seq'::regclass);


--
-- Name: credit_agreement_comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_comment ALTER COLUMN id SET DEFAULT nextval('public.credit_agreement_comment_id_seq'::regclass);


--
-- Name: credit_agreement_content id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_content ALTER COLUMN id SET DEFAULT nextval('public.credit_agreement_content_id_seq'::regclass);


--
-- Name: credit_agreement_credit_transaction id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_credit_transaction ALTER COLUMN id SET DEFAULT nextval('public.credit_agreement_credit_transaction_id_seq'::regclass);


--
-- Name: credit_agreement_file_attachment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_file_attachment ALTER COLUMN id SET DEFAULT nextval('public.credit_agreement_file_attachment_id_seq'::regclass);


--
-- Name: credit_agreement_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_history ALTER COLUMN id SET DEFAULT nextval('public.credit_agreement_history_id_seq'::regclass);


--
-- Name: credit_class_code id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_class_code ALTER COLUMN id SET DEFAULT nextval('public.credit_class_code_id_seq'::regclass);


--
-- Name: credit_transaction id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction ALTER COLUMN id SET DEFAULT nextval('public.credit_transaction_id_seq'::regclass);


--
-- Name: credit_transaction_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction_type ALTER COLUMN id SET DEFAULT nextval('public.credit_transaction_type_id_seq'::regclass);


--
-- Name: credit_transfer id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer ALTER COLUMN id SET DEFAULT nextval('public.credit_transfer_id_seq'::regclass);


--
-- Name: credit_transfer_comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_comment ALTER COLUMN id SET DEFAULT nextval('public.credit_transfer_comment_id_seq'::regclass);


--
-- Name: credit_transfer_content id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_content ALTER COLUMN id SET DEFAULT nextval('public.credit_transfer_content_id_seq'::regclass);


--
-- Name: credit_transfer_credit_transaction id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_credit_transaction ALTER COLUMN id SET DEFAULT nextval('public.credit_transfer_credit_transaction_id_seq'::regclass);


--
-- Name: credit_transfer_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_history ALTER COLUMN id SET DEFAULT nextval('public.credit_transfer_history_id_seq'::regclass);


--
-- Name: django_celery_beat_clockedschedule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_clockedschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_crontabschedule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_crontabschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_intervalschedule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_intervalschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_periodictask id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_periodictask ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_periodictask_id_seq'::regclass);


--
-- Name: django_celery_beat_solarschedule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_solarschedule_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: fixture_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixture_migrations ALTER COLUMN id SET DEFAULT nextval('public.fixture_migrations_id_seq'::regclass);


--
-- Name: icbc_registration_data id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_registration_data ALTER COLUMN id SET DEFAULT nextval('public.icbc_registration_data_id_seq'::regclass);


--
-- Name: icbc_snapshot_data id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_snapshot_data ALTER COLUMN id SET DEFAULT nextval('public.icbc_snapshot_data_id_seq'::regclass);


--
-- Name: icbc_upload_date id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_upload_date ALTER COLUMN id SET DEFAULT nextval('public.icbc_upload_date_id_seq'::regclass);


--
-- Name: icbc_vehicle id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_vehicle ALTER COLUMN id SET DEFAULT nextval('public.icbc_vehicle_id_seq'::regclass);


--
-- Name: model_year id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year ALTER COLUMN id SET DEFAULT nextval('public.model_year_id_seq'::regclass);


--
-- Name: model_year_report id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_id_seq'::regclass);


--
-- Name: model_year_report_address id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_address ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_address_id_seq'::regclass);


--
-- Name: model_year_report_adjustment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_adjustment ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_adjustment_id_seq'::regclass);


--
-- Name: model_year_report_assessment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_assessment ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_assessment_id_seq'::regclass);


--
-- Name: model_year_report_assessment_comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_assessment_comment ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_assessment_comment_id_seq'::regclass);


--
-- Name: model_year_report_assessment_descriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_assessment_descriptions ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_assessment_descriptions_id_seq'::regclass);


--
-- Name: model_year_report_compliance_obligation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_compliance_obligation ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_compliance_obligation_id_seq'::regclass);


--
-- Name: model_year_report_confirmation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_confirmation ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_confirmation_id_seq'::regclass);


--
-- Name: model_year_report_credit_offset id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_credit_offset ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_credit_offset_id_seq'::regclass);


--
-- Name: model_year_report_credit_transaction id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_credit_transaction ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_credit_transaction_id_seq'::regclass);


--
-- Name: model_year_report_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_history ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_history_id_seq'::regclass);


--
-- Name: model_year_report_ldv_sales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_ldv_sales ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_ldv_sales_id_seq'::regclass);


--
-- Name: model_year_report_make id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_make ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_make_id_seq'::regclass);


--
-- Name: model_year_report_vehicle id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_vehicle ALTER COLUMN id SET DEFAULT nextval('public.model_year_report_vehicle_id_seq'::regclass);


--
-- Name: notification id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification ALTER COLUMN id SET DEFAULT nextval('public.notification_id_seq'::regclass);


--
-- Name: notification_subscription id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_subscription ALTER COLUMN id SET DEFAULT nextval('public.notification_subscription_id_seq'::regclass);


--
-- Name: organization id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization ALTER COLUMN id SET DEFAULT nextval('public.organization_id_seq'::regclass);


--
-- Name: organization_address id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_address ALTER COLUMN id SET DEFAULT nextval('public.organization_address_id_seq'::regclass);


--
-- Name: organization_deficits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_deficits ALTER COLUMN id SET DEFAULT nextval('public.organization_deficits_id_seq'::regclass);


--
-- Name: organization_ldv_sales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_ldv_sales ALTER COLUMN id SET DEFAULT nextval('public.organization_ldv_sales_id_seq'::regclass);


--
-- Name: permission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission ALTER COLUMN id SET DEFAULT nextval('public.permission_id_seq'::regclass);


--
-- Name: record_of_sale id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_of_sale ALTER COLUMN id SET DEFAULT nextval('public.record_of_sale_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: role_permission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission ALTER COLUMN id SET DEFAULT nextval('public.role_permission_id_seq'::regclass);


--
-- Name: sales_forecast id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_forecast ALTER COLUMN id SET DEFAULT nextval('public.sales_forecast_id_seq'::regclass);


--
-- Name: sales_forecast_record id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_forecast_record ALTER COLUMN id SET DEFAULT nextval('public.sales_forecast_record_id_seq'::regclass);


--
-- Name: sales_submission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission ALTER COLUMN id SET DEFAULT nextval('public.sales_submission_id_seq'::regclass);


--
-- Name: sales_submission_comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_comment ALTER COLUMN id SET DEFAULT nextval('public.sales_submission_comment_id_seq'::regclass);


--
-- Name: sales_submission_content id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_content ALTER COLUMN id SET DEFAULT nextval('public.sale_submission_content_id_seq'::regclass);


--
-- Name: sales_submission_content_reason id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_content_reason ALTER COLUMN id SET DEFAULT nextval('public.sales_submission_content_reason_id_seq'::regclass);


--
-- Name: sales_submission_credit_transaction id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_credit_transaction ALTER COLUMN id SET DEFAULT nextval('public.sales_submission_credit_transaction_id_seq'::regclass);


--
-- Name: sales_submission_evidence id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_evidence ALTER COLUMN id SET DEFAULT nextval('public.sale_submission_file_attachment_id_seq'::regclass);


--
-- Name: sales_submission_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_history ALTER COLUMN id SET DEFAULT nextval('public.sales_submission_history_id_seq'::regclass);


--
-- Name: signing_authority_assertion id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.signing_authority_assertion ALTER COLUMN id SET DEFAULT nextval('public.signing_authority_assertion_id_seq'::regclass);


--
-- Name: signing_authority_confirmation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.signing_authority_confirmation ALTER COLUMN id SET DEFAULT nextval('public.signing_authority_confirmation_id_seq'::regclass);


--
-- Name: supplemental_report id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report ALTER COLUMN id SET DEFAULT nextval('public.supplemental_report_id_seq'::regclass);


--
-- Name: supplemental_report_assessment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_assessment ALTER COLUMN id SET DEFAULT nextval('public.supplemental_report_assessment_id_seq'::regclass);


--
-- Name: supplemental_report_assessment_comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_assessment_comment ALTER COLUMN id SET DEFAULT nextval('public.supplemental_report_assessment_comment_id_seq'::regclass);


--
-- Name: supplemental_report_comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_comment ALTER COLUMN id SET DEFAULT nextval('public.supplemental_report_comment_id_seq'::regclass);


--
-- Name: supplemental_report_credit_activity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_credit_activity ALTER COLUMN id SET DEFAULT nextval('public.supplemental_report_credit_activity_id_seq'::regclass);


--
-- Name: supplemental_report_file_attachment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_file_attachment ALTER COLUMN id SET DEFAULT nextval('public.supplemental_report_file_attachment_id_seq'::regclass);


--
-- Name: supplemental_report_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_history ALTER COLUMN id SET DEFAULT nextval('public.supplemental_report_history_id_seq'::regclass);


--
-- Name: supplemental_report_sales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_sales ALTER COLUMN id SET DEFAULT nextval('public.supplemental_report_sales_id_seq'::regclass);


--
-- Name: supplemental_report_supplier_information id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_supplier_information ALTER COLUMN id SET DEFAULT nextval('public.supplemental_report_supplier_information_id_seq'::regclass);


--
-- Name: user_creation_request id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_creation_request ALTER COLUMN id SET DEFAULT nextval('public.user_creation_request_id_seq'::regclass);


--
-- Name: user_profile id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_profile ALTER COLUMN id SET DEFAULT nextval('public.user_profile_id_seq'::regclass);


--
-- Name: user_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role ALTER COLUMN id SET DEFAULT nextval('public.user_role_id_seq'::regclass);


--
-- Name: vehicle id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle ALTER COLUMN id SET DEFAULT nextval('public.vehicle_id_seq'::regclass);


--
-- Name: vehicle_change_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_change_history ALTER COLUMN id SET DEFAULT nextval('public.api_vehiclechangehistory_id_seq'::regclass);


--
-- Name: vehicle_class_code id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_class_code ALTER COLUMN id SET DEFAULT nextval('public.vehicle_class_code_id_seq'::regclass);


--
-- Name: vehicle_comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_comment ALTER COLUMN id SET DEFAULT nextval('public.vehicle_comment_id_seq'::regclass);


--
-- Name: vehicle_file_attachment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_file_attachment ALTER COLUMN id SET DEFAULT nextval('public.vehicle_file_attachment_id_seq'::regclass);


--
-- Name: vehicle_zev_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_zev_type ALTER COLUMN id SET DEFAULT nextval('public.vehicle_zev_type_id_seq'::regclass);


--
-- Name: weight_class_code id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_class_code ALTER COLUMN id SET DEFAULT nextval('public.weight_class_code_id_seq'::regclass);


--
-- Name: logged_actions event_id; Type: DEFAULT; Schema: zeva_audit; Owner: -
--

ALTER TABLE ONLY zeva_audit.logged_actions ALTER COLUMN event_id SET DEFAULT nextval('zeva_audit.logged_actions_event_id_seq'::regclass);


--
-- Data for Name: address_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.address_type (id, create_timestamp, create_user, update_timestamp, update_user, effective_date, expiration_date, address_type) FROM stdin;
\.
COPY public.address_type (id, create_timestamp, create_user, update_timestamp, update_user, effective_date, expiration_date, address_type) FROM '$$PATH$$/4504.dat';

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/4508.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/4510.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/4512.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/4514.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/4515.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/4518.dat';

--
-- Data for Name: compliance_ratio; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_ratio (id, create_timestamp, create_user, update_timestamp, update_user, model_year, compliance_ratio, zev_class_a) FROM stdin;
\.
COPY public.compliance_ratio (id, create_timestamp, create_user, update_timestamp, update_user, model_year, compliance_ratio, zev_class_a) FROM '$$PATH$$/4520.dat';

--
-- Data for Name: credit_agreement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_agreement (id, create_timestamp, create_user, update_timestamp, update_user, transaction_type, status, effective_date, organization_id, optional_agreement_id, model_year_report_id) FROM stdin;
\.
COPY public.credit_agreement (id, create_timestamp, create_user, update_timestamp, update_user, transaction_type, status, effective_date, organization_id, optional_agreement_id, model_year_report_id) FROM '$$PATH$$/4522.dat';

--
-- Data for Name: credit_agreement_comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_agreement_comment (id, create_timestamp, create_user, update_timestamp, update_user, to_director, comment, credit_agreement_id) FROM stdin;
\.
COPY public.credit_agreement_comment (id, create_timestamp, create_user, update_timestamp, update_user, to_director, comment, credit_agreement_id) FROM '$$PATH$$/4523.dat';

--
-- Data for Name: credit_agreement_content; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_agreement_content (id, create_timestamp, create_user, update_timestamp, update_user, number_of_credits, credit_agreement_id, credit_class_id, model_year_id) FROM stdin;
\.
COPY public.credit_agreement_content (id, create_timestamp, create_user, update_timestamp, update_user, number_of_credits, credit_agreement_id, credit_class_id, model_year_id) FROM '$$PATH$$/4525.dat';

--
-- Data for Name: credit_agreement_credit_transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_agreement_credit_transaction (id, create_timestamp, create_user, update_timestamp, update_user, credit_agreement_id, credit_transaction_id) FROM stdin;
\.
COPY public.credit_agreement_credit_transaction (id, create_timestamp, create_user, update_timestamp, update_user, credit_agreement_id, credit_transaction_id) FROM '$$PATH$$/4527.dat';

--
-- Data for Name: credit_agreement_file_attachment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_agreement_file_attachment (id, create_timestamp, create_user, update_timestamp, update_user, filename, minio_object_name, size, mime_type, is_removed, credit_agreement_id) FROM stdin;
\.
COPY public.credit_agreement_file_attachment (id, create_timestamp, create_user, update_timestamp, update_user, filename, minio_object_name, size, mime_type, is_removed, credit_agreement_id) FROM '$$PATH$$/4529.dat';

--
-- Data for Name: credit_agreement_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_agreement_history (id, create_timestamp, create_user, update_timestamp, update_user, status, credit_agreement_id) FROM stdin;
\.
COPY public.credit_agreement_history (id, create_timestamp, create_user, update_timestamp, update_user, status, credit_agreement_id) FROM '$$PATH$$/4531.dat';

--
-- Data for Name: credit_class_code; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_class_code (effective_date, expiration_date, credit_class, create_timestamp, update_timestamp, create_user, update_user, id) FROM stdin;
\.
COPY public.credit_class_code (effective_date, expiration_date, credit_class, create_timestamp, update_timestamp, create_user, update_user, id) FROM '$$PATH$$/4534.dat';

--
-- Data for Name: credit_transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_transaction (id, create_timestamp, update_timestamp, credit_value, transaction_timestamp, credit_to_id, debit_from_id, create_user, update_user, credit_class_id, transaction_type_id, model_year_id, weight_class_id, number_of_credits, total_value) FROM stdin;
\.
COPY public.credit_transaction (id, create_timestamp, update_timestamp, credit_value, transaction_timestamp, credit_to_id, debit_from_id, create_user, update_user, credit_class_id, transaction_type_id, model_year_id, weight_class_id, number_of_credits, total_value) FROM '$$PATH$$/4536.dat';

--
-- Data for Name: credit_transaction_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_transaction_type (transaction_type, create_timestamp, update_timestamp, create_user, update_user, id) FROM stdin;
\.
COPY public.credit_transaction_type (transaction_type, create_timestamp, update_timestamp, create_user, update_user, id) FROM '$$PATH$$/4538.dat';

--
-- Data for Name: credit_transfer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_transfer (id, create_timestamp, create_user, update_timestamp, update_user, status, credit_to_id, debit_from_id) FROM stdin;
\.
COPY public.credit_transfer (id, create_timestamp, create_user, update_timestamp, update_user, status, credit_to_id, debit_from_id) FROM '$$PATH$$/4540.dat';

--
-- Data for Name: credit_transfer_comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_transfer_comment (id, create_timestamp, create_user, update_timestamp, update_user, credit_transfer_comment, credit_transfer_history_id) FROM stdin;
\.
COPY public.credit_transfer_comment (id, create_timestamp, create_user, update_timestamp, update_user, credit_transfer_comment, credit_transfer_history_id) FROM '$$PATH$$/4541.dat';

--
-- Data for Name: credit_transfer_content; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_transfer_content (id, create_timestamp, create_user, update_timestamp, update_user, credit_transfer_id, credit_class_id, credit_value, dollar_value, model_year_id, weight_class_id) FROM stdin;
\.
COPY public.credit_transfer_content (id, create_timestamp, create_user, update_timestamp, update_user, credit_transfer_id, credit_class_id, credit_value, dollar_value, model_year_id, weight_class_id) FROM '$$PATH$$/4543.dat';

--
-- Data for Name: credit_transfer_credit_transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_transfer_credit_transaction (id, create_timestamp, create_user, update_timestamp, update_user, credit_transaction_id, credit_transfer_id) FROM stdin;
\.
COPY public.credit_transfer_credit_transaction (id, create_timestamp, create_user, update_timestamp, update_user, credit_transaction_id, credit_transfer_id) FROM '$$PATH$$/4545.dat';

--
-- Data for Name: credit_transfer_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_transfer_history (id, create_timestamp, create_user, update_timestamp, update_user, status, transfer_id) FROM stdin;
\.
COPY public.credit_transfer_history (id, create_timestamp, create_user, update_timestamp, update_user, status, transfer_id) FROM '$$PATH$$/4547.dat';

--
-- Data for Name: django_celery_beat_clockedschedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_celery_beat_clockedschedule (id, clocked_time, enabled) FROM stdin;
\.
COPY public.django_celery_beat_clockedschedule (id, clocked_time, enabled) FROM '$$PATH$$/4550.dat';

--
-- Data for Name: django_celery_beat_crontabschedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM stdin;
\.
COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM '$$PATH$$/4552.dat';

--
-- Data for Name: django_celery_beat_intervalschedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_celery_beat_intervalschedule (id, every, period) FROM stdin;
\.
COPY public.django_celery_beat_intervalschedule (id, every, period) FROM '$$PATH$$/4554.dat';

--
-- Data for Name: django_celery_beat_periodictask; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id) FROM stdin;
\.
COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id) FROM '$$PATH$$/4556.dat';

--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
\.
COPY public.django_celery_beat_periodictasks (ident, last_update) FROM '$$PATH$$/4558.dat';

--
-- Data for Name: django_celery_beat_solarschedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM stdin;
\.
COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM '$$PATH$$/4559.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/4561.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/4563.dat';

--
-- Data for Name: fixture_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fixture_migrations (id, fixture_filename, applied) FROM stdin;
\.
COPY public.fixture_migrations (id, fixture_filename, applied) FROM '$$PATH$$/4565.dat';

--
-- Data for Name: icbc_registration_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.icbc_registration_data (id, create_timestamp, update_timestamp, vin, icbc_vehicle_id, create_user, update_user, icbc_upload_date_id) FROM stdin;
\.
COPY public.icbc_registration_data (id, create_timestamp, update_timestamp, vin, icbc_vehicle_id, create_user, update_user, icbc_upload_date_id) FROM '$$PATH$$/4567.dat';

--
-- Data for Name: icbc_snapshot_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.icbc_snapshot_data (id, create_timestamp, create_user, update_timestamp, update_user, vin, make, model_name, model_year, upload_date, submission_id) FROM stdin;
\.
COPY public.icbc_snapshot_data (id, create_timestamp, create_user, update_timestamp, update_user, vin, make, model_name, model_year, upload_date, submission_id) FROM '$$PATH$$/4569.dat';

--
-- Data for Name: icbc_upload_date; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.icbc_upload_date (id, create_timestamp, create_user, update_timestamp, update_user, upload_date, filename) FROM stdin;
\.
COPY public.icbc_upload_date (id, create_timestamp, create_user, update_timestamp, update_user, upload_date, filename) FROM '$$PATH$$/4571.dat';

--
-- Data for Name: icbc_vehicle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.icbc_vehicle (id, create_timestamp, update_timestamp, model_name, make, model_year_id, create_user, update_user) FROM stdin;
\.
COPY public.icbc_vehicle (id, create_timestamp, update_timestamp, model_name, make, model_year_id, create_user, update_user) FROM '$$PATH$$/4573.dat';

--
-- Data for Name: model_year; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year (id, create_timestamp, update_timestamp, effective_date, expiration_date, description, create_user, update_user) FROM stdin;
\.
COPY public.model_year (id, create_timestamp, update_timestamp, effective_date, expiration_date, description, create_user, update_user) FROM '$$PATH$$/4575.dat';

--
-- Data for Name: model_year_report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report (id, create_timestamp, create_user, update_timestamp, update_user, organization_name, supplier_class, validation_status, model_year_id, organization_id, credit_reduction_selection) FROM stdin;
\.
COPY public.model_year_report (id, create_timestamp, create_user, update_timestamp, update_user, organization_name, supplier_class, validation_status, model_year_id, organization_id, credit_reduction_selection) FROM '$$PATH$$/4577.dat';

--
-- Data for Name: model_year_report_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_address (id, create_timestamp, create_user, update_timestamp, update_user, representative_name, address_line_1, address_line_2, address_line_3, city, postal_code, state, county, country, other, address_type_id, model_year_report_id) FROM stdin;
\.
COPY public.model_year_report_address (id, create_timestamp, create_user, update_timestamp, update_user, representative_name, address_line_1, address_line_2, address_line_3, city, postal_code, state, county, country, other, address_type_id, model_year_report_id) FROM '$$PATH$$/4578.dat';

--
-- Data for Name: model_year_report_adjustment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_adjustment (id, create_timestamp, create_user, update_timestamp, update_user, number_of_credits, is_reduction, credit_class_id, model_year_id, model_year_report_id) FROM stdin;
\.
COPY public.model_year_report_adjustment (id, create_timestamp, create_user, update_timestamp, update_user, number_of_credits, is_reduction, credit_class_id, model_year_id, model_year_report_id) FROM '$$PATH$$/4580.dat';

--
-- Data for Name: model_year_report_assessment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_assessment (id, create_timestamp, create_user, update_timestamp, update_user, penalty, model_year_report_id, model_year_report_assessment_description_id, display) FROM stdin;
\.
COPY public.model_year_report_assessment (id, create_timestamp, create_user, update_timestamp, update_user, penalty, model_year_report_id, model_year_report_assessment_description_id, display) FROM '$$PATH$$/4582.dat';

--
-- Data for Name: model_year_report_assessment_comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_assessment_comment (id, create_timestamp, create_user, update_timestamp, update_user, to_director, assessment_comment, model_year_report_id, display) FROM stdin;
\.
COPY public.model_year_report_assessment_comment (id, create_timestamp, create_user, update_timestamp, update_user, to_director, assessment_comment, model_year_report_id, display) FROM '$$PATH$$/4583.dat';

--
-- Data for Name: model_year_report_assessment_descriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_assessment_descriptions (id, create_timestamp, create_user, update_timestamp, update_user, assessment_description, display_order) FROM stdin;
\.
COPY public.model_year_report_assessment_descriptions (id, create_timestamp, create_user, update_timestamp, update_user, assessment_description, display_order) FROM '$$PATH$$/4585.dat';

--
-- Data for Name: model_year_report_compliance_obligation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_compliance_obligation (id, create_timestamp, create_user, update_timestamp, update_user, credit_a_value, credit_b_value, category, model_year_id, model_year_report_id, from_gov, reduction_value) FROM stdin;
\.
COPY public.model_year_report_compliance_obligation (id, create_timestamp, create_user, update_timestamp, update_user, credit_a_value, credit_b_value, category, model_year_id, model_year_report_id, from_gov, reduction_value) FROM '$$PATH$$/4588.dat';

--
-- Data for Name: model_year_report_confirmation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_confirmation (id, create_timestamp, create_user, update_timestamp, update_user, has_accepted, title, model_year_report_id, signing_authority_assertion_id) FROM stdin;
\.
COPY public.model_year_report_confirmation (id, create_timestamp, create_user, update_timestamp, update_user, has_accepted, title, model_year_report_id, signing_authority_assertion_id) FROM '$$PATH$$/4590.dat';

--
-- Data for Name: model_year_report_credit_offset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_credit_offset (id, create_timestamp, create_user, update_timestamp, update_user, credit_a_offset_value, credit_b_offset_value, model_year_id, model_year_report_id) FROM stdin;
\.
COPY public.model_year_report_credit_offset (id, create_timestamp, create_user, update_timestamp, update_user, credit_a_offset_value, credit_b_offset_value, model_year_id, model_year_report_id) FROM '$$PATH$$/4592.dat';

--
-- Data for Name: model_year_report_credit_transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_credit_transaction (id, create_timestamp, create_user, update_timestamp, update_user, credit_transaction_id, model_year_report_id) FROM stdin;
\.
COPY public.model_year_report_credit_transaction (id, create_timestamp, create_user, update_timestamp, update_user, credit_transaction_id, model_year_report_id) FROM '$$PATH$$/4594.dat';

--
-- Data for Name: model_year_report_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_history (id, create_timestamp, create_user, update_timestamp, update_user, validation_status, model_year_report_id) FROM stdin;
\.
COPY public.model_year_report_history (id, create_timestamp, create_user, update_timestamp, update_user, validation_status, model_year_report_id) FROM '$$PATH$$/4596.dat';

--
-- Data for Name: model_year_report_ldv_sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_ldv_sales (id, create_timestamp, create_user, update_timestamp, update_user, ldv_sales, from_gov, model_year_id, model_year_report_id, display) FROM stdin;
\.
COPY public.model_year_report_ldv_sales (id, create_timestamp, create_user, update_timestamp, update_user, ldv_sales, from_gov, model_year_id, model_year_report_id, display) FROM '$$PATH$$/4599.dat';

--
-- Data for Name: model_year_report_make; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_make (id, create_timestamp, create_user, update_timestamp, update_user, make, model_year_report_id, from_gov, display) FROM stdin;
\.
COPY public.model_year_report_make (id, create_timestamp, create_user, update_timestamp, update_user, make, model_year_report_id, from_gov, display) FROM '$$PATH$$/4601.dat';

--
-- Data for Name: model_year_report_vehicle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_year_report_vehicle (id, create_timestamp, create_user, update_timestamp, update_user, pending_sales, sales_issued, make, model_name, range, model_year_id, zev_class_id, vehicle_zev_type_id, model_year_report_id) FROM stdin;
\.
COPY public.model_year_report_vehicle (id, create_timestamp, create_user, update_timestamp, update_user, pending_sales, sales_issued, make, model_name, range, model_year_id, zev_class_id, vehicle_zev_type_id, model_year_report_id) FROM '$$PATH$$/4603.dat';

--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification (id, create_timestamp, create_user, update_timestamp, update_user, notification_code, name, description, permission_id) FROM stdin;
\.
COPY public.notification (id, create_timestamp, create_user, update_timestamp, update_user, notification_code, name, description, permission_id) FROM '$$PATH$$/4605.dat';

--
-- Data for Name: notification_subscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_subscription (id, create_timestamp, create_user, update_timestamp, update_user, notification_id, user_profile_id) FROM stdin;
\.
COPY public.notification_subscription (id, create_timestamp, create_user, update_timestamp, update_user, notification_id, user_profile_id) FROM '$$PATH$$/4607.dat';

--
-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization (id, create_timestamp, update_timestamp, organization_name, is_government, is_active, short_name, create_user, update_user, first_model_year_id) FROM stdin;
\.
COPY public.organization (id, create_timestamp, update_timestamp, organization_name, is_government, is_active, short_name, create_user, update_user, first_model_year_id) FROM '$$PATH$$/4609.dat';

--
-- Data for Name: organization_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_address (id, create_timestamp, update_timestamp, effective_date, expiration_date, address_line_1, address_line_2, address_line_3, city, postal_code, state, county, country, other, organization_id, create_user, update_user, address_type_id, representative_name) FROM stdin;
\.
COPY public.organization_address (id, create_timestamp, update_timestamp, effective_date, expiration_date, address_line_1, address_line_2, address_line_3, city, postal_code, state, county, country, other, organization_id, create_user, update_user, address_type_id, representative_name) FROM '$$PATH$$/4610.dat';

--
-- Data for Name: organization_deficits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_deficits (id, create_timestamp, create_user, update_timestamp, update_user, credit_value, credit_class_id, model_year_id, organization_id) FROM stdin;
\.
COPY public.organization_deficits (id, create_timestamp, create_user, update_timestamp, update_user, credit_value, credit_class_id, model_year_id, organization_id) FROM '$$PATH$$/4612.dat';

--
-- Data for Name: organization_ldv_sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_ldv_sales (id, create_timestamp, create_user, update_timestamp, update_user, ldv_sales, model_year_id, organization_id, is_supplied) FROM stdin;
\.
COPY public.organization_ldv_sales (id, create_timestamp, create_user, update_timestamp, update_user, ldv_sales, model_year_id, organization_id, is_supplied) FROM '$$PATH$$/4615.dat';

--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission (id, create_timestamp, update_timestamp, permission_code, name, description, create_user, update_user) FROM stdin;
\.
COPY public.permission (id, create_timestamp, update_timestamp, permission_code, name, description, create_user, update_user) FROM '$$PATH$$/4617.dat';

--
-- Data for Name: record_of_sale; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.record_of_sale (id, create_timestamp, update_timestamp, reference_number, vin, vin_validation_status, sale_date, validation_status, vehicle_id, submission_id, create_user, update_user, icbc_snapshot_id) FROM stdin;
\.
COPY public.record_of_sale (id, create_timestamp, update_timestamp, reference_number, vin, vin_validation_status, sale_date, validation_status, vehicle_id, submission_id, create_user, update_user, icbc_snapshot_id) FROM '$$PATH$$/4619.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role (id, create_timestamp, update_timestamp, role_code, description, is_government_role, display_order, default_role, create_user, update_user) FROM stdin;
\.
COPY public.role (id, create_timestamp, update_timestamp, role_code, description, is_government_role, display_order, default_role, create_user, update_user) FROM '$$PATH$$/4621.dat';

--
-- Data for Name: role_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permission (id, create_timestamp, update_timestamp, permission_id, role_id, create_user, update_user) FROM stdin;
\.
COPY public.role_permission (id, create_timestamp, update_timestamp, permission_id, role_id, create_user, update_user) FROM '$$PATH$$/4623.dat';

--
-- Data for Name: sales_forecast; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_forecast (id, create_timestamp, create_user, update_timestamp, update_user, ice_vehicles_one, ice_vehicles_two, ice_vehicles_three, zev_vehicles_one, zev_vehicles_two, zev_vehicles_three, model_year_report_id) FROM stdin;
\.
COPY public.sales_forecast (id, create_timestamp, create_user, update_timestamp, update_user, ice_vehicles_one, ice_vehicles_two, ice_vehicles_three, zev_vehicles_one, zev_vehicles_two, zev_vehicles_three, model_year_report_id) FROM '$$PATH$$/4629.dat';

--
-- Data for Name: sales_forecast_record; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_forecast_record (id, create_timestamp, create_user, update_timestamp, update_user, model_year, make, model_name, type, range, zev_class, vehicle_class_interior_volume, total_supplied, sales_forecast_id) FROM stdin;
\.
COPY public.sales_forecast_record (id, create_timestamp, create_user, update_timestamp, update_user, model_year, make, model_name, type, range, zev_class, vehicle_class_interior_volume, total_supplied, sales_forecast_id) FROM '$$PATH$$/4631.dat';

--
-- Data for Name: sales_submission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_submission (id, create_timestamp, update_timestamp, submission_date, validation_status, organization_id, submission_sequence, create_user, update_user, filename, part_of_model_year_report) FROM stdin;
\.
COPY public.sales_submission (id, create_timestamp, update_timestamp, submission_date, validation_status, organization_id, submission_sequence, create_user, update_user, filename, part_of_model_year_report) FROM '$$PATH$$/4633.dat';

--
-- Data for Name: sales_submission_comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_submission_comment (id, create_timestamp, create_user, update_timestamp, update_user, sales_submission_comment, sales_submission_id, to_govt) FROM stdin;
\.
COPY public.sales_submission_comment (id, create_timestamp, create_user, update_timestamp, update_user, sales_submission_comment, sales_submission_id, to_govt) FROM '$$PATH$$/4634.dat';

--
-- Data for Name: sales_submission_content; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_submission_content (id, create_timestamp, create_user, update_timestamp, update_user, xls_make, xls_model, xls_model_year, xls_sale_date, xls_vin, submission_id, xls_date_mode, xls_date_type, reason, warnings_list) FROM stdin;
\.
COPY public.sales_submission_content (id, create_timestamp, create_user, update_timestamp, update_user, xls_make, xls_model, xls_model_year, xls_sale_date, xls_vin, submission_id, xls_date_mode, xls_date_type, reason, warnings_list) FROM '$$PATH$$/4625.dat';

--
-- Data for Name: sales_submission_content_reason; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_submission_content_reason (id, create_timestamp, create_user, update_timestamp, update_user, reason) FROM stdin;
\.
COPY public.sales_submission_content_reason (id, create_timestamp, create_user, update_timestamp, update_user, reason) FROM '$$PATH$$/4636.dat';

--
-- Data for Name: sales_submission_credit_transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_submission_credit_transaction (id, create_timestamp, create_user, update_timestamp, update_user, credit_transaction_id, sales_submission_id) FROM stdin;
\.
COPY public.sales_submission_credit_transaction (id, create_timestamp, create_user, update_timestamp, update_user, credit_transaction_id, sales_submission_id) FROM '$$PATH$$/4638.dat';

--
-- Data for Name: sales_submission_evidence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_submission_evidence (id, create_timestamp, create_user, update_timestamp, update_user, filename, minio_object_name, size, mime_type, is_removed, submission_id) FROM stdin;
\.
COPY public.sales_submission_evidence (id, create_timestamp, create_user, update_timestamp, update_user, filename, minio_object_name, size, mime_type, is_removed, submission_id) FROM '$$PATH$$/4627.dat';

--
-- Data for Name: sales_submission_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_submission_history (id, create_timestamp, create_user, update_timestamp, update_user, validation_status, submission_id) FROM stdin;
\.
COPY public.sales_submission_history (id, create_timestamp, create_user, update_timestamp, update_user, validation_status, submission_id) FROM '$$PATH$$/4640.dat';

--
-- Data for Name: signing_authority_assertion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.signing_authority_assertion (id, create_timestamp, create_user, update_timestamp, update_user, effective_date, expiration_date, display_order, description, module) FROM stdin;
\.
COPY public.signing_authority_assertion (id, create_timestamp, create_user, update_timestamp, update_user, effective_date, expiration_date, display_order, description, module) FROM '$$PATH$$/4643.dat';

--
-- Data for Name: signing_authority_confirmation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.signing_authority_confirmation (id, create_timestamp, create_user, update_timestamp, update_user, has_accepted, title, credit_transfer_id, signing_authority_assertion_id) FROM stdin;
\.
COPY public.signing_authority_confirmation (id, create_timestamp, create_user, update_timestamp, update_user, has_accepted, title, credit_transfer_id, signing_authority_assertion_id) FROM '$$PATH$$/4645.dat';

--
-- Data for Name: supplemental_report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplemental_report (id, create_timestamp, create_user, update_timestamp, update_user, status, model_year_report_id, ldv_sales, supplemental_id) FROM stdin;
\.
COPY public.supplemental_report (id, create_timestamp, create_user, update_timestamp, update_user, status, model_year_report_id, ldv_sales, supplemental_id) FROM '$$PATH$$/4647.dat';

--
-- Data for Name: supplemental_report_assessment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplemental_report_assessment (id, create_timestamp, create_user, update_timestamp, update_user, penalty, supplemental_report_id, supplemental_report_assessment_description_id) FROM stdin;
\.
COPY public.supplemental_report_assessment (id, create_timestamp, create_user, update_timestamp, update_user, penalty, supplemental_report_id, supplemental_report_assessment_description_id) FROM '$$PATH$$/4648.dat';

--
-- Data for Name: supplemental_report_assessment_comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplemental_report_assessment_comment (id, create_timestamp, create_user, update_timestamp, update_user, to_director, assessment_comment, supplemental_report_id) FROM stdin;
\.
COPY public.supplemental_report_assessment_comment (id, create_timestamp, create_user, update_timestamp, update_user, to_director, assessment_comment, supplemental_report_id) FROM '$$PATH$$/4649.dat';

--
-- Data for Name: supplemental_report_comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplemental_report_comment (id, create_timestamp, create_user, update_timestamp, update_user, to_govt, comment, supplemental_report_id) FROM stdin;
\.
COPY public.supplemental_report_comment (id, create_timestamp, create_user, update_timestamp, update_user, to_govt, comment, supplemental_report_id) FROM '$$PATH$$/4652.dat';

--
-- Data for Name: supplemental_report_credit_activity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplemental_report_credit_activity (id, create_timestamp, create_user, update_timestamp, update_user, credit_a_value, credit_b_value, category, model_year_id, supplemental_report_id) FROM stdin;
\.
COPY public.supplemental_report_credit_activity (id, create_timestamp, create_user, update_timestamp, update_user, credit_a_value, credit_b_value, category, model_year_id, supplemental_report_id) FROM '$$PATH$$/4654.dat';

--
-- Data for Name: supplemental_report_file_attachment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplemental_report_file_attachment (id, create_timestamp, create_user, update_timestamp, update_user, filename, minio_object_name, size, mime_type, is_removed, supplemental_report_id) FROM stdin;
\.
COPY public.supplemental_report_file_attachment (id, create_timestamp, create_user, update_timestamp, update_user, filename, minio_object_name, size, mime_type, is_removed, supplemental_report_id) FROM '$$PATH$$/4656.dat';

--
-- Data for Name: supplemental_report_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplemental_report_history (id, create_timestamp, create_user, update_timestamp, update_user, validation_status, supplemental_report_id) FROM stdin;
\.
COPY public.supplemental_report_history (id, create_timestamp, create_user, update_timestamp, update_user, validation_status, supplemental_report_id) FROM '$$PATH$$/4658.dat';

--
-- Data for Name: supplemental_report_sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplemental_report_sales (id, create_timestamp, create_user, update_timestamp, update_user, sales, make, model_name, range, model_year, model_year_report_vehicle_id, supplemental_report_id, vehicle_zev_type, zev_class, supplemental_origin_zev_sale_id) FROM stdin;
\.
COPY public.supplemental_report_sales (id, create_timestamp, create_user, update_timestamp, update_user, sales, make, model_name, range, model_year, model_year_report_vehicle_id, supplemental_report_id, vehicle_zev_type, zev_class, supplemental_origin_zev_sale_id) FROM '$$PATH$$/4661.dat';

--
-- Data for Name: supplemental_report_supplier_information; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplemental_report_supplier_information (id, create_timestamp, create_user, update_timestamp, update_user, category, value, supplemental_report_id) FROM stdin;
\.
COPY public.supplemental_report_supplier_information (id, create_timestamp, create_user, update_timestamp, update_user, category, value, supplemental_report_id) FROM '$$PATH$$/4663.dat';

--
-- Data for Name: user_creation_request; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_creation_request (id, create_timestamp, update_timestamp, keycloak_email, external_username, is_mapped, user_profile_id, create_user, update_user) FROM stdin;
\.
COPY public.user_creation_request (id, create_timestamp, update_timestamp, keycloak_email, external_username, is_mapped, user_profile_id, create_user, update_user) FROM '$$PATH$$/4665.dat';

--
-- Data for Name: user_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_profile (id, create_timestamp, update_timestamp, first_name, last_name, email, phone, username, organization_id, display_name, is_active, keycloak_email, title, create_user, update_user, keycloak_user_id) FROM stdin;
\.
COPY public.user_profile (id, create_timestamp, update_timestamp, first_name, last_name, email, phone, username, organization_id, display_name, is_active, keycloak_email, title, create_user, update_user, keycloak_user_id) FROM '$$PATH$$/4667.dat';

--
-- Data for Name: user_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_role (id, create_timestamp, update_timestamp, role_id, user_profile_id, create_user, update_user) FROM stdin;
\.
COPY public.user_role (id, create_timestamp, update_timestamp, role_id, user_profile_id, create_user, update_user) FROM '$$PATH$$/4669.dat';

--
-- Data for Name: vehicle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle (id, create_timestamp, update_timestamp, range, make, model_year_id, validation_status, model_name, credit_value, vehicle_zev_type_id, vehicle_class_code_id, weight_kg, organization_id, create_user, update_user, credit_class_id, has_passed_us_06_test, is_active) FROM stdin;
\.
COPY public.vehicle (id, create_timestamp, update_timestamp, range, make, model_year_id, validation_status, model_name, credit_value, vehicle_zev_type_id, vehicle_class_code_id, weight_kg, organization_id, create_user, update_user, credit_class_id, has_passed_us_06_test, is_active) FROM '$$PATH$$/4671.dat';

--
-- Data for Name: vehicle_change_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_change_history (id, create_timestamp, vehicle_id, model_name, model_year_id, range, user_role, validation_status, vehicle_zev_type_id, make, vehicle_class_code_id, weight_kg, organization_id, create_user) FROM stdin;
\.
COPY public.vehicle_change_history (id, create_timestamp, vehicle_id, model_name, model_year_id, range, user_role, validation_status, vehicle_zev_type_id, make, vehicle_class_code_id, weight_kg, organization_id, create_user) FROM '$$PATH$$/4506.dat';

--
-- Data for Name: vehicle_class_code; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_class_code (id, create_timestamp, update_timestamp, effective_date, expiration_date, description, vehicle_class_code, create_user, update_user) FROM stdin;
\.
COPY public.vehicle_class_code (id, create_timestamp, update_timestamp, effective_date, expiration_date, description, vehicle_class_code, create_user, update_user) FROM '$$PATH$$/4672.dat';

--
-- Data for Name: vehicle_comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_comment (id, create_timestamp, create_user, update_timestamp, update_user, vehicle_comment, vehicle_id) FROM stdin;
\.
COPY public.vehicle_comment (id, create_timestamp, create_user, update_timestamp, update_user, vehicle_comment, vehicle_id) FROM '$$PATH$$/4674.dat';

--
-- Data for Name: vehicle_file_attachment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_file_attachment (id, create_timestamp, create_user, update_timestamp, update_user, filename, minio_object_name, size, mime_type, is_removed, vehicle_id) FROM stdin;
\.
COPY public.vehicle_file_attachment (id, create_timestamp, create_user, update_timestamp, update_user, filename, minio_object_name, size, mime_type, is_removed, vehicle_id) FROM '$$PATH$$/4676.dat';

--
-- Data for Name: vehicle_zev_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_zev_type (id, create_timestamp, update_timestamp, effective_date, expiration_date, description, vehicle_zev_code, create_user, update_user) FROM stdin;
\.
COPY public.vehicle_zev_type (id, create_timestamp, update_timestamp, effective_date, expiration_date, description, vehicle_zev_code, create_user, update_user) FROM '$$PATH$$/4679.dat';

--
-- Data for Name: weight_class_code; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.weight_class_code (id, create_timestamp, create_user, update_timestamp, update_user, effective_date, expiration_date, weight_class_code, description) FROM stdin;
\.
COPY public.weight_class_code (id, create_timestamp, create_user, update_timestamp, update_user, effective_date, expiration_date, weight_class_code, description) FROM '$$PATH$$/4681.dat';

--
-- Data for Name: logged_actions; Type: TABLE DATA; Schema: zeva_audit; Owner: -
--

COPY zeva_audit.logged_actions (event_id, schema_name, table_name, relid, session_user_name, action_tstamp_tx, client_query, action, statement_only) FROM stdin;
\.
COPY zeva_audit.logged_actions (event_id, schema_name, table_name, relid, session_user_name, action_tstamp_tx, client_query, action, statement_only) FROM '$$PATH$$/4683.dat';

--
-- Name: address_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.address_type_id_seq', 35, true);


--
-- Name: api_vehiclechangehistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_vehiclechangehistory_id_seq', 965, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 775, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, false);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: compliance_ratio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.compliance_ratio_id_seq', 33, true);


--
-- Name: credit_agreement_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_agreement_comment_id_seq', 198, true);


--
-- Name: credit_agreement_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_agreement_content_id_seq', 271, true);


--
-- Name: credit_agreement_credit_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_agreement_credit_transaction_id_seq', 256, true);


--
-- Name: credit_agreement_file_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_agreement_file_attachment_id_seq', 2, true);


--
-- Name: credit_agreement_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_agreement_history_id_seq', 471, true);


--
-- Name: credit_agreement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_agreement_id_seq', 266, true);


--
-- Name: credit_class_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_class_code_id_seq', 35, true);


--
-- Name: credit_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_transaction_id_seq', 1254, true);


--
-- Name: credit_transaction_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_transaction_type_id_seq', 37, true);


--
-- Name: credit_transfer_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_transfer_comment_id_seq', 365, true);


--
-- Name: credit_transfer_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_transfer_content_id_seq', 262, true);


--
-- Name: credit_transfer_credit_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_transfer_credit_transaction_id_seq', 248, true);


--
-- Name: credit_transfer_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_transfer_history_id_seq', 515, true);


--
-- Name: credit_transfer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_transfer_id_seq', 260, true);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_celery_beat_clockedschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_celery_beat_crontabschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_celery_beat_intervalschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_celery_beat_periodictask_id_seq', 1, false);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_celery_beat_solarschedule_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 183, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 521, true);


--
-- Name: fixture_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fixture_migrations_id_seq', 229, true);


--
-- Name: icbc_registration_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.icbc_registration_data_id_seq', 464698, true);


--
-- Name: icbc_snapshot_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.icbc_snapshot_data_id_seq', 166794, true);


--
-- Name: icbc_upload_date_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.icbc_upload_date_id_seq', 570, true);


--
-- Name: icbc_vehicle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.icbc_vehicle_id_seq', 21372, true);


--
-- Name: model_year_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_id_seq', 143, true);


--
-- Name: model_year_report_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_address_id_seq', 845, true);


--
-- Name: model_year_report_adjustment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_adjustment_id_seq', 1, false);


--
-- Name: model_year_report_assessment_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_assessment_comment_id_seq', 483, true);


--
-- Name: model_year_report_assessment_descriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_assessment_descriptions_id_seq', 42, true);


--
-- Name: model_year_report_assessment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_assessment_id_seq', 319, true);


--
-- Name: model_year_report_compliance_obligation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_compliance_obligation_id_seq', 4622, true);


--
-- Name: model_year_report_confirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_confirmation_id_seq', 928, true);


--
-- Name: model_year_report_credit_offset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_credit_offset_id_seq', 1, false);


--
-- Name: model_year_report_credit_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_credit_transaction_id_seq', 447, true);


--
-- Name: model_year_report_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_history_id_seq', 1266, true);


--
-- Name: model_year_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_id_seq', 513, true);


--
-- Name: model_year_report_ldv_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_ldv_sales_id_seq', 1074, true);


--
-- Name: model_year_report_make_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_make_id_seq', 775, true);


--
-- Name: model_year_report_vehicle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_year_report_vehicle_id_seq', 389, true);


--
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_id_seq', 170, true);


--
-- Name: notification_subscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_subscription_id_seq', 1838, true);


--
-- Name: organization_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_address_id_seq', 385, true);


--
-- Name: organization_deficits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_deficits_id_seq', 111, true);


--
-- Name: organization_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_id_seq', 95, true);


--
-- Name: organization_ldv_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_ldv_sales_id_seq', 420, true);


--
-- Name: permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permission_id_seq', 160, true);


--
-- Name: record_of_sale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.record_of_sale_id_seq', 187386, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_id_seq', 46, true);


--
-- Name: role_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_permission_id_seq', 220, true);


--
-- Name: sale_submission_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_submission_content_id_seq', 131214, true);


--
-- Name: sale_submission_file_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_submission_file_attachment_id_seq', 375, true);


--
-- Name: sales_forecast_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_forecast_id_seq', 86, true);


--
-- Name: sales_forecast_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_forecast_record_id_seq', 80, true);


--
-- Name: sales_submission_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_submission_comment_id_seq', 822, true);


--
-- Name: sales_submission_content_reason_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_submission_content_reason_id_seq', 33, true);


--
-- Name: sales_submission_credit_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_submission_credit_transaction_id_seq', 771, true);


--
-- Name: sales_submission_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_submission_history_id_seq', 1708, true);


--
-- Name: sales_submission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_submission_id_seq', 707, true);


--
-- Name: signing_authority_assertion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.signing_authority_assertion_id_seq', 89, true);


--
-- Name: signing_authority_confirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.signing_authority_confirmation_id_seq', 426, true);


--
-- Name: supplemental_report_assessment_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplemental_report_assessment_comment_id_seq', 273, true);


--
-- Name: supplemental_report_assessment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplemental_report_assessment_id_seq', 249, true);


--
-- Name: supplemental_report_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplemental_report_comment_id_seq', 33, true);


--
-- Name: supplemental_report_credit_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplemental_report_credit_activity_id_seq', 826, true);


--
-- Name: supplemental_report_file_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplemental_report_file_attachment_id_seq', 1, true);


--
-- Name: supplemental_report_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplemental_report_history_id_seq', 388, true);


--
-- Name: supplemental_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplemental_report_id_seq', 301, true);


--
-- Name: supplemental_report_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplemental_report_sales_id_seq', 221, true);


--
-- Name: supplemental_report_supplier_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplemental_report_supplier_information_id_seq', 78, true);


--
-- Name: user_creation_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_creation_request_id_seq', 1, false);


--
-- Name: user_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_profile_id_seq', 660, true);


--
-- Name: user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_role_id_seq', 1144, true);


--
-- Name: vehicle_class_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_class_code_id_seq', 16, true);


--
-- Name: vehicle_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_comment_id_seq', 334, true);


--
-- Name: vehicle_file_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_file_attachment_id_seq', 254, true);


--
-- Name: vehicle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_id_seq', 976, true);


--
-- Name: vehicle_zev_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_zev_type_id_seq', 8, true);


--
-- Name: weight_class_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.weight_class_code_id_seq', 2, true);


--
-- Name: logged_actions_event_id_seq; Type: SEQUENCE SET; Schema: zeva_audit; Owner: -
--

SELECT pg_catalog.setval('zeva_audit.logged_actions_event_id_seq', 1, false);


--
-- Name: address_type address_type_address_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_type
    ADD CONSTRAINT address_type_address_type_key UNIQUE (address_type);


--
-- Name: address_type address_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_type
    ADD CONSTRAINT address_type_pkey PRIMARY KEY (id);


--
-- Name: vehicle_change_history api_vehiclechangehistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_change_history
    ADD CONSTRAINT api_vehiclechangehistory_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: compliance_ratio compliance_ratio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_ratio
    ADD CONSTRAINT compliance_ratio_pkey PRIMARY KEY (id);


--
-- Name: credit_agreement_comment credit_agreement_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_comment
    ADD CONSTRAINT credit_agreement_comment_pkey PRIMARY KEY (id);


--
-- Name: credit_agreement_content credit_agreement_content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_content
    ADD CONSTRAINT credit_agreement_content_pkey PRIMARY KEY (id);


--
-- Name: credit_agreement_credit_transaction credit_agreement_credit_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_credit_transaction
    ADD CONSTRAINT credit_agreement_credit_transaction_pkey PRIMARY KEY (id);


--
-- Name: credit_agreement_file_attachment credit_agreement_file_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_file_attachment
    ADD CONSTRAINT credit_agreement_file_attachment_pkey PRIMARY KEY (id);


--
-- Name: credit_agreement_history credit_agreement_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_history
    ADD CONSTRAINT credit_agreement_history_pkey PRIMARY KEY (id);


--
-- Name: credit_agreement credit_agreement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement
    ADD CONSTRAINT credit_agreement_pkey PRIMARY KEY (id);


--
-- Name: credit_class_code credit_class_code_credit_class_0c2ae991_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_class_code
    ADD CONSTRAINT credit_class_code_credit_class_0c2ae991_uniq UNIQUE (credit_class);


--
-- Name: credit_class_code credit_class_code_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_class_code
    ADD CONSTRAINT credit_class_code_pkey PRIMARY KEY (id);


--
-- Name: credit_transaction credit_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction
    ADD CONSTRAINT credit_transaction_pkey PRIMARY KEY (id);


--
-- Name: credit_transaction_type credit_transaction_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction_type
    ADD CONSTRAINT credit_transaction_type_pkey PRIMARY KEY (id);


--
-- Name: credit_transaction_type credit_transaction_type_transaction_type_10bf3375_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction_type
    ADD CONSTRAINT credit_transaction_type_transaction_type_10bf3375_uniq UNIQUE (transaction_type);


--
-- Name: credit_transfer_comment credit_transfer_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_comment
    ADD CONSTRAINT credit_transfer_comment_pkey PRIMARY KEY (id);


--
-- Name: credit_transfer_content credit_transfer_content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_content
    ADD CONSTRAINT credit_transfer_content_pkey PRIMARY KEY (id);


--
-- Name: credit_transfer_credit_transaction credit_transfer_credit_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_credit_transaction
    ADD CONSTRAINT credit_transfer_credit_transaction_pkey PRIMARY KEY (id);


--
-- Name: credit_transfer_history credit_transfer_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_history
    ADD CONSTRAINT credit_transfer_history_pkey PRIMARY KEY (id);


--
-- Name: credit_transfer credit_transfer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer
    ADD CONSTRAINT credit_transfer_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_clockedschedule django_celery_beat_clockedschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule
    ADD CONSTRAINT django_celery_beat_clockedschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_crontabschedule django_celery_beat_crontabschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule
    ADD CONSTRAINT django_celery_beat_crontabschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_intervalschedule django_celery_beat_intervalschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule
    ADD CONSTRAINT django_celery_beat_intervalschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_name_key UNIQUE (name);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictasks django_celery_beat_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_periodictasks
    ADD CONSTRAINT django_celery_beat_periodictasks_pkey PRIMARY KEY (ident);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq UNIQUE (event, latitude, longitude);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solarschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solarschedule_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: fixture_migrations fixture_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixture_migrations
    ADD CONSTRAINT fixture_migrations_pkey PRIMARY KEY (id);


--
-- Name: icbc_registration_data icbc_registration_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_registration_data
    ADD CONSTRAINT icbc_registration_data_pkey PRIMARY KEY (id);


--
-- Name: icbc_registration_data icbc_registration_data_vin_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_registration_data
    ADD CONSTRAINT icbc_registration_data_vin_key UNIQUE (vin);


--
-- Name: icbc_snapshot_data icbc_snapshot_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_snapshot_data
    ADD CONSTRAINT icbc_snapshot_data_pkey PRIMARY KEY (id);


--
-- Name: icbc_upload_date icbc_upload_date_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_upload_date
    ADD CONSTRAINT icbc_upload_date_pkey PRIMARY KEY (id);


--
-- Name: icbc_vehicle icbc_vehicle_make_id_model_name_model_year_id_7e9d7e11_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_vehicle
    ADD CONSTRAINT icbc_vehicle_make_id_model_name_model_year_id_7e9d7e11_uniq UNIQUE (make, model_name, model_year_id);


--
-- Name: icbc_vehicle icbc_vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_vehicle
    ADD CONSTRAINT icbc_vehicle_pkey PRIMARY KEY (id);


--
-- Name: model_year model_year_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year
    ADD CONSTRAINT model_year_name_key UNIQUE (description);


--
-- Name: model_year model_year_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year
    ADD CONSTRAINT model_year_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_address model_year_report_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_address
    ADD CONSTRAINT model_year_report_address_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_adjustment model_year_report_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_adjustment
    ADD CONSTRAINT model_year_report_adjustment_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_assessment_comment model_year_report_assessment_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_assessment_comment
    ADD CONSTRAINT model_year_report_assessment_comment_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_assessment_descriptions model_year_report_assessment_descriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_assessment_descriptions
    ADD CONSTRAINT model_year_report_assessment_descriptions_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_assessment model_year_report_assessment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_assessment
    ADD CONSTRAINT model_year_report_assessment_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_compliance_obligation model_year_report_compliance_obligation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_compliance_obligation
    ADD CONSTRAINT model_year_report_compliance_obligation_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_confirmation model_year_report_confirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_confirmation
    ADD CONSTRAINT model_year_report_confirmation_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_credit_offset model_year_report_credit_offset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_credit_offset
    ADD CONSTRAINT model_year_report_credit_offset_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_credit_transaction model_year_report_credit_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_credit_transaction
    ADD CONSTRAINT model_year_report_credit_transaction_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_history model_year_report_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_history
    ADD CONSTRAINT model_year_report_history_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_ldv_sales model_year_report_ldv_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_ldv_sales
    ADD CONSTRAINT model_year_report_ldv_sales_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_make model_year_report_make_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_make
    ADD CONSTRAINT model_year_report_make_pkey PRIMARY KEY (id);


--
-- Name: model_year_report model_year_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report
    ADD CONSTRAINT model_year_report_pkey PRIMARY KEY (id);


--
-- Name: model_year_report_vehicle model_year_report_vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_vehicle
    ADD CONSTRAINT model_year_report_vehicle_pkey PRIMARY KEY (id);


--
-- Name: notification notification_notification_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_notification_code_key UNIQUE (notification_code);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: notification_subscription notification_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_subscription
    ADD CONSTRAINT notification_subscription_pkey PRIMARY KEY (id);


--
-- Name: organization_address organization_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_address
    ADD CONSTRAINT organization_address_pkey PRIMARY KEY (id);


--
-- Name: organization_deficits organization_deficits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_deficits
    ADD CONSTRAINT organization_deficits_pkey PRIMARY KEY (id);


--
-- Name: organization_ldv_sales organization_ldv_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_ldv_sales
    ADD CONSTRAINT organization_ldv_sales_pkey PRIMARY KEY (id);


--
-- Name: organization organization_name_7bf391ab_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_name_7bf391ab_uniq UNIQUE (organization_name);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: organization organization_short_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_short_name_key UNIQUE (short_name);


--
-- Name: permission permission_permission_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT permission_permission_code_key UNIQUE (permission_code);


--
-- Name: permission permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT permission_pkey PRIMARY KEY (id);


--
-- Name: record_of_sale record_of_sale_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_of_sale
    ADD CONSTRAINT record_of_sale_pkey PRIMARY KEY (id);


--
-- Name: role_permission role_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_pkey PRIMARY KEY (id);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: role role_role_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_role_code_key UNIQUE (role_code);


--
-- Name: sales_submission_content sale_submission_content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_content
    ADD CONSTRAINT sale_submission_content_pkey PRIMARY KEY (id);


--
-- Name: sales_submission_evidence sale_submission_file_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_evidence
    ADD CONSTRAINT sale_submission_file_attachment_pkey PRIMARY KEY (id);


--
-- Name: sales_forecast sales_forecast_model_year_report_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_forecast
    ADD CONSTRAINT sales_forecast_model_year_report_id_key UNIQUE (model_year_report_id);


--
-- Name: sales_forecast sales_forecast_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_forecast
    ADD CONSTRAINT sales_forecast_pkey PRIMARY KEY (id);


--
-- Name: sales_forecast_record sales_forecast_record_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_forecast_record
    ADD CONSTRAINT sales_forecast_record_pkey PRIMARY KEY (id);


--
-- Name: sales_submission_comment sales_submission_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_comment
    ADD CONSTRAINT sales_submission_comment_pkey PRIMARY KEY (id);


--
-- Name: sales_submission_content_reason sales_submission_content_reason_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_content_reason
    ADD CONSTRAINT sales_submission_content_reason_pkey PRIMARY KEY (id);


--
-- Name: sales_submission_credit_transaction sales_submission_credit_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_credit_transaction
    ADD CONSTRAINT sales_submission_credit_transaction_pkey PRIMARY KEY (id);


--
-- Name: sales_submission_history sales_submission_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_history
    ADD CONSTRAINT sales_submission_history_pkey PRIMARY KEY (id);


--
-- Name: sales_submission sales_submission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission
    ADD CONSTRAINT sales_submission_pkey PRIMARY KEY (id);


--
-- Name: sales_submission sales_submission_submission_date_submissi_fa81ade9_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission
    ADD CONSTRAINT sales_submission_submission_date_submissi_fa81ade9_uniq UNIQUE (submission_date, submission_sequence, organization_id);


--
-- Name: signing_authority_assertion signing_authority_assertion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.signing_authority_assertion
    ADD CONSTRAINT signing_authority_assertion_pkey PRIMARY KEY (id);


--
-- Name: signing_authority_confirmation signing_authority_confirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.signing_authority_confirmation
    ADD CONSTRAINT signing_authority_confirmation_pkey PRIMARY KEY (id);


--
-- Name: supplemental_report_assessment_comment supplemental_report_assessment_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_assessment_comment
    ADD CONSTRAINT supplemental_report_assessment_comment_pkey PRIMARY KEY (id);


--
-- Name: supplemental_report_assessment supplemental_report_assessment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_assessment
    ADD CONSTRAINT supplemental_report_assessment_pkey PRIMARY KEY (id);


--
-- Name: supplemental_report_comment supplemental_report_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_comment
    ADD CONSTRAINT supplemental_report_comment_pkey PRIMARY KEY (id);


--
-- Name: supplemental_report_credit_activity supplemental_report_credit_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_credit_activity
    ADD CONSTRAINT supplemental_report_credit_activity_pkey PRIMARY KEY (id);


--
-- Name: supplemental_report_file_attachment supplemental_report_file_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_file_attachment
    ADD CONSTRAINT supplemental_report_file_attachment_pkey PRIMARY KEY (id);


--
-- Name: supplemental_report_history supplemental_report_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_history
    ADD CONSTRAINT supplemental_report_history_pkey PRIMARY KEY (id);


--
-- Name: supplemental_report supplemental_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report
    ADD CONSTRAINT supplemental_report_pkey PRIMARY KEY (id);


--
-- Name: supplemental_report_sales supplemental_report_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_sales
    ADD CONSTRAINT supplemental_report_sales_pkey PRIMARY KEY (id);


--
-- Name: supplemental_report_supplier_information supplemental_report_supplier_information_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_supplier_information
    ADD CONSTRAINT supplemental_report_supplier_information_pkey PRIMARY KEY (id);


--
-- Name: user_creation_request user_creation_request_keycloak_email_external__4432ed53_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_creation_request
    ADD CONSTRAINT user_creation_request_keycloak_email_external__4432ed53_uniq UNIQUE (keycloak_email, external_username);


--
-- Name: user_creation_request user_creation_request_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_creation_request
    ADD CONSTRAINT user_creation_request_pkey PRIMARY KEY (id);


--
-- Name: user_creation_request user_creation_request_user_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_creation_request
    ADD CONSTRAINT user_creation_request_user_profile_id_key UNIQUE (user_profile_id);


--
-- Name: user_profile user_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_profile
    ADD CONSTRAINT user_profile_pkey PRIMARY KEY (id);


--
-- Name: user_profile user_profile_username_f86c0c97_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_profile
    ADD CONSTRAINT user_profile_username_f86c0c97_uniq UNIQUE (username);


--
-- Name: user_role user_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_pkey PRIMARY KEY (id);


--
-- Name: vehicle_class_code vehicle_class_code_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_class_code
    ADD CONSTRAINT vehicle_class_code_pkey PRIMARY KEY (id);


--
-- Name: vehicle_class_code vehicle_class_code_vehicle_class_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_class_code
    ADD CONSTRAINT vehicle_class_code_vehicle_class_code_key UNIQUE (vehicle_class_code);


--
-- Name: vehicle_comment vehicle_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_comment
    ADD CONSTRAINT vehicle_comment_pkey PRIMARY KEY (id);


--
-- Name: vehicle_file_attachment vehicle_file_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_file_attachment
    ADD CONSTRAINT vehicle_file_attachment_pkey PRIMARY KEY (id);


--
-- Name: vehicle vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT vehicle_pkey PRIMARY KEY (id);


--
-- Name: vehicle_zev_type vehicle_zev_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_zev_type
    ADD CONSTRAINT vehicle_zev_type_pkey PRIMARY KEY (id);


--
-- Name: vehicle_zev_type vehicle_zev_type_vehicle_zev_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_zev_type
    ADD CONSTRAINT vehicle_zev_type_vehicle_zev_code_key UNIQUE (vehicle_zev_code);


--
-- Name: weight_class_code weight_class_code_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_class_code
    ADD CONSTRAINT weight_class_code_pkey PRIMARY KEY (id);


--
-- Name: weight_class_code weight_class_code_weight_class_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_class_code
    ADD CONSTRAINT weight_class_code_weight_class_code_key UNIQUE (weight_class_code);


--
-- Name: logged_actions logged_actions_pkey; Type: CONSTRAINT; Schema: zeva_audit; Owner: -
--

ALTER TABLE ONLY zeva_audit.logged_actions
    ADD CONSTRAINT logged_actions_pkey PRIMARY KEY (event_id);


--
-- Name: address_type_address_type_2e682c39_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX address_type_address_type_2e682c39_like ON public.address_type USING btree (address_type varchar_pattern_ops);


--
-- Name: api_vehiclechangehistory_vehicle_id_d8728c64; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX api_vehiclechangehistory_vehicle_id_d8728c64 ON public.vehicle_change_history USING btree (vehicle_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: credit_agreement_comment_credit_agreement_id_99636959; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_agreement_comment_credit_agreement_id_99636959 ON public.credit_agreement_comment USING btree (credit_agreement_id);


--
-- Name: credit_agreement_content_credit_agreement_id_4255d4f9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_agreement_content_credit_agreement_id_4255d4f9 ON public.credit_agreement_content USING btree (credit_agreement_id);


--
-- Name: credit_agreement_content_credit_class_id_0540ae6b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_agreement_content_credit_class_id_0540ae6b ON public.credit_agreement_content USING btree (credit_class_id);


--
-- Name: credit_agreement_content_model_year_id_0406c15e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_agreement_content_model_year_id_0406c15e ON public.credit_agreement_content USING btree (model_year_id);


--
-- Name: credit_agreement_credit_tr_credit_agreement_id_40bf067c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_agreement_credit_tr_credit_agreement_id_40bf067c ON public.credit_agreement_credit_transaction USING btree (credit_agreement_id);


--
-- Name: credit_agreement_credit_tr_credit_transaction_id_ea870f1a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_agreement_credit_tr_credit_transaction_id_ea870f1a ON public.credit_agreement_credit_transaction USING btree (credit_transaction_id);


--
-- Name: credit_agreement_file_attachment_credit_agreement_id_b4fe3f4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_agreement_file_attachment_credit_agreement_id_b4fe3f4f ON public.credit_agreement_file_attachment USING btree (credit_agreement_id);


--
-- Name: credit_agreement_history_credit_agreement_id_34353eb7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_agreement_history_credit_agreement_id_34353eb7 ON public.credit_agreement_history USING btree (credit_agreement_id);


--
-- Name: credit_agreement_model_year_report_id_3fc5fa02; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_agreement_model_year_report_id_3fc5fa02 ON public.credit_agreement USING btree (model_year_report_id);


--
-- Name: credit_agreement_organization_id_8605a62d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_agreement_organization_id_8605a62d ON public.credit_agreement USING btree (organization_id);


--
-- Name: credit_class_credit_class_7c159529_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_class_credit_class_7c159529_like ON public.credit_class_code USING btree (credit_class varchar_pattern_ops);


--
-- Name: credit_transaction_credit_class_id_bbf2d758; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transaction_credit_class_id_bbf2d758 ON public.credit_transaction USING btree (credit_class_id);


--
-- Name: credit_transaction_credit_to_id_4c437b49; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transaction_credit_to_id_4c437b49 ON public.credit_transaction USING btree (credit_to_id);


--
-- Name: credit_transaction_debit_from_id_d83b1367; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transaction_debit_from_id_d83b1367 ON public.credit_transaction USING btree (debit_from_id);


--
-- Name: credit_transaction_model_year_id_04cd4baf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transaction_model_year_id_04cd4baf ON public.credit_transaction USING btree (model_year_id);


--
-- Name: credit_transaction_transaction_type_id_409914b1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transaction_transaction_type_id_409914b1 ON public.credit_transaction USING btree (transaction_type_id);


--
-- Name: credit_transaction_type_transaction_type_10bf3375_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transaction_type_transaction_type_10bf3375_like ON public.credit_transaction_type USING btree (transaction_type varchar_pattern_ops);


--
-- Name: credit_transaction_weight_class_id_a9983b87; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transaction_weight_class_id_a9983b87 ON public.credit_transaction USING btree (weight_class_id);


--
-- Name: credit_transfer_comment_credit_transfer_history_id_4f943e5b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transfer_comment_credit_transfer_history_id_4f943e5b ON public.credit_transfer_comment USING btree (credit_transfer_history_id);


--
-- Name: credit_transfer_content_credit_class_id_62bd28df; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transfer_content_credit_class_id_62bd28df ON public.credit_transfer_content USING btree (credit_class_id);


--
-- Name: credit_transfer_content_credit_transfer_id_016efc66; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transfer_content_credit_transfer_id_016efc66 ON public.credit_transfer_content USING btree (credit_transfer_id);


--
-- Name: credit_transfer_content_model_year_id_bc68a3a1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transfer_content_model_year_id_bc68a3a1 ON public.credit_transfer_content USING btree (model_year_id);


--
-- Name: credit_transfer_content_weight_class_id_53f61b3c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transfer_content_weight_class_id_53f61b3c ON public.credit_transfer_content USING btree (weight_class_id);


--
-- Name: credit_transfer_credit_to_id_4efce8c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transfer_credit_to_id_4efce8c0 ON public.credit_transfer USING btree (credit_to_id);


--
-- Name: credit_transfer_credit_tra_credit_transaction_id_c1a119d5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transfer_credit_tra_credit_transaction_id_c1a119d5 ON public.credit_transfer_credit_transaction USING btree (credit_transaction_id);


--
-- Name: credit_transfer_credit_transaction_credit_transfer_id_b86b0303; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transfer_credit_transaction_credit_transfer_id_b86b0303 ON public.credit_transfer_credit_transaction USING btree (credit_transfer_id);


--
-- Name: credit_transfer_debit_from_id_a7a6116e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transfer_debit_from_id_a7a6116e ON public.credit_transfer USING btree (debit_from_id);


--
-- Name: credit_transfer_history_transfer_id_ddf6fd97; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credit_transfer_history_transfer_id_ddf6fd97 ON public.credit_transfer_history USING btree (transfer_id);


--
-- Name: django_celery_beat_periodictask_clocked_id_47a69f82; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_celery_beat_periodictask_clocked_id_47a69f82 ON public.django_celery_beat_periodictask USING btree (clocked_id);


--
-- Name: django_celery_beat_periodictask_crontab_id_d3cba168; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_celery_beat_periodictask_crontab_id_d3cba168 ON public.django_celery_beat_periodictask USING btree (crontab_id);


--
-- Name: django_celery_beat_periodictask_interval_id_a8ca27da; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_celery_beat_periodictask_interval_id_a8ca27da ON public.django_celery_beat_periodictask USING btree (interval_id);


--
-- Name: django_celery_beat_periodictask_name_265a36b7_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_celery_beat_periodictask_name_265a36b7_like ON public.django_celery_beat_periodictask USING btree (name varchar_pattern_ops);


--
-- Name: django_celery_beat_periodictask_solar_id_a87ce72c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_celery_beat_periodictask_solar_id_a87ce72c ON public.django_celery_beat_periodictask USING btree (solar_id);


--
-- Name: icbc_registration_data_icbc_upload_date_id_f24b9312; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_registration_data_icbc_upload_date_id_f24b9312 ON public.icbc_registration_data USING btree (icbc_upload_date_id);


--
-- Name: icbc_registration_data_icbc_vehicle_id_7572c491; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_registration_data_icbc_vehicle_id_7572c491 ON public.icbc_registration_data USING btree (icbc_vehicle_id);


--
-- Name: icbc_registration_data_vin_584ef05c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_registration_data_vin_584ef05c_like ON public.icbc_registration_data USING btree (vin varchar_pattern_ops);


--
-- Name: icbc_snapshot_data_make_1468b4bc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_snapshot_data_make_1468b4bc ON public.icbc_snapshot_data USING btree (make);


--
-- Name: icbc_snapshot_data_make_1468b4bc_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_snapshot_data_make_1468b4bc_like ON public.icbc_snapshot_data USING btree (make varchar_pattern_ops);


--
-- Name: icbc_snapshot_data_model_name_ff9349fc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_snapshot_data_model_name_ff9349fc ON public.icbc_snapshot_data USING btree (model_name);


--
-- Name: icbc_snapshot_data_model_name_ff9349fc_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_snapshot_data_model_name_ff9349fc_like ON public.icbc_snapshot_data USING btree (model_name varchar_pattern_ops);


--
-- Name: icbc_snapshot_data_submission_id_4212e6a0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_snapshot_data_submission_id_4212e6a0 ON public.icbc_snapshot_data USING btree (submission_id);


--
-- Name: icbc_snapshot_data_vin_a8755607; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_snapshot_data_vin_a8755607 ON public.icbc_snapshot_data USING btree (vin);


--
-- Name: icbc_snapshot_data_vin_a8755607_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_snapshot_data_vin_a8755607_like ON public.icbc_snapshot_data USING btree (vin varchar_pattern_ops);


--
-- Name: icbc_vehicle_make_52da2080; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_vehicle_make_52da2080 ON public.icbc_vehicle USING btree (make);


--
-- Name: icbc_vehicle_make_52da2080_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_vehicle_make_52da2080_like ON public.icbc_vehicle USING btree (make varchar_pattern_ops);


--
-- Name: icbc_vehicle_make_model_name_model_year_id_9305170f_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_vehicle_make_model_name_model_year_id_9305170f_idx ON public.icbc_vehicle USING btree (make, model_name, model_year_id);


--
-- Name: icbc_vehicle_model_name_1a8aedb9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_vehicle_model_name_1a8aedb9 ON public.icbc_vehicle USING btree (model_name);


--
-- Name: icbc_vehicle_model_name_1a8aedb9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_vehicle_model_name_1a8aedb9_like ON public.icbc_vehicle USING btree (model_name varchar_pattern_ops);


--
-- Name: icbc_vehicle_model_year_id_25b707e0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX icbc_vehicle_model_year_id_25b707e0 ON public.icbc_vehicle USING btree (model_year_id);


--
-- Name: model_year_name_f93b98b1_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_name_f93b98b1_like ON public.model_year USING btree (description varchar_pattern_ops);


--
-- Name: model_year_report_address_address_type_id_b8e9034c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_address_address_type_id_b8e9034c ON public.model_year_report_address USING btree (address_type_id);


--
-- Name: model_year_report_address_model_year_report_id_22bb07b9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_address_model_year_report_id_22bb07b9 ON public.model_year_report_address USING btree (model_year_report_id);


--
-- Name: model_year_report_adjustment_credit_class_id_1d1579f4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_adjustment_credit_class_id_1d1579f4 ON public.model_year_report_adjustment USING btree (credit_class_id);


--
-- Name: model_year_report_adjustment_model_year_id_ee0e4981; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_adjustment_model_year_id_ee0e4981 ON public.model_year_report_adjustment USING btree (model_year_id);


--
-- Name: model_year_report_adjustment_model_year_report_id_ee739661; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_adjustment_model_year_report_id_ee739661 ON public.model_year_report_adjustment USING btree (model_year_report_id);


--
-- Name: model_year_report_assessme_model_year_report_assessme_5f4015a1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_assessme_model_year_report_assessme_5f4015a1 ON public.model_year_report_assessment USING btree (model_year_report_assessment_description_id);


--
-- Name: model_year_report_assessme_model_year_report_id_49f26b96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_assessme_model_year_report_id_49f26b96 ON public.model_year_report_assessment_comment USING btree (model_year_report_id);


--
-- Name: model_year_report_assessment_model_year_report_id_d6cc53b4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_assessment_model_year_report_id_d6cc53b4 ON public.model_year_report_assessment USING btree (model_year_report_id);


--
-- Name: model_year_report_complian_model_year_report_id_a3ab5f15; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_complian_model_year_report_id_a3ab5f15 ON public.model_year_report_compliance_obligation USING btree (model_year_report_id);


--
-- Name: model_year_report_compliance_obligation_model_year_id_5b646f99; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_compliance_obligation_model_year_id_5b646f99 ON public.model_year_report_compliance_obligation USING btree (model_year_id);


--
-- Name: model_year_report_confirma_signing_authority_assertio_45189806; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_confirma_signing_authority_assertio_45189806 ON public.model_year_report_confirmation USING btree (signing_authority_assertion_id);


--
-- Name: model_year_report_confirmation_model_year_report_id_bd42ce9f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_confirmation_model_year_report_id_bd42ce9f ON public.model_year_report_confirmation USING btree (model_year_report_id);


--
-- Name: model_year_report_credit_offset_model_year_id_c24c331d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_credit_offset_model_year_id_c24c331d ON public.model_year_report_credit_offset USING btree (model_year_id);


--
-- Name: model_year_report_credit_offset_model_year_report_id_f26ce86a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_credit_offset_model_year_report_id_f26ce86a ON public.model_year_report_credit_offset USING btree (model_year_report_id);


--
-- Name: model_year_report_credit_t_credit_transaction_id_5ff28bfc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_credit_t_credit_transaction_id_5ff28bfc ON public.model_year_report_credit_transaction USING btree (credit_transaction_id);


--
-- Name: model_year_report_credit_t_model_year_report_id_68b95fb0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_credit_t_model_year_report_id_68b95fb0 ON public.model_year_report_credit_transaction USING btree (model_year_report_id);


--
-- Name: model_year_report_history_model_year_report_id_37063658; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_history_model_year_report_id_37063658 ON public.model_year_report_history USING btree (model_year_report_id);


--
-- Name: model_year_report_ldv_sales_model_year_id_cfa935ed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_ldv_sales_model_year_id_cfa935ed ON public.model_year_report_ldv_sales USING btree (model_year_id);


--
-- Name: model_year_report_ldv_sales_model_year_report_id_4f2d6b09; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_ldv_sales_model_year_report_id_4f2d6b09 ON public.model_year_report_ldv_sales USING btree (model_year_report_id);


--
-- Name: model_year_report_make_model_year_report_id_01799a27; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_make_model_year_report_id_01799a27 ON public.model_year_report_make USING btree (model_year_report_id);


--
-- Name: model_year_report_model_year_id_74554218; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_model_year_id_74554218 ON public.model_year_report USING btree (model_year_id);


--
-- Name: model_year_report_organization_id_c0665455; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_organization_id_c0665455 ON public.model_year_report USING btree (organization_id);


--
-- Name: model_year_report_vehicle_model_year_id_1fb2ce70; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_vehicle_model_year_id_1fb2ce70 ON public.model_year_report_vehicle USING btree (model_year_id);


--
-- Name: model_year_report_vehicle_model_year_report_id_ec5e1854; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_vehicle_model_year_report_id_ec5e1854 ON public.model_year_report_vehicle USING btree (model_year_report_id);


--
-- Name: model_year_report_vehicle_zev_class_id_39ede20a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_vehicle_zev_class_id_39ede20a ON public.model_year_report_vehicle USING btree (zev_class_id);


--
-- Name: model_year_report_vehicle_zev_type_id_5a321461; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_year_report_vehicle_zev_type_id_5a321461 ON public.model_year_report_vehicle USING btree (vehicle_zev_type_id);


--
-- Name: notification_notification_code_7554f7b7_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_notification_code_7554f7b7_like ON public.notification USING btree (notification_code varchar_pattern_ops);


--
-- Name: notification_permission_id_382f009d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_permission_id_382f009d ON public.notification USING btree (permission_id);


--
-- Name: notification_subscription_notification_id_99cf7e2d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_subscription_notification_id_99cf7e2d ON public.notification_subscription USING btree (notification_id);


--
-- Name: notification_subscription_user_profile_id_9e991605; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_subscription_user_profile_id_9e991605 ON public.notification_subscription USING btree (user_profile_id);


--
-- Name: organization_address_address_type_id_387ee3dc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_address_address_type_id_387ee3dc ON public.organization_address USING btree (address_type_id);


--
-- Name: organization_address_organization_id_2e03ad1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_address_organization_id_2e03ad1c ON public.organization_address USING btree (organization_id);


--
-- Name: organization_deficits_credit_class_id_68c970f4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_deficits_credit_class_id_68c970f4 ON public.organization_deficits USING btree (credit_class_id);


--
-- Name: organization_deficits_model_year_id_b8982ae9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_deficits_model_year_id_b8982ae9 ON public.organization_deficits USING btree (model_year_id);


--
-- Name: organization_deficits_organization_id_1a842417; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_deficits_organization_id_1a842417 ON public.organization_deficits USING btree (organization_id);


--
-- Name: organization_first_model_year_id_afc0b1d4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_first_model_year_id_afc0b1d4 ON public.organization USING btree (first_model_year_id);


--
-- Name: organization_ldv_sales_model_year_id_20b2b685; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_ldv_sales_model_year_id_20b2b685 ON public.organization_ldv_sales USING btree (model_year_id);


--
-- Name: organization_ldv_sales_organization_id_094faedd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_ldv_sales_organization_id_094faedd ON public.organization_ldv_sales USING btree (organization_id);


--
-- Name: organization_name_7bf391ab_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_name_7bf391ab_like ON public.organization USING btree (organization_name varchar_pattern_ops);


--
-- Name: organization_short_name_7c3c32d5_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_short_name_7c3c32d5_like ON public.organization USING btree (short_name varchar_pattern_ops);


--
-- Name: permission_permission_code_4462d737_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_permission_code_4462d737_like ON public.permission USING btree (permission_code varchar_pattern_ops);


--
-- Name: record_of_sale_icbc_snapshot_id_bbdec575; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX record_of_sale_icbc_snapshot_id_bbdec575 ON public.record_of_sale USING btree (icbc_snapshot_id);


--
-- Name: record_of_sale_submission_id_0145d9d1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX record_of_sale_submission_id_0145d9d1 ON public.record_of_sale USING btree (submission_id);


--
-- Name: record_of_sale_vehicle_id_1411d18a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX record_of_sale_vehicle_id_1411d18a ON public.record_of_sale USING btree (vehicle_id);


--
-- Name: role_permission_permission_id_ee9c5982; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX role_permission_permission_id_ee9c5982 ON public.role_permission USING btree (permission_id);


--
-- Name: role_permission_role_id_877a80a4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX role_permission_role_id_877a80a4 ON public.role_permission USING btree (role_id);


--
-- Name: role_role_code_1b19495b_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX role_role_code_1b19495b_like ON public.role USING btree (role_code varchar_pattern_ops);


--
-- Name: sale_submission_content_submission_id_28be2ed6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sale_submission_content_submission_id_28be2ed6 ON public.sales_submission_content USING btree (submission_id);


--
-- Name: sale_submission_file_attachment_submission_id_03bfc421; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sale_submission_file_attachment_submission_id_03bfc421 ON public.sales_submission_evidence USING btree (submission_id);


--
-- Name: sales_forecast_record_sales_forecast_id_d8dd4842; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_forecast_record_sales_forecast_id_d8dd4842 ON public.sales_forecast_record USING btree (sales_forecast_id);


--
-- Name: sales_submission_comment_sales_submission_id_4121699e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_comment_sales_submission_id_4121699e ON public.sales_submission_comment USING btree (sales_submission_id);


--
-- Name: sales_submission_content_xls_make_67d69aa9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_content_xls_make_67d69aa9 ON public.sales_submission_content USING btree (xls_make);


--
-- Name: sales_submission_content_xls_make_67d69aa9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_content_xls_make_67d69aa9_like ON public.sales_submission_content USING btree (xls_make varchar_pattern_ops);


--
-- Name: sales_submission_content_xls_model_44d28b2c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_content_xls_model_44d28b2c ON public.sales_submission_content USING btree (xls_model);


--
-- Name: sales_submission_content_xls_model_44d28b2c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_content_xls_model_44d28b2c_like ON public.sales_submission_content USING btree (xls_model varchar_pattern_ops);


--
-- Name: sales_submission_content_xls_model_year_ca826a22; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_content_xls_model_year_ca826a22 ON public.sales_submission_content USING btree (xls_model_year);


--
-- Name: sales_submission_content_xls_model_year_ca826a22_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_content_xls_model_year_ca826a22_like ON public.sales_submission_content USING btree (xls_model_year varchar_pattern_ops);


--
-- Name: sales_submission_content_xls_vin_9d9b2ef0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_content_xls_vin_9d9b2ef0 ON public.sales_submission_content USING btree (xls_vin);


--
-- Name: sales_submission_content_xls_vin_9d9b2ef0_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_content_xls_vin_9d9b2ef0_like ON public.sales_submission_content USING btree (xls_vin varchar_pattern_ops);


--
-- Name: sales_submission_credit_tr_credit_transaction_id_1960f629; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_credit_tr_credit_transaction_id_1960f629 ON public.sales_submission_credit_transaction USING btree (credit_transaction_id);


--
-- Name: sales_submission_credit_tr_sales_submission_id_352461f9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_credit_tr_sales_submission_id_352461f9 ON public.sales_submission_credit_transaction USING btree (sales_submission_id);


--
-- Name: sales_submission_history_submission_id_e251081f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_history_submission_id_e251081f ON public.sales_submission_history USING btree (submission_id);


--
-- Name: sales_submission_organization_id_ecfa5fc0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_submission_organization_id_ecfa5fc0 ON public.sales_submission USING btree (organization_id);


--
-- Name: signing_authority_confirma_signing_authority_assertio_de796307; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX signing_authority_confirma_signing_authority_assertio_de796307 ON public.signing_authority_confirmation USING btree (signing_authority_assertion_id);


--
-- Name: signing_authority_confirmation_credit_transfer_id_c1a4c0e9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX signing_authority_confirmation_credit_transfer_id_c1a4c0e9 ON public.signing_authority_confirmation USING btree (credit_transfer_id);


--
-- Name: supplemental_report_assess_supplemental_report_assess_a056b98e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_assess_supplemental_report_assess_a056b98e ON public.supplemental_report_assessment USING btree (supplemental_report_assessment_description_id);


--
-- Name: supplemental_report_assess_supplemental_report_id_243795eb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_assess_supplemental_report_id_243795eb ON public.supplemental_report_assessment_comment USING btree (supplemental_report_id);


--
-- Name: supplemental_report_assessment_supplemental_report_id_4c03de96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_assessment_supplemental_report_id_4c03de96 ON public.supplemental_report_assessment USING btree (supplemental_report_id);


--
-- Name: supplemental_report_comment_supplemental_report_id_2af79f57; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_comment_supplemental_report_id_2af79f57 ON public.supplemental_report_comment USING btree (supplemental_report_id);


--
-- Name: supplemental_report_credit_activity_model_year_id_8718b60f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_credit_activity_model_year_id_8718b60f ON public.supplemental_report_credit_activity USING btree (model_year_id);


--
-- Name: supplemental_report_credit_supplemental_report_id_72b53528; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_credit_supplemental_report_id_72b53528 ON public.supplemental_report_credit_activity USING btree (supplemental_report_id);


--
-- Name: supplemental_report_file_a_supplemental_report_id_d5c6b1cc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_file_a_supplemental_report_id_d5c6b1cc ON public.supplemental_report_file_attachment USING btree (supplemental_report_id);


--
-- Name: supplemental_report_history_supplemental_report_id_809f37b1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_history_supplemental_report_id_809f37b1 ON public.supplemental_report_history USING btree (supplemental_report_id);


--
-- Name: supplemental_report_model_year_report_id_2ca17f1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_model_year_report_id_2ca17f1f ON public.supplemental_report USING btree (model_year_report_id);


--
-- Name: supplemental_report_sales_model_year_report_vehicle_id_3ea21f8a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_sales_model_year_report_vehicle_id_3ea21f8a ON public.supplemental_report_sales USING btree (model_year_report_vehicle_id);


--
-- Name: supplemental_report_sales_supplemental_report_id_392777fa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_sales_supplemental_report_id_392777fa ON public.supplemental_report_sales USING btree (supplemental_report_id);


--
-- Name: supplemental_report_suppli_supplemental_report_id_933d051e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplemental_report_suppli_supplemental_report_id_933d051e ON public.supplemental_report_supplier_information USING btree (supplemental_report_id);


--
-- Name: unique_non_deleted_vehicles; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_non_deleted_vehicles ON public.vehicle USING btree (make, model_name, vehicle_zev_type_id, model_year_id) WHERE (NOT ((validation_status)::text = 'DELETED'::text));


--
-- Name: user_profile_organization_id_836b384f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_profile_organization_id_836b384f ON public.user_profile USING btree (organization_id);


--
-- Name: user_profile_username_f86c0c97_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_profile_username_f86c0c97_like ON public.user_profile USING btree (username varchar_pattern_ops);


--
-- Name: user_role_role_id_6a11361a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_role_role_id_6a11361a ON public.user_role USING btree (role_id);


--
-- Name: user_role_user_profile_id_b48c3036; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_role_user_profile_id_b48c3036 ON public.user_role USING btree (user_profile_id);


--
-- Name: vehicle_class_code_vehicle_class_code_16ffe900_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_class_code_vehicle_class_code_16ffe900_like ON public.vehicle_class_code USING btree (vehicle_class_code varchar_pattern_ops);


--
-- Name: vehicle_comment_vehicle_id_ea0d0314; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_comment_vehicle_id_ea0d0314 ON public.vehicle_comment USING btree (vehicle_id);


--
-- Name: vehicle_credit_class_id_a258b312; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_credit_class_id_a258b312 ON public.vehicle USING btree (credit_class_id);


--
-- Name: vehicle_file_attachment_vehicle_id_238831e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_file_attachment_vehicle_id_238831e7 ON public.vehicle_file_attachment USING btree (vehicle_id);


--
-- Name: vehicle_model_year_id_8cc080d2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_model_year_id_8cc080d2 ON public.vehicle USING btree (model_year_id);


--
-- Name: vehicle_organization_id_8f346c5f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_organization_id_8f346c5f ON public.vehicle USING btree (organization_id);


--
-- Name: vehicle_vehicle_class_code_id_8bd7c11b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_vehicle_class_code_id_8bd7c11b ON public.vehicle USING btree (vehicle_class_code_id);


--
-- Name: vehicle_vehicle_zev_type_id_0f32dbc1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_vehicle_zev_type_id_0f32dbc1 ON public.vehicle USING btree (vehicle_zev_type_id);


--
-- Name: vehicle_zev_type_vehicle_zev_code_92f6e35d_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_zev_type_vehicle_zev_code_92f6e35d_like ON public.vehicle_zev_type USING btree (vehicle_zev_code varchar_pattern_ops);


--
-- Name: weight_class_code_weight_class_code_a4b62a39_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX weight_class_code_weight_class_code_a4b62a39_like ON public.weight_class_code USING btree (weight_class_code varchar_pattern_ops);


--
-- Name: logged_actions_relid_idx; Type: INDEX; Schema: zeva_audit; Owner: -
--

CREATE INDEX logged_actions_relid_idx ON zeva_audit.logged_actions USING btree (relid);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_agreement_comment credit_agreement_com_credit_agreement_id_99636959_fk_credit_ag; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_comment
    ADD CONSTRAINT credit_agreement_com_credit_agreement_id_99636959_fk_credit_ag FOREIGN KEY (credit_agreement_id) REFERENCES public.credit_agreement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_agreement_content credit_agreement_con_credit_agreement_id_4255d4f9_fk_credit_ag; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_content
    ADD CONSTRAINT credit_agreement_con_credit_agreement_id_4255d4f9_fk_credit_ag FOREIGN KEY (credit_agreement_id) REFERENCES public.credit_agreement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_agreement_content credit_agreement_con_credit_class_id_0540ae6b_fk_credit_cl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_content
    ADD CONSTRAINT credit_agreement_con_credit_class_id_0540ae6b_fk_credit_cl FOREIGN KEY (credit_class_id) REFERENCES public.credit_class_code(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_agreement_content credit_agreement_con_model_year_id_0406c15e_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_content
    ADD CONSTRAINT credit_agreement_con_model_year_id_0406c15e_fk_model_yea FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_agreement_credit_transaction credit_agreement_cre_credit_agreement_id_40bf067c_fk_credit_ag; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_credit_transaction
    ADD CONSTRAINT credit_agreement_cre_credit_agreement_id_40bf067c_fk_credit_ag FOREIGN KEY (credit_agreement_id) REFERENCES public.credit_agreement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_agreement_credit_transaction credit_agreement_cre_credit_transaction_i_ea870f1a_fk_credit_tr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_credit_transaction
    ADD CONSTRAINT credit_agreement_cre_credit_transaction_i_ea870f1a_fk_credit_tr FOREIGN KEY (credit_transaction_id) REFERENCES public.credit_transaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_agreement_file_attachment credit_agreement_fil_credit_agreement_id_b4fe3f4f_fk_credit_ag; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_file_attachment
    ADD CONSTRAINT credit_agreement_fil_credit_agreement_id_b4fe3f4f_fk_credit_ag FOREIGN KEY (credit_agreement_id) REFERENCES public.credit_agreement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_agreement_history credit_agreement_his_credit_agreement_id_34353eb7_fk_credit_ag; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement_history
    ADD CONSTRAINT credit_agreement_his_credit_agreement_id_34353eb7_fk_credit_ag FOREIGN KEY (credit_agreement_id) REFERENCES public.credit_agreement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_agreement credit_agreement_model_year_report_id_3fc5fa02_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement
    ADD CONSTRAINT credit_agreement_model_year_report_id_3fc5fa02_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_agreement credit_agreement_organization_id_8605a62d_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_agreement
    ADD CONSTRAINT credit_agreement_organization_id_8605a62d_fk_organization_id FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transaction credit_transaction_credit_class_id_bbf2d758_fk_credit_cl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction
    ADD CONSTRAINT credit_transaction_credit_class_id_bbf2d758_fk_credit_cl FOREIGN KEY (credit_class_id) REFERENCES public.credit_class_code(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transaction credit_transaction_credit_to_id_4c437b49_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction
    ADD CONSTRAINT credit_transaction_credit_to_id_4c437b49_fk_organization_id FOREIGN KEY (credit_to_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transaction credit_transaction_debit_from_id_d83b1367_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction
    ADD CONSTRAINT credit_transaction_debit_from_id_d83b1367_fk_organization_id FOREIGN KEY (debit_from_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transaction credit_transaction_model_year_id_04cd4baf_fk_model_year_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction
    ADD CONSTRAINT credit_transaction_model_year_id_04cd4baf_fk_model_year_id FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transaction credit_transaction_transaction_type_id_409914b1_fk_credit_tr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction
    ADD CONSTRAINT credit_transaction_transaction_type_id_409914b1_fk_credit_tr FOREIGN KEY (transaction_type_id) REFERENCES public.credit_transaction_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transaction credit_transaction_weight_class_id_a9983b87_fk_weight_cl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transaction
    ADD CONSTRAINT credit_transaction_weight_class_id_a9983b87_fk_weight_cl FOREIGN KEY (weight_class_id) REFERENCES public.weight_class_code(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transfer_comment credit_transfer_comm_credit_transfer_hist_4f943e5b_fk_credit_tr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_comment
    ADD CONSTRAINT credit_transfer_comm_credit_transfer_hist_4f943e5b_fk_credit_tr FOREIGN KEY (credit_transfer_history_id) REFERENCES public.credit_transfer_history(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transfer_content credit_transfer_cont_credit_class_id_62bd28df_fk_credit_cl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_content
    ADD CONSTRAINT credit_transfer_cont_credit_class_id_62bd28df_fk_credit_cl FOREIGN KEY (credit_class_id) REFERENCES public.credit_class_code(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transfer_content credit_transfer_cont_credit_transfer_id_016efc66_fk_credit_tr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_content
    ADD CONSTRAINT credit_transfer_cont_credit_transfer_id_016efc66_fk_credit_tr FOREIGN KEY (credit_transfer_id) REFERENCES public.credit_transfer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transfer_content credit_transfer_cont_weight_class_id_53f61b3c_fk_weight_cl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_content
    ADD CONSTRAINT credit_transfer_cont_weight_class_id_53f61b3c_fk_weight_cl FOREIGN KEY (weight_class_id) REFERENCES public.weight_class_code(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transfer_content credit_transfer_content_model_year_id_bc68a3a1_fk_model_year_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_content
    ADD CONSTRAINT credit_transfer_content_model_year_id_bc68a3a1_fk_model_year_id FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transfer_credit_transaction credit_transfer_cred_credit_transaction_i_c1a119d5_fk_credit_tr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_credit_transaction
    ADD CONSTRAINT credit_transfer_cred_credit_transaction_i_c1a119d5_fk_credit_tr FOREIGN KEY (credit_transaction_id) REFERENCES public.credit_transaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transfer_credit_transaction credit_transfer_cred_credit_transfer_id_b86b0303_fk_credit_tr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_credit_transaction
    ADD CONSTRAINT credit_transfer_cred_credit_transfer_id_b86b0303_fk_credit_tr FOREIGN KEY (credit_transfer_id) REFERENCES public.credit_transfer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transfer credit_transfer_credit_to_id_4efce8c0_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer
    ADD CONSTRAINT credit_transfer_credit_to_id_4efce8c0_fk_organization_id FOREIGN KEY (credit_to_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transfer credit_transfer_debit_from_id_a7a6116e_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer
    ADD CONSTRAINT credit_transfer_debit_from_id_a7a6116e_fk_organization_id FOREIGN KEY (debit_from_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: credit_transfer_history credit_transfer_hist_transfer_id_ddf6fd97_fk_credit_tr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transfer_history
    ADD CONSTRAINT credit_transfer_hist_transfer_id_ddf6fd97_fk_credit_tr FOREIGN KEY (transfer_id) REFERENCES public.credit_transfer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_clocked_id_47a69f82_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_clocked_id_47a69f82_fk_django_ce FOREIGN KEY (clocked_id) REFERENCES public.django_celery_beat_clockedschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_crontab_id_d3cba168_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_crontab_id_d3cba168_fk_django_ce FOREIGN KEY (crontab_id) REFERENCES public.django_celery_beat_crontabschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_interval_id_a8ca27da_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_interval_id_a8ca27da_fk_django_ce FOREIGN KEY (interval_id) REFERENCES public.django_celery_beat_intervalschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_solar_id_a87ce72c_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_solar_id_a87ce72c_fk_django_ce FOREIGN KEY (solar_id) REFERENCES public.django_celery_beat_solarschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: icbc_registration_data icbc_registration_da_icbc_upload_date_id_f24b9312_fk_icbc_uplo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_registration_data
    ADD CONSTRAINT icbc_registration_da_icbc_upload_date_id_f24b9312_fk_icbc_uplo FOREIGN KEY (icbc_upload_date_id) REFERENCES public.icbc_upload_date(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: icbc_registration_data icbc_registration_da_icbc_vehicle_id_7572c491_fk_icbc_vehi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_registration_data
    ADD CONSTRAINT icbc_registration_da_icbc_vehicle_id_7572c491_fk_icbc_vehi FOREIGN KEY (icbc_vehicle_id) REFERENCES public.icbc_vehicle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: icbc_snapshot_data icbc_snapshot_data_submission_id_4212e6a0_fk_sales_sub; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_snapshot_data
    ADD CONSTRAINT icbc_snapshot_data_submission_id_4212e6a0_fk_sales_sub FOREIGN KEY (submission_id) REFERENCES public.sales_submission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: icbc_vehicle icbc_vehicle_model_year_id_25b707e0_fk_model_year_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icbc_vehicle
    ADD CONSTRAINT icbc_vehicle_model_year_id_25b707e0_fk_model_year_id FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_address model_year_report_ad_address_type_id_b8e9034c_fk_address_t; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_address
    ADD CONSTRAINT model_year_report_ad_address_type_id_b8e9034c_fk_address_t FOREIGN KEY (address_type_id) REFERENCES public.address_type(id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_adjustment model_year_report_ad_credit_class_id_1d1579f4_fk_credit_cl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_adjustment
    ADD CONSTRAINT model_year_report_ad_credit_class_id_1d1579f4_fk_credit_cl FOREIGN KEY (credit_class_id) REFERENCES public.credit_class_code(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_adjustment model_year_report_ad_model_year_id_ee0e4981_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_adjustment
    ADD CONSTRAINT model_year_report_ad_model_year_id_ee0e4981_fk_model_yea FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_address model_year_report_ad_model_year_report_id_22bb07b9_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_address
    ADD CONSTRAINT model_year_report_ad_model_year_report_id_22bb07b9_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_adjustment model_year_report_ad_model_year_report_id_ee739661_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_adjustment
    ADD CONSTRAINT model_year_report_ad_model_year_report_id_ee739661_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_assessment model_year_report_as_model_year_report_as_5f4015a1_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_assessment
    ADD CONSTRAINT model_year_report_as_model_year_report_as_5f4015a1_fk_model_yea FOREIGN KEY (model_year_report_assessment_description_id) REFERENCES public.model_year_report_assessment_descriptions(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_assessment_comment model_year_report_as_model_year_report_id_49f26b96_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_assessment_comment
    ADD CONSTRAINT model_year_report_as_model_year_report_id_49f26b96_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_assessment model_year_report_as_model_year_report_id_d6cc53b4_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_assessment
    ADD CONSTRAINT model_year_report_as_model_year_report_id_d6cc53b4_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_compliance_obligation model_year_report_co_model_year_id_5b646f99_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_compliance_obligation
    ADD CONSTRAINT model_year_report_co_model_year_id_5b646f99_fk_model_yea FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_compliance_obligation model_year_report_co_model_year_report_id_a3ab5f15_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_compliance_obligation
    ADD CONSTRAINT model_year_report_co_model_year_report_id_a3ab5f15_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_confirmation model_year_report_co_model_year_report_id_bd42ce9f_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_confirmation
    ADD CONSTRAINT model_year_report_co_model_year_report_id_bd42ce9f_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_confirmation model_year_report_co_signing_authority_as_45189806_fk_signing_a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_confirmation
    ADD CONSTRAINT model_year_report_co_signing_authority_as_45189806_fk_signing_a FOREIGN KEY (signing_authority_assertion_id) REFERENCES public.signing_authority_assertion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_credit_transaction model_year_report_cr_credit_transaction_i_5ff28bfc_fk_credit_tr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_credit_transaction
    ADD CONSTRAINT model_year_report_cr_credit_transaction_i_5ff28bfc_fk_credit_tr FOREIGN KEY (credit_transaction_id) REFERENCES public.credit_transaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_credit_offset model_year_report_cr_model_year_id_c24c331d_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_credit_offset
    ADD CONSTRAINT model_year_report_cr_model_year_id_c24c331d_fk_model_yea FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_credit_transaction model_year_report_cr_model_year_report_id_68b95fb0_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_credit_transaction
    ADD CONSTRAINT model_year_report_cr_model_year_report_id_68b95fb0_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_credit_offset model_year_report_cr_model_year_report_id_f26ce86a_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_credit_offset
    ADD CONSTRAINT model_year_report_cr_model_year_report_id_f26ce86a_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_history model_year_report_hi_model_year_report_id_37063658_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_history
    ADD CONSTRAINT model_year_report_hi_model_year_report_id_37063658_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_ldv_sales model_year_report_ld_model_year_id_cfa935ed_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_ldv_sales
    ADD CONSTRAINT model_year_report_ld_model_year_id_cfa935ed_fk_model_yea FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_ldv_sales model_year_report_ld_model_year_report_id_4f2d6b09_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_ldv_sales
    ADD CONSTRAINT model_year_report_ld_model_year_report_id_4f2d6b09_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_make model_year_report_ma_model_year_report_id_01799a27_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_make
    ADD CONSTRAINT model_year_report_ma_model_year_report_id_01799a27_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report model_year_report_model_year_id_74554218_fk_model_year_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report
    ADD CONSTRAINT model_year_report_model_year_id_74554218_fk_model_year_id FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report model_year_report_organization_id_c0665455_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report
    ADD CONSTRAINT model_year_report_organization_id_c0665455_fk_organization_id FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_vehicle model_year_report_ve_model_year_id_1fb2ce70_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_vehicle
    ADD CONSTRAINT model_year_report_ve_model_year_id_1fb2ce70_fk_model_yea FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_vehicle model_year_report_ve_model_year_report_id_ec5e1854_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_vehicle
    ADD CONSTRAINT model_year_report_ve_model_year_report_id_ec5e1854_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_vehicle model_year_report_ve_vehicle_zev_type_id_c93e2b06_fk_vehicle_z; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_vehicle
    ADD CONSTRAINT model_year_report_ve_vehicle_zev_type_id_c93e2b06_fk_vehicle_z FOREIGN KEY (vehicle_zev_type_id) REFERENCES public.vehicle_zev_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: model_year_report_vehicle model_year_report_ve_zev_class_id_39ede20a_fk_credit_cl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_year_report_vehicle
    ADD CONSTRAINT model_year_report_ve_zev_class_id_39ede20a_fk_credit_cl FOREIGN KEY (zev_class_id) REFERENCES public.credit_class_code(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notification notification_permission_id_382f009d_fk_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_permission_id_382f009d_fk_permission_id FOREIGN KEY (permission_id) REFERENCES public.permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notification_subscription notification_subscri_user_profile_id_9e991605_fk_user_prof; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_subscription
    ADD CONSTRAINT notification_subscri_user_profile_id_9e991605_fk_user_prof FOREIGN KEY (user_profile_id) REFERENCES public.user_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_address organization_address_address_type_id_387ee3dc_fk_address_t; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_address
    ADD CONSTRAINT organization_address_address_type_id_387ee3dc_fk_address_t FOREIGN KEY (address_type_id) REFERENCES public.address_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_address organization_address_organization_id_2e03ad1c_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_address
    ADD CONSTRAINT organization_address_organization_id_2e03ad1c_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_deficits organization_deficit_credit_class_id_68c970f4_fk_credit_cl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_deficits
    ADD CONSTRAINT organization_deficit_credit_class_id_68c970f4_fk_credit_cl FOREIGN KEY (credit_class_id) REFERENCES public.credit_class_code(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_deficits organization_deficit_organization_id_1a842417_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_deficits
    ADD CONSTRAINT organization_deficit_organization_id_1a842417_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_deficits organization_deficits_model_year_id_b8982ae9_fk_model_year_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_deficits
    ADD CONSTRAINT organization_deficits_model_year_id_b8982ae9_fk_model_year_id FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization organization_first_model_year_id_afc0b1d4_fk_model_year_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_first_model_year_id_afc0b1d4_fk_model_year_id FOREIGN KEY (first_model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_ldv_sales organization_ldv_sal_organization_id_094faedd_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_ldv_sales
    ADD CONSTRAINT organization_ldv_sal_organization_id_094faedd_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_ldv_sales organization_ldv_sales_model_year_id_20b2b685_fk_model_year_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_ldv_sales
    ADD CONSTRAINT organization_ldv_sales_model_year_id_20b2b685_fk_model_year_id FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: record_of_sale record_of_sale_icbc_snapshot_id_bbdec575_fk_icbc_snap; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_of_sale
    ADD CONSTRAINT record_of_sale_icbc_snapshot_id_bbdec575_fk_icbc_snap FOREIGN KEY (icbc_snapshot_id) REFERENCES public.icbc_snapshot_data(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: record_of_sale record_of_sale_submission_id_0145d9d1_fk_sales_submission_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_of_sale
    ADD CONSTRAINT record_of_sale_submission_id_0145d9d1_fk_sales_submission_id FOREIGN KEY (submission_id) REFERENCES public.sales_submission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: record_of_sale record_of_sale_vehicle_id_1411d18a_fk_vehicle_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_of_sale
    ADD CONSTRAINT record_of_sale_vehicle_id_1411d18a_fk_vehicle_id FOREIGN KEY (vehicle_id) REFERENCES public.vehicle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: role_permission role_permission_permission_id_ee9c5982_fk_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_permission_id_ee9c5982_fk_permission_id FOREIGN KEY (permission_id) REFERENCES public.permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: role_permission role_permission_role_id_877a80a4_fk_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_role_id_877a80a4_fk_role_id FOREIGN KEY (role_id) REFERENCES public.role(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sales_submission_content sale_submission_cont_submission_id_28be2ed6_fk_sales_sub; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_content
    ADD CONSTRAINT sale_submission_cont_submission_id_28be2ed6_fk_sales_sub FOREIGN KEY (submission_id) REFERENCES public.sales_submission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sales_submission_evidence sale_submission_file_submission_id_03bfc421_fk_sales_sub; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_evidence
    ADD CONSTRAINT sale_submission_file_submission_id_03bfc421_fk_sales_sub FOREIGN KEY (submission_id) REFERENCES public.sales_submission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sales_forecast sales_forecast_model_year_report_id_19561159_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_forecast
    ADD CONSTRAINT sales_forecast_model_year_report_id_19561159_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sales_forecast_record sales_forecast_recor_sales_forecast_id_d8dd4842_fk_sales_for; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_forecast_record
    ADD CONSTRAINT sales_forecast_recor_sales_forecast_id_d8dd4842_fk_sales_for FOREIGN KEY (sales_forecast_id) REFERENCES public.sales_forecast(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sales_submission_comment sales_submission_com_sales_submission_id_4121699e_fk_sales_sub; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_comment
    ADD CONSTRAINT sales_submission_com_sales_submission_id_4121699e_fk_sales_sub FOREIGN KEY (sales_submission_id) REFERENCES public.sales_submission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sales_submission_credit_transaction sales_submission_cre_credit_transaction_i_1960f629_fk_credit_tr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_credit_transaction
    ADD CONSTRAINT sales_submission_cre_credit_transaction_i_1960f629_fk_credit_tr FOREIGN KEY (credit_transaction_id) REFERENCES public.credit_transaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sales_submission_credit_transaction sales_submission_cre_sales_submission_id_352461f9_fk_sales_sub; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_credit_transaction
    ADD CONSTRAINT sales_submission_cre_sales_submission_id_352461f9_fk_sales_sub FOREIGN KEY (sales_submission_id) REFERENCES public.sales_submission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sales_submission_history sales_submission_his_submission_id_e251081f_fk_sales_sub; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission_history
    ADD CONSTRAINT sales_submission_his_submission_id_e251081f_fk_sales_sub FOREIGN KEY (submission_id) REFERENCES public.sales_submission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sales_submission sales_submission_organization_id_ecfa5fc0_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_submission
    ADD CONSTRAINT sales_submission_organization_id_ecfa5fc0_fk_organization_id FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: signing_authority_confirmation signing_authority_co_credit_transfer_id_c1a4c0e9_fk_credit_tr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.signing_authority_confirmation
    ADD CONSTRAINT signing_authority_co_credit_transfer_id_c1a4c0e9_fk_credit_tr FOREIGN KEY (credit_transfer_id) REFERENCES public.credit_transfer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: signing_authority_confirmation signing_authority_co_signing_authority_as_de796307_fk_signing_a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.signing_authority_confirmation
    ADD CONSTRAINT signing_authority_co_signing_authority_as_de796307_fk_signing_a FOREIGN KEY (signing_authority_assertion_id) REFERENCES public.signing_authority_assertion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_credit_activity supplemental_report__model_year_id_8718b60f_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_credit_activity
    ADD CONSTRAINT supplemental_report__model_year_id_8718b60f_fk_model_yea FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_sales supplemental_report__model_year_report_ve_3ea21f8a_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_sales
    ADD CONSTRAINT supplemental_report__model_year_report_ve_3ea21f8a_fk_model_yea FOREIGN KEY (model_year_report_vehicle_id) REFERENCES public.model_year_report_vehicle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_assessment_comment supplemental_report__supplemental_report__243795eb_fk_supplemen; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_assessment_comment
    ADD CONSTRAINT supplemental_report__supplemental_report__243795eb_fk_supplemen FOREIGN KEY (supplemental_report_id) REFERENCES public.supplemental_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_comment supplemental_report__supplemental_report__2af79f57_fk_supplemen; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_comment
    ADD CONSTRAINT supplemental_report__supplemental_report__2af79f57_fk_supplemen FOREIGN KEY (supplemental_report_id) REFERENCES public.supplemental_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_sales supplemental_report__supplemental_report__392777fa_fk_supplemen; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_sales
    ADD CONSTRAINT supplemental_report__supplemental_report__392777fa_fk_supplemen FOREIGN KEY (supplemental_report_id) REFERENCES public.supplemental_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_assessment supplemental_report__supplemental_report__4c03de96_fk_supplemen; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_assessment
    ADD CONSTRAINT supplemental_report__supplemental_report__4c03de96_fk_supplemen FOREIGN KEY (supplemental_report_id) REFERENCES public.supplemental_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_credit_activity supplemental_report__supplemental_report__72b53528_fk_supplemen; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_credit_activity
    ADD CONSTRAINT supplemental_report__supplemental_report__72b53528_fk_supplemen FOREIGN KEY (supplemental_report_id) REFERENCES public.supplemental_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_history supplemental_report__supplemental_report__809f37b1_fk_supplemen; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_history
    ADD CONSTRAINT supplemental_report__supplemental_report__809f37b1_fk_supplemen FOREIGN KEY (supplemental_report_id) REFERENCES public.supplemental_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_supplier_information supplemental_report__supplemental_report__933d051e_fk_supplemen; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_supplier_information
    ADD CONSTRAINT supplemental_report__supplemental_report__933d051e_fk_supplemen FOREIGN KEY (supplemental_report_id) REFERENCES public.supplemental_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_assessment supplemental_report__supplemental_report__a056b98e_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_assessment
    ADD CONSTRAINT supplemental_report__supplemental_report__a056b98e_fk_model_yea FOREIGN KEY (supplemental_report_assessment_description_id) REFERENCES public.model_year_report_assessment_descriptions(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report_file_attachment supplemental_report__supplemental_report__d5c6b1cc_fk_supplemen; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report_file_attachment
    ADD CONSTRAINT supplemental_report__supplemental_report__d5c6b1cc_fk_supplemen FOREIGN KEY (supplemental_report_id) REFERENCES public.supplemental_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplemental_report supplemental_report_model_year_report_id_2ca17f1f_fk_model_yea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplemental_report
    ADD CONSTRAINT supplemental_report_model_year_report_id_2ca17f1f_fk_model_yea FOREIGN KEY (model_year_report_id) REFERENCES public.model_year_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_creation_request user_creation_reques_user_profile_id_0cbbf2cd_fk_user_prof; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_creation_request
    ADD CONSTRAINT user_creation_reques_user_profile_id_0cbbf2cd_fk_user_prof FOREIGN KEY (user_profile_id) REFERENCES public.user_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_profile user_profile_organization_id_836b384f_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_profile
    ADD CONSTRAINT user_profile_organization_id_836b384f_fk_organization_id FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_role user_role_role_id_6a11361a_fk_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_role_id_6a11361a_fk_role_id FOREIGN KEY (role_id) REFERENCES public.role(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_role user_role_user_profile_id_b48c3036_fk_user_profile_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_user_profile_id_b48c3036_fk_user_profile_id FOREIGN KEY (user_profile_id) REFERENCES public.user_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vehicle_change_history vehicle_change_history_vehicle_id_0932e651_fk_vehicle_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_change_history
    ADD CONSTRAINT vehicle_change_history_vehicle_id_0932e651_fk_vehicle_id FOREIGN KEY (vehicle_id) REFERENCES public.vehicle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vehicle_comment vehicle_comment_vehicle_id_ea0d0314_fk_vehicle_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_comment
    ADD CONSTRAINT vehicle_comment_vehicle_id_ea0d0314_fk_vehicle_id FOREIGN KEY (vehicle_id) REFERENCES public.vehicle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vehicle vehicle_credit_class_id_a258b312_fk_credit_class_code_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT vehicle_credit_class_id_a258b312_fk_credit_class_code_id FOREIGN KEY (credit_class_id) REFERENCES public.credit_class_code(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vehicle_file_attachment vehicle_file_attachment_vehicle_id_238831e7_fk_vehicle_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_file_attachment
    ADD CONSTRAINT vehicle_file_attachment_vehicle_id_238831e7_fk_vehicle_id FOREIGN KEY (vehicle_id) REFERENCES public.vehicle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vehicle vehicle_model_year_id_8cc080d2_fk_model_year_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT vehicle_model_year_id_8cc080d2_fk_model_year_id FOREIGN KEY (model_year_id) REFERENCES public.model_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vehicle vehicle_organization_id_8f346c5f_fk_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT vehicle_organization_id_8f346c5f_fk_organization_id FOREIGN KEY (organization_id) REFERENCES public.organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vehicle vehicle_vehicle_class_code_id_8bd7c11b_fk_vehicle_class_code_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT vehicle_vehicle_class_code_id_8bd7c11b_fk_vehicle_class_code_id FOREIGN KEY (vehicle_class_code_id) REFERENCES public.vehicle_class_code(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vehicle vehicle_vehicle_zev_type_id_0f32dbc1_fk_vehicle_zev_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT vehicle_vehicle_zev_type_id_0f32dbc1_fk_vehicle_zev_type_id FOREIGN KEY (vehicle_zev_type_id) REFERENCES public.vehicle_zev_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

